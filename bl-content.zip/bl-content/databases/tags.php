<?php defined('BLUDIT') or die('Bludit CMS.'); ?>
{
    "wordcamp-europe": {
        "name": "WordCamp Europe",
        "list": [
            "wordcamp-europe-2018-draws-2085-attendees-organizers-look",
            "matt-mullenweg-unveils-gutenberg-roadmap-at-wceu-wordpress",
            "wordcamp-europe-2018-contributor-day-posts-record-turnout",
            "wordcamp-europe-2018-speaker-applications-now-open",
            "wordcamp-europe-2018-early-bird-tickets-now-on",
            "wordcamp-europe-2017-posts-24-no-show-rate",
            "wordpress-new-gutenberg-editor-now-available-as-a",
            "wordcamp-europe-2018-to-be-held-in-belgrade",
            "wordcamp-europe-2017-draws-1900-attendees-from-79",
            "wordcamp-europe-2017-kicks-off-with-contributor-day",
            "worona-releases-free-wordcamp-europe-paris-guide-app",
            "wordcamp-europe-2017-livestream-tickets-now-available",
            "wpweekly-episode-274-wordpress-commercials-storefront-and-the",
            "wordcamp-europe-to-halt-regular-ticket-sales-may",
            "wordcamp-europe-attendees-are-being-denied-visas-because",
            "wordcamp-europe-contributor-day-to-host-13-workshops",
            "wordcamp-europe-2017-introduces-small-business-sponsorships",
            "wordcamp-europe-2017-announces-speakers-opens-registration-for",
            "wordcamp-europe-2017-to-experiment-with-sponsors-workshops",
            "wordcamp-europe-calls-for-host-city-applications-for",
            "call-for-applications-to-host-wordcamp-europe-2018",
            "wordcamp-europe-2017-will-host-the-next-wordpress",
            "wordcamp-europe-2016-videos-uploaded-to-wordpresstv-coloring",
            "in-case-you-missed-it-issue-12",
            "wpweekly-episode-239-wordcamp-europe-wordsesh-4-and",
            "wordcamp-europe-2016-livestream-recordings-now-available",
            "highlights-of-matt-mullenwegs-qa-at-wordcamp-europe",
            "wordcamp-europe-2017-will-be-in-paris-france",
            "wordcamp-europe-2016-kicks-off-today-in-vienna",
            "wpweekly-episode-236-wordpress-turns-13-years-old",
            "wordcamp-europe-to-offer-free-live-streaming-for",
            "wordcamp-europe-2016-expands-attendee-capacity-to-2200",
            "wordcamp-europe-assembles-130-person-volunteer-team"
        ]
    },
    "atomic-blocks": {
        "name": "atomic blocks",
        "list": [
            "array-launches-free-gutenberg-ready-atomic-blocks-theme"
        ]
    },
    "gutenberg": {
        "name": "gutenberg",
        "list": [
            "array-launches-free-gutenberg-ready-atomic-blocks-theme",
            "wpweekly-episode-323-recap-of-wordcamp-grand-rapids",
            "video-a-quick-introduction-to-gutenberg-and-the",
            "video-matt-mullenwegs-summertime-update-at-wceu-2018",
            "new-classic-editor-addon-plugin-disables-the-try",
            "wordpress-498-to-introduce-try-gutenberg-callout",
            "block-unit-test-plugin-helps-wordpress-theme-developers",
            "wceu-panel-discusses-progressive-wordpress-themes-amp-and",
            "drop-it-plugin-brings-gifs-and-unsplash-photos",
            "gutenberg-31-introduces-tips-interface-to-guide-new",
            "interview-with-matias-ventura-on-building-the-vision",
            "matt-mullenweg-unveils-gutenberg-roadmap-at-wceu-wordpress",
            "wpweekly-episode-321-recap-of-wordcamp-eu-2018",
            "gutenberg-team-panel-talks-release-timeline-theme-building-0",
            "gutenberg-team-panel-talks-release-timeline-theme-building",
            "wpweekly-episode-319-the-gutenberg-plugin-turns-31",
            "wpweekly-episode-319-the-gutenberg-plugin-turns-30",
            "one-way-to-whitelist-and-blacklist-blocks-in",
            "wpweekly-episode-315-wordpress-496-gutenberg-and-stolen",
            "wpweekly-episode-314-getting-squeebly-with-it",
            "a-gutenberg-migration-guide-for-developers",
            "wpweekly-episode-313-buddypress-gutenberg-and-an-upcoming",
            "wordpress-for-ios-and-gutenberg-dont-get-along",
            "gutenberg-27-released-adds-ability-to-edit-permalinks",
            "talking-gutenberg-on-episode-eight-of-the-drunken",
            "wpweekly-episode-312-dragon-drop-wordpress-accessibility-statement",
            "gutenberg-26-introduces-drag-and-drop-block-sorting",
            "an-update-to-my-gutenberg-experience",
            "wpweekly-episode-311-jetpack-60-wordpress-495-and",
            "try-gutenberg-prompt-pushed-back-to-a-later",
            "wpweekly-episode-310-community-management-php-and-hello",
            "my-gutenberg-experience-thus-far",
            "in-wordpress-495-users-will-be-two-clicks",
            "why-gutenberg-and-why-now",
            "wpweekly-episode-308-wildcard-ssl-certificates-for-all",
            "wpweekly-episode-307-thirty-percent-of-the-web",
            "conceptual-ideas-on-how-the-customizer-could-integrate",
            "4500-plugins-need-your-help-in-determining-gutenberg",
            "wpweekly-episode-306-amp-gdpr-and-brewing-beer",
            "matt-cromwell-hosts-matt-mullenweg-in-qa-gutenberg",
            "wpweekly-episode-303-interview-with-zac-gordon-technology",
            "new-toolkit-simplifies-the-process-of-creating-gutenberg",
            "gutenberg-20-released-with-numerous-accessibility-and-keyboard",
            "zac-gordon-launches-gutenberg-development-course-includes-more",
            "wpweekly-episode-300-interview-with-matt-gutenbeard-mullenweg",
            "a-collection-of-gutenberg-conversations-resources-and-videos",
            "wpweekly-episode-297-wordcamp-us-2017-recap",
            "gutenberg-and-the-wordpress-of-tomorrow-by-morten",
            "gutenberg-18-adds-greater-extensibility-for-plugin-developers",
            "four-things-id-like-to-see-in-this",
            "gutenberg-team-is-ramping-up-usability-testing-at",
            "wpweekly-episode-295-turkey-with-a-side-of",
            "tailor-page-builder-plugin-discontinued-owners-cite-funding",
            "woocommerce-explores-the-possibilities-and-challenges-for-e",
            "wpweekly-episode-294-heropress-community-and-winningwp-with",
            "gutenberg-17-adds-multi-block-transform-functionality-drops",
            "gutenberg-contributors-explore-alternative-to-using-iframes-for",
            "gutenberg-contributors-discuss-the-drawbacks-of-using-iframes",
            "gutenberg-16-improves-writing-experience-moves-block-toolbar",
            "wordpress-49-beta-4-removes-try-gutenberg-call",
            "gutenberg-15-adds-initial-support-for-meta-boxes",
            "bear-app-users-want-wordpress-publishing-integration",
            "wpweekly-episode-291-all-hands-on-deck-on",
            "gutenberg-14-adds-html-mode-for-blocks",
            "gutenberg-engineer-matias-ventura-unpacks-the-vision-for",
            "gutenberg-13-adds-new-feedback-option-for-plugin",
            "wpweekly-episode-290-putting-the-rad-in-brad",
            "gutenberg-12-adds-postmeta-support-and-extended-settings",
            "wordpress-explores-a-javascript-framework-agnostic-approach-to",
            "wpweekly-episode-288-no-reactjs-framework-for-gutenberg",
            "why-vuejs-creator-evan-you-thinks-vue-could",
            "wordpress-abandons-react-due-to-patents-clause-gutenberg",
            "gutenberg-to-offer-new-approach-to-tinymce-in",
            "gutenberg-110-adds-autocomplete-for-blocks-developers-elaborate",
            "wordcamp-grand-rapids-attendees-share-first-impressions-of",
            "gutenberg-100-introduces-drag-and-drop-for-adding",
            "matt-mullenweg-addresses-concerns-about-gutenberg-confirms-new",
            "wpweekly-episode-286-upgrading-php-facebook-not-budging",
            "morten-rand-hendriksen-on-what-gutenberg-means-for",
            "user-experience-tests-show-gutenbergs-ui-elements-can",
            "wpweekly-episode-285-not-every-wordpress-is-the",
            "gutenberg-080-introduces-5-new-blocks-categories-text",
            "user-tracking-to-be-removed-from-gutenberg-in",
            "wpweekly-episode-284-catching-up-with-david-peralty",
            "wordpress-core-fields-api-project-sees-renewed-interest",
            "gutenberg-development-team-confirms-meta-box-api-will",
            "gutenberg-070-adds-opt-in-usage-tracking",
            "wpweekly-episode-283-a-visit-from-st-gutenberg",
            "gutenberg-060-changes-text-paragraph-block-behavior-adds",
            "wpweekly-episode-282-talking-woocommerce-with-cody-landefeld",
            "gutenberg-boilerplate-demonstrates-how-to-build-custom-blocks",
            "gutenberg-050-adds-new-verse-block-for-poetry",
            "gutenberg-contributors-explore-adding-drag-and-drop-and",
            "gutenberg-030-adds-front-end-styles-for-core",
            "popular-wordpress-plugins-slow-to-add-meta-box",
            "wpweekly-episode-279-the-future-of-underscores-with",
            "wordpress-opens-up-more-channels-for-gutenberg-testing",
            "why-gutenberg",
            "gutenberg-020-released-adds-new-custom-html-and",
            "wordpress-49-to-focus-on-managing-plugins-and",
            "wordpress-new-gutenberg-editor-now-available-as-a",
            "wordpress-48-release-targeted-for-june-8",
            "wordpress-core-editor-team-publishes-ui-prototype-for"
        ]
    },
    "automattic": {
        "name": "automattic",
        "list": [
            "wpweekly-episode-323-recap-of-wordcamp-grand-rapids",
            "wpweekly-episode-309-all-amped-up",
            "wpweekly-episode-306-amp-gdpr-and-brewing-beer",
            "wpweekly-episode-296-gutenberg-telemetry-calypso-and-more",
            "amp-project-turns-2-automattic-partners-with-google",
            "trademark-trial-and-appeal-board-dismisses-automattics-trademark",
            "blog-passes-100000-registrations-665-of-purchased-domains",
            "automattic-to-renew-efforts-on-underscores-retire-components",
            "wpweekly-episode-271-recapping-wordcamp-chicago-2017-with",
            "automattic-to-close-san-francisco-office",
            "automattic-to-host-a-free-remote-conference-on",
            "blog-in-a-box-project-integrates-wordpress-with",
            "jetpack-introduces-theme-installation-from-wordpresscom-sparks-controversy",
            "jetpack-43-now-in-beta-admin-interface-rebuilt",
            "in-case-you-missed-it-issue-15",
            "registration-of-the-blog-domain-extension-is-now",
            "automattic-will-continue-to-use-reactjs-in-calypso",
            "in-case-you-missed-it-issue-13",
            "codeableio-buys-back-shares-from-early-investors-partners",
            "wpweekly-episode-240-interview-with-matt-mullenweg-2016",
            "automattic-pushes-the-advanced-wordpress-facebook-group-giveaway",
            "pressable-rolls-back-database-change-that-caused-customer",
            "the-blog-domain-extension-is-now-open-to",
            "automattic-to-oversee-the-sale-and-registration-of",
            "wpweekly-episode-233-recap-of-wordcamp-chicago-2016",
            "automattic-introduces-woocommerce-connect-hosted-components-for-e",
            "edit-flow-lives-new-update-fixes-bugs-and",
            "hey-automattic-whats-going-on-with-edit-flow",
            "automattic-partners-with-lets-encrypt-to-enable-https",
            "in-case-you-missed-it-issue-6",
            "cast-of-silicon-valley-nails-the-meaning-of",
            "in-case-you-missed-it-issue-4",
            "automattic-releases-wordpress-plugin-for-facebooks-instant-articles",
            "in-case-you-missed-it-issue-3",
            "stripe-payment-gateway-for-woocommerce-is-now-available",
            "automattic-adds-amp-support-to-wordpresscom-releases-plugin",
            "automattic-launches-components-with-5-new-starter-themes"
        ]
    },
    "wceu": {
        "name": "wceu",
        "list": [
            "wpweekly-episode-323-recap-of-wordcamp-grand-rapids",
            "three-minute-movie-showcases-the-wordcamp-eu-2018",
            "wpweekly-episode-277-wordpress-48-filing-good-bug"
        ]
    },
    "wordcamp-grand-rapids": {
        "name": "wordcamp grand rapids",
        "list": [
            "wpweekly-episode-323-recap-of-wordcamp-grand-rapids",
            "wordcamp-grand-rapids-attendees-share-first-impressions-of",
            "wordcamp-grand-rapids-2017-sells-out-organizers-on"
        ]
    },
    "paypal": {
        "name": "paypal",
        "list": [
            "wordcamp-ticket-sales-move-from-paypal-to-stripe",
            "paypal-for-woocommerce-how-andrew-angell-is-building"
        ]
    },
    "stripe": {
        "name": "stripe",
        "list": [
            "wordcamp-ticket-sales-move-from-paypal-to-stripe",
            "wpweekly-episode-224-preview-of-wordpress-45",
            "stripe-payment-gateway-for-woocommerce-is-now-available"
        ]
    },
    "wordcamps": {
        "name": "wordcamps",
        "list": [
            "wordcamp-ticket-sales-move-from-paypal-to-stripe",
            "wordcamp-for-ios-renamed-to-wp-camps-more-0",
            "wordcamp-for-ios-renamed-to-wp-camps-more",
            "marcel-schmitz-releases-unofficial-wordcamp-for-ios-app",
            "a-wordcamp-for-organizers-is-in-the-planning",
            "donatewc-successfully-sponsors-its-first-applicant-to-wordcamp",
            "donatewc-reaches-fundraising-goal",
            "donatewc-aims-to-provide-travel-sponsorships-to-attend",
            "wpweekly-episode-287-wordpress-meetups-events-and-wordcamps",
            "wpweekly-episode-278-recap-of-wordcamp-europe-2017",
            "wpweekly-episode-275-the-javascript-framework-rabbit-hole",
            "in-case-you-missed-it-issue-20",
            "community-team-releases-plugin-that-displays-wordpress-events",
            "how-to-view-upcoming-wordcamps-in-the-wordpress",
            "do-you-enjoy-wordpress-meetups-let-the-community",
            "the-value-of-sponsoring-a-wordcamp-from-a",
            "the-challenges-of-organizing-a-wordcamp-from-abroad",
            "headway-389-patches-potential-xss-vulnerability",
            "how-wordcamp-londons-social-event-was-more-inclusive",
            "should-wordcamp-afterparties-be-alcohol-free",
            "wpweekly-episode-234-all-things-wordcamp-with-andrea",
            "wpweekly-episode-229-versionpress-goes-open-source",
            "wordcamp-central-now-lets-you-track-an-events"
        ]
    },
    "cookie": {
        "name": "cookie",
        "list": [
            "video-matt-mullenwegs-summertime-update-at-wceu-2018"
        ]
    },
    "keynote": {
        "name": "keynote",
        "list": [
            "video-matt-mullenwegs-summertime-update-at-wceu-2018"
        ]
    },
    "higher-education": {
        "name": "higher education",
        "list": [
            "wpcampus-will-be-streamed-live-for-free-july",
            "free-conference-dedicated-to-wordpress-in-higher-ed",
            "wpweekly-episode-301-wordpress-in-highered-accessibility-and",
            "wpcampus-online-scheduled-for-january-23rd-2017",
            "wpcampus-is-accepting-applications-to-host-the-event",
            "wpcampus-survey-results-indicate-misconceptions-of-wordpress-are"
        ]
    },
    "livestream": {
        "name": "livestream",
        "list": [
            "wpcampus-will-be-streamed-live-for-free-july",
            "watch-wordcamp-eu-for-free-via-livestream-0",
            "watch-wordcamp-eu-for-free-via-livestream",
            "watch-wordcamp-miami-2018-via-free-livestream",
            "watch-wpcampus-sessions-for-free-via-livestream-starting"
        ]
    },
    "wpcampus": {
        "name": "wpcampus",
        "list": [
            "wpcampus-will-be-streamed-live-for-free-july",
            "wpcampus-scheduled-for-july-12-14-in-st",
            "free-conference-dedicated-to-wordpress-in-higher-ed",
            "wpweekly-episode-301-wordpress-in-highered-accessibility-and",
            "wpcampus-2017-will-be-streamed-live-for-free",
            "in-case-you-missed-it-issue-21",
            "wpweekly-episode-266-clef-is-shutting-down-configuring",
            "wpcampus-2017-to-take-place-july-14-15",
            "wpcampus-online-scheduled-for-january-23rd-2017",
            "wpcampus-is-accepting-applications-to-host-the-event",
            "watch-wpcampus-sessions-for-free-via-livestream-starting",
            "help-wpcampus-gather-data-on-how-schools-and",
            "the-inaugural-wpcampus-set-for-july-15-16"
        ]
    },
    "japan": {
        "name": "japan",
        "list": [
            "how-wordpress-is-powering-a-new-community-on",
            "json-api-now-available-for-wordpress-wapuu-archive"
        ]
    },
    "wordcamp": {
        "name": "wordcamp",
        "list": [
            "how-wordpress-is-powering-a-new-community-on",
            "wpweekly-episode-317-minor-major-major-minor-release",
            "wpweekly-episode-311-jetpack-60-wordpress-495-and",
            "wordcamp-albuquerque-gears-up-for-5th-edition-in",
            "harare-and-nairobi-host-2nd-round-of-successful",
            "wordcamp-incubator-program-gears-up-for-round-2",
            "camp-press-a-detox-from-digital-life",
            "wordcamp-ann-arbor-to-host-second-wordcamp-warmup",
            "wordcamp-grand-rapids-2017-sells-out-organizers-on",
            "watch-wordcamp-varna-wapuus-get-designed-in-real",
            "zagreb-to-host-3rd-wordcamp-in-croatia-september",
            "wordcamp-netherlands-reinstated-for-2018",
            "wpweekly-episode-277-wordpress-48-filing-good-bug",
            "wordpress-community-team-considers-new-retreat-style-wordcamp",
            "wpweekly-episode-270-going-camp-press-with-mendel",
            "wordpress-community-support-shuts-down-wordcamp-netherlands-in",
            "in-case-you-missed-it-issue-18",
            "wordcamp-orlando-rescheduled-for-november-12-13",
            "wordcamp-orlando-rescheduled-for-november-12-14",
            "wordcamp-orlando-cancelled-due-to-hurricane",
            "new-wordpress-plugin-displays-a-live-twitter-wall",
            "wordsesh-4-this-saturday-august-20-at-0000",
            "wordsesh-4-scheduled-for-august-19-20",
            "wpweekly-episode-238-interview-with-adam-warner-sitelocks",
            "wordcamp-northeast-ohio-a-smashing-success",
            "wordcamp-chicago-2016-was-a-deep-dish-of",
            "wordcamp-organizers-get-new-tool-for-creating-personalized",
            "wpweekly-episode-232-recap-of-wordcamp-san-diego",
            "im-attending-wordcamp-chicago-2016-this-weekend",
            "europe-tops-wordcamp-growth-in-2015-with-70",
            "wpweekly-episode-226-burnout",
            "wordpress-to-launch-experimental-wordcamp-incubator-program"
        ]
    },
    "react": {
        "name": "react",
        "list": [
            "just-write-a-client-side-react-app-for",
            "drupal-core-maintainers-propose-adopting-react-for-administrative",
            "wpweekly-episode-289-where-did-wordpress-ease-of",
            "wordpress-core-javascript-framework-selection-discussion-continues-with",
            "facebook-to-re-license-react-after-backlash-from",
            "wordpress-explores-a-javascript-framework-agnostic-approach-to",
            "wpweekly-episode-288-no-reactjs-framework-for-gutenberg",
            "why-vuejs-creator-evan-you-thinks-vue-could",
            "wordpress-abandons-react-due-to-patents-clause-gutenberg",
            "matt-mullenweg-addresses-concerns-about-gutenberg-confirms-new",
            "wpweekly-episode-286-upgrading-php-facebook-not-budging",
            "facebook-isnt-budging-on-reacts-bsd-patents-license",
            "petition-to-re-license-react-has-been-escalated",
            "the-state-of-javascript-2017-survey-is-now",
            "react-users-petition-facebook-to-re-license-reactjs",
            "vuejs-creator-evan-you-weighs-in-on-wordpress",
            "wordpress-core-javascript-framework-debate-heats-up-contributors",
            "wordpress-to-select-new-javascript-framework-for-use",
            "free-react-fundamentals-course-updated-for-react-v155",
            "wordexpress-project-experiments-with-bringing-graphql-to-wordpress",
            "state-of-javascript-survey-results-published-react-emerges",
            "codecademy-launches-free-reactjs-courses",
            "jetpack-43-now-in-beta-admin-interface-rebuilt",
            "wes-bos-launches-free-reactjs-redux-online-course"
        ]
    },
    "jivot": {
        "name": "живот",
        "list": [
            "kak-da-namerite-partnor-v-lyubovta-priyatel-uchitel",
            "10-jiteiski-saveta-ot-vashata-kotka"
        ]
    },
    "lichnostno-razvitie": {
        "name": "личностно развитие",
        "list": [
            "kak-da-namerite-partnor-v-lyubovta-priyatel-uchitel"
        ]
    },
    "lyubov": {
        "name": "любов",
        "list": [
            "kak-da-namerite-partnor-v-lyubovta-priyatel-uchitel"
        ]
    },
    "wordcamp-incubator-program": {
        "name": "wordcamp incubator program",
        "list": [
            "wordcamp-incubator-program-2018-to-host-events-in",
            "wordcamp-incubator-program-gears-up-for-round-2",
            "harare-zimbabwe-to-host-its-2nd-wordcamp-november",
            "incubator-wordcamp-denpasar-a-success",
            "harare-zimbabwe-hosts-its-first-wordcamp",
            "wordcamp-incubator-program-to-launch-in-indonesia-zimbabwe",
            "wordcamp-incubator-program-receives-182-applications-narrows-candidates"
        ]
    },
    "amp": {
        "name": "amp",
        "list": [
            "wceu-panel-discusses-progressive-wordpress-themes-amp-and",
            "wpweekly-episode-313-buddypress-gutenberg-and-an-upcoming",
            "amp-for-wordpress-07-rc-1-released",
            "wpweekly-episode-309-all-amped-up",
            "wpweekly-episode-308-wildcard-ssl-certificates-for-all",
            "wpweekly-episode-306-amp-gdpr-and-brewing-beer",
            "amp-project-turns-2-automattic-partners-with-google",
            "google-updates-amp-to-allow-sharing-of-canonical",
            "wpweekly-episode-251-amp-translation-day-2-and",
            "wordpresscom-adds-customization-for-amp-pages-pushes-update",
            "google-is-amping-up-mobile-search-results-as",
            "wpweekly-episode-224-preview-of-wordpress-45",
            "automattic-adds-amp-support-to-wordpresscom-releases-plugin"
        ]
    },
    "progressive-web-apps": {
        "name": "progressive web apps",
        "list": [
            "wceu-panel-discusses-progressive-wordpress-themes-amp-and"
        ]
    },
    "progressive-wordpress-themes": {
        "name": "progressive WordPress themes",
        "list": [
            "wceu-panel-discusses-progressive-wordpress-themes-amp-and"
        ]
    },
    "acquisition": {
        "name": "acquisition",
        "list": [
            "wpweekly-episode-322-wp-engine-acquires-studiopress",
            "wp-engine-acquires-studiopress",
            "liquid-web-acquires-ithemes-in-multi-million-dollar",
            "updraftplus-acquires-easy-updates-manager-plugin",
            "wpweekly-episode-298-gdpr-user-privacy-and-more",
            "wp-site-care-acquires-wp-radius",
            "9seeds-acquires-web-savvy-marketings-genesis-theme-store",
            "imagely-acquires-teslathemes-is-seeking-other-acquisition-opportunities",
            "podcast-motor-acquires-seriously-simple-podcasting-plugin",
            "updraftplus-acquires-wp-optimize-will-be-integrated-into",
            "wpweekly-episode-248-insight-into-the-managewp-acquisition"
        ]
    },
    "security": {
        "name": "security",
        "list": [
            "wpweekly-episode-322-wp-engine-acquires-studiopress",
            "wpweekly-episode-320-building-a-sustainable-web-0",
            "wpweekly-episode-320-building-a-sustainable-web",
            "wordpress-495-squashes-25-bugs",
            "lets-encrypt-wildcard-certificates-are-now-available",
            "new-plugin-makes-wordpress-core-updates-more-secure",
            "wordpress-492-patches-xss-vulnerability",
            "jetpack-561-increases-security-of-the-contact-form",
            "wordpress-491-released-fixes-page-template-bug",
            "github-launches-security-alerts-for-javascript-and-ruby",
            "wpweekly-episode-293-wordpress-483-rip-firebug-and",
            "wordpress-483-a-security-release-six-weeks-in",
            "postman-smtp-plugin-forked-after-removal-from-wordpressorg",
            "github-launches-new-dependency-graph-feature-with-security",
            "disqus-data-breach-affects-175-million-accounts",
            "new-wp-cli-project-aims-to-extend-checksum",
            "si-captcha-anti-spam-plugin-permanently-removed-from",
            "wordpress-482-patches-eight-security-vulnerabilities",
            "display-widgets-plugin-permanently-removed-from-wordpressorg-due",
            "equifax-launches-wordpress-powered-site-for-consumers-affected",
            "sitelock-acquires-patchmans-malware-and-vulnerability-detection-technology",
            "wpweekly-episode-273-mental-health-awareness-with-bridget",
            "wordpress-475-patches-six-security-issues-immediate-update",
            "wordpress-is-now-on-hackerone-launches-bug-bounties",
            "wordpress-security-issue-in-password-reset-emails-to",
            "hacked-home-routers-are-launching-brute-force-attacks",
            "data-from-theme-reviews-shows-authors-need-more",
            "wpweekly-episode-267-interview-with-aaron-d-campbell",
            "in-case-you-missed-it-issue-18",
            "wpweekly-episode-266-clef-is-shutting-down-configuring",
            "wordpress-473-patches-six-security-vulnerabilities-immediate-update",
            "hackerone-launches-free-community-edition-for-non-commercial",
            "nextgen-gallery-patches-critical-sql-injection-vulnerability",
            "learn-how-to-find-and-exploit-xss-vulnerabilities",
            "cloudflare-memory-leak-exposes-private-data",
            "wpweekly-episode-264-rest-api-disqus-and-happy",
            "how-to-check-if-installed-plugins-are-no",
            "wpweekly-episode-263-plugins-disappearing-wordcamp-miami-and",
            "matt-mullenweg-responds-to-security-rant-digital-signatures",
            "why-plugins-sometimes-disappear-from-the-wordpress-plugin",
            "wordpress-rest-api-vulnerability-exploits-continue",
            "wpweekly-episode-262-interview-with-morten-rand-hendriksen",
            "wp-super-cache-149-patches-multiple-xss-vulnerabilities",
            "wordpress-rest-api-vulnerability-is-being-actively-exploited",
            "wpweekly-episode-261-wordpress-for-schools-with-cameron",
            "aaron-d-campbell-replaces-nikolay-bachiyski-as-wordpress",
            "wordpress-471-fixes-eight-security-issues",
            "buddypress-274-patches-security-vulnerability-that-could-allow",
            "wpweekly-episode-256-interview-with-tony-perez-ceo",
            "wp-ecommerce-3114-patches-sql-injection-vulnerability",
            "high-risk-xss-vulnerability-discovered-in-w3-total",
            "managewp-launches-automated-security-scanning",
            "wordpress-461-released-patches-two-security-vulnerabilities",
            "jetpack-42-released-with-performance-and-security-updates",
            "techcrunch-hacked-by-ourmine-attackers-target-weak-passwords",
            "downtime-expected-for-some-wp-engine-customers-as",
            "18-wordpress-plugins-updated-due-to-summer-of",
            "bbpress-2510-patches-security-vulnerability",
            "all-in-one-seo-237-patches-persistent-xss",
            "wordpress-453-fixes-7-security-issues",
            "jetpack-404-released-patches-3-security-vulnerabilities",
            "critical-vulnerability-patched-in-ewww-image-optimizer-plugin",
            "wp-mobile-detector-plugin-patched-for-arbitrary-file",
            "jetpack-403-patches-a-critical-xss-vulnerability",
            "wpweekly-episode-234-all-things-wordcamp-with-andrea",
            "critical-vulnerabilities-found-in-phpstorm-immediate-update-advised",
            "wordpress-452-patches-two-security-vulnerabilities",
            "ninja-forms-update-patches-critical-security-vulnerability",
            "bbpress-259-patches-cross-site-scripting-vulnerability",
            "templatic-hacked-files-and-databases-compromised",
            "wpweekly-episode-231-an-inside-look-at-the",
            "sucuri-partners-with-lets-encrypt-to-offer-free",
            "wpweekly-episode-229-versionpress-goes-open-source",
            "outdated-and-vulnerable-wordpress-and-drupal-versions-may",
            "user-role-editor-425-patches-critical-security-vulnerability",
            "wpweekly-episode-225-interview-with-scott-kingsley-clark",
            "custom-content-type-manager-plugin-update-creates-a",
            "roots-team-releases-wp-password-bcrypt-plugin-to",
            "critical-security-vulnerability-discovered-in-elegant-themes-products"
        ]
    },
    "studiopress": {
        "name": "studiopress",
        "list": [
            "wpweekly-episode-322-wp-engine-acquires-studiopress",
            "wp-engine-acquires-studiopress",
            "wpweekly-episode-302-brian-gardner-founder-of-studiopress",
            "9seeds-acquires-web-savvy-marketings-genesis-theme-store",
            "studiopress-puts-woocommerce-compatibility-on-the-roadmap-for"
        ]
    },
    "tide": {
        "name": "Tide",
        "list": [
            "wpweekly-episode-322-wp-engine-acquires-studiopress",
            "tide-project-aims-to-audit-and-score-wordpress"
        ]
    },
    "wp-engine": {
        "name": "wp engine",
        "list": [
            "wpweekly-episode-322-wp-engine-acquires-studiopress",
            "wp-engine-acquires-studiopress",
            "wp-engine-adds-2fa-to-user-portal-opt"
        ]
    },
    "javascript": {
        "name": "javascript",
        "list": [
            "free-javascript-for-wordpress-conference-to-stream-live",
            "wpweekly-episode-305-10up-javascript-for-wordpress-conference",
            "free-virtual-wordpress-for-javascript-conference-june-29th",
            "scotch-school-offers-free-course-on-getting-started",
            "wordpress-replaces-browserify-with-webpack-for-build-process",
            "wordpress-core-javascript-framework-selection-discussion-continues-with",
            "facebook-to-re-license-react-after-backlash-from",
            "wordpress-explores-a-javascript-framework-agnostic-approach-to",
            "why-vuejs-creator-evan-you-thinks-vue-could",
            "the-state-of-javascript-2017-survey-is-now",
            "vuejs-creator-evan-you-weighs-in-on-wordpress",
            "wpweekly-episode-275-the-javascript-framework-rabbit-hole",
            "wordpress-core-javascript-framework-debate-heats-up-contributors",
            "wordpress-to-select-new-javascript-framework-for-use",
            "wes-bos-launches-javascript30-a-free-30-day",
            "fall-enrollment-for-zac-gordons-javascript-for-wordpress",
            "state-of-javascript-survey-results-published-react-emerges",
            "wes-bos-launches-free-reactjs-redux-online-course"
        ]
    },
    "aftermovie": {
        "name": "aftermovie",
        "list": [
            "three-minute-movie-showcases-the-wordcamp-eu-2018"
        ]
    },
    "production-pool": {
        "name": "production pool",
        "list": [
            "three-minute-movie-showcases-the-wordcamp-eu-2018"
        ]
    },
    "zabava": {
        "name": "забава",
        "list": [
            "10-jiteiski-saveta-ot-vashata-kotka"
        ]
    },
    "kotki": {
        "name": "котки",
        "list": [
            "10-jiteiski-saveta-ot-vashata-kotka"
        ]
    },
    "samopoznanie": {
        "name": "самопознание",
        "list": [
            "10-jiteiski-saveta-ot-vashata-kotka"
        ]
    },
    "uroci": {
        "name": "уроци",
        "list": [
            "10-jiteiski-saveta-ot-vashata-kotka"
        ]
    },
    "interview": {
        "name": "interview",
        "list": [
            "wpweekly-episode-321-recap-of-wordcamp-eu-2018",
            "wpweekly-episode-320-building-a-sustainable-web-0",
            "wpweekly-episode-320-building-a-sustainable-web",
            "wpweekly-episode-309-all-amped-up",
            "matt-cromwell-hosts-matt-mullenweg-in-qa-gutenberg",
            "wpweekly-episode-304-desktopserver-life-and-health-with",
            "wpweekly-episode-303-interview-with-zac-gordon-technology",
            "wpweekly-episode-302-brian-gardner-founder-of-studiopress",
            "wpweekly-episode-301-wordpress-in-highered-accessibility-and",
            "wpweekly-episode-300-interview-with-matt-gutenbeard-mullenweg",
            "wpweekly-episode-297-wordcamp-us-2017-recap",
            "wpweekly-episode-284-catching-up-with-david-peralty",
            "wpweekly-episode-282-talking-woocommerce-with-cody-landefeld",
            "wpweekly-episode-280-behind-the-scenes-of-tuniversity",
            "wpweekly-episode-279-the-future-of-underscores-with",
            "matt-mullenweg-discusses-core-focuses-downsides-of-a",
            "lifted-a-wordpress-theme-and-plugin-shop-for",
            "wpweekly-episode-276-interview-with-jon-brown-a",
            "wpweekly-episode-273-mental-health-awareness-with-bridget",
            "wpweekly-episode-272-interview-with-james-farmer-co",
            "wpweekly-episode-271-recapping-wordcamp-chicago-2017-with",
            "wpweekly-episode-269-interview-with-daniel-ha-ceo",
            "wpweekly-episode-268-behind-the-scenes-of-wordpress",
            "wpweekly-episode-267-interview-with-aaron-d-campbell",
            "wpweekly-episode-265-interview-with-matt-medeiros",
            "wpweekly-episode-262-interview-with-morten-rand-hendriksen",
            "wpweekly-episode-261-wordpress-for-schools-with-cameron",
            "wpweekly-episode-256-interview-with-tony-perez-ceo",
            "wpweekly-episode-255-all-about-the-customizer",
            "wpweekly-episode-252-flywheel-hosting-three-years-later",
            "wpweekly-episode-250-interview-with-matt-cromwell-head",
            "wpweekly-episode-247-interview-with-marc-benzakein-operations",
            "wpweekly-episode-246-interview-with-gabriel-mays-head",
            "wpweekly-episode-244-myths-lies-and-the-truth",
            "wpweekly-episode-242-interview-with-eric-meyer",
            "wpweekly-episode-240-interview-with-matt-mullenweg-2016",
            "wpweekly-episode-238-interview-with-adam-warner-sitelocks",
            "wpweekly-episode-235-interview-with-james-giroux-envatos",
            "wpweekly-episode-231-an-inside-look-at-the",
            "wpweekly-episode-230-interview-with-mike-schroder-wordpress",
            "mendel-kurland-interviews-konstantin-obenland-at-wordcamp-london",
            "wpweekly-episode-227-the-heropress-story-with-topher",
            "wpweekly-episode-225-interview-with-scott-kingsley-clark",
            "joshua-strebel-interviews-alex-king-10-days-before",
            "joshua-strebel-interviews-alex-king-10-days-before-0"
        ]
    },
    "wordcamp-eu": {
        "name": "wordcamp eu",
        "list": [
            "wpweekly-episode-321-recap-of-wordcamp-eu-2018",
            "watch-wordcamp-eu-for-free-via-livestream-0",
            "watch-wordcamp-eu-for-free-via-livestream"
        ]
    },
    "wp-rig": {
        "name": "wp rig",
        "list": [
            "wpweekly-episode-321-recap-of-wordcamp-eu-2018",
            "wp-rig-a-wordpress-starter-theme-and-build"
        ]
    },
    "build-process": {
        "name": "build process",
        "list": [
            "wp-rig-a-wordpress-starter-theme-and-build"
        ]
    },
    "optimization": {
        "name": "optimization",
        "list": [
            "wp-rig-a-wordpress-starter-theme-and-build",
            "wpweekly-episode-320-building-a-sustainable-web-0",
            "wpweekly-episode-320-building-a-sustainable-web",
            "why-some-wordpress-plugins-leave-orphaned-tables-in"
        ]
    },
    "starter-theme": {
        "name": "starter theme",
        "list": [
            "wp-rig-a-wordpress-starter-theme-and-build"
        ]
    },
    "contributor-day": {
        "name": "contributor day",
        "list": [
            "wordcamp-europe-2018-contributor-day-posts-record-turnout"
        ]
    },
    "customizer": {
        "name": "customizer",
        "list": [
            "gutenberg-team-panel-talks-release-timeline-theme-building-0",
            "gutenberg-team-panel-talks-release-timeline-theme-building",
            "wordpress-49-released-with-major-improvements-to-customizer",
            "wordpress-49-adds-scheduling-drafts-and-front-end",
            "wordpress-49-to-focus-on-code-editing-and",
            "customize-snapshots-060-adds-the-ability-to-name",
            "wpweekly-episode-274-wordpress-commercials-storefront-and-the",
            "wordpress-48-increases-maximum-width-of-the-customizer",
            "initial-customizer-survey-results-reveal-majority-of-respondents",
            "matt-mullenweg-announces-tech-and-design-leads-for",
            "wpweekly-episode-255-all-about-the-customizer",
            "wordpress-passes-27-market-share-banks-on-customizer",
            "visible-edit-shortcuts-in-wordpress-47-makes-customizing",
            "a-new-way-to-search-preview-and-install",
            "a-preview-of-the-custom-css-editor-added",
            "wordpress-47-to-ship-with-infrastructure-from-the",
            "the-days-of-creating-child-themes-for-simple",
            "wordpresscom-introduces-content-options-customizer-panel-plans-to",
            "two-distinct-approaches-aimed-at-making-site-customization",
            "customize-snapshots-050-introduces-scheduled-publishing-and-frontend",
            "set-a-highlight-color-for-wordpress-content-with",
            "new-wordpress-feature-proposal-adds-content-authorship-to",
            "ahmad-awais-releases-wordpress-customizer-package-for-sublime",
            "customize-posts-plugin-and-selective-refresh-are-paving",
            "wpweekly-episode-228-communication-is-key",
            "draft-and-save-customizer-changes-for-later-with",
            "get-your-widgets-ready-for-wordpress-45",
            "write-css-in-the-customizer-with-the-advanced",
            "customizer-responsive-preview-and-selective-refresh-to-be"
        ]
    },
    "sustainability": {
        "name": "sustainability",
        "list": [
            "wpweekly-episode-320-building-a-sustainable-web-0",
            "wpweekly-episode-320-building-a-sustainable-web",
            "wpweekly-episode-319-the-gutenberg-plugin-turns-31",
            "wpweekly-episode-319-the-gutenberg-plugin-turns-30",
            "sustainability-wordpress-sustywp"
        ]
    },
    "troubleshooting": {
        "name": "troubleshooting",
        "list": [
            "plugin-detective-wins-wordcamp-orange-countys-2018-plugin",
            "plugin-detective-wins-wordcamp-orange-countys-2018-plugin-0"
        ]
    },
    "wordcamp-orange-county": {
        "name": "wordcamp orange county",
        "list": [
            "plugin-detective-wins-wordcamp-orange-countys-2018-plugin",
            "plugin-detective-wins-wordcamp-orange-countys-2018-plugin-0",
            "wordcamp-orange-county-plugin-a-palooza-first-place"
        ]
    },
    "microsoft": {
        "name": "microsoft",
        "list": [
            "wpweekly-episode-319-the-gutenberg-plugin-turns-31",
            "wpweekly-episode-319-the-gutenberg-plugin-turns-30",
            "new-plugin-uses-microsofts-computer-vision-api-to"
        ]
    },
    "simplepress": {
        "name": "simple:press",
        "list": [
            "wpweekly-episode-319-the-gutenberg-plugin-turns-31",
            "wpweekly-episode-319-the-gutenberg-plugin-turns-30"
        ]
    },
    "adoption": {
        "name": "adoption",
        "list": [
            "simplepress-forum-plugin-is-up-for-adoption"
        ]
    },
    "business": {
        "name": "business",
        "list": [
            "simplepress-forum-plugin-is-up-for-adoption",
            "from-building-wordpress-sites-to-selling-plugins-in",
            "customers-still-in-the-dark-concerning-the-future",
            "cory-miller-and-matt-danner-launch-new-business"
        ]
    },
    "forums": {
        "name": "forums",
        "list": [
            "simplepress-forum-plugin-is-up-for-adoption",
            "wpweekly-episode-310-community-management-php-and-hello",
            "bbpress-259-patches-cross-site-scripting-vulnerability"
        ]
    },
    "ios": {
        "name": "ios",
        "list": [
            "wordcamp-for-ios-renamed-to-wp-camps-more-0",
            "wordcamp-for-ios-renamed-to-wp-camps-more",
            "marcel-schmitz-releases-unofficial-wordcamp-for-ios-app",
            "wordpress-for-ios-adds-people-and-user-role"
        ]
    },
    "wp-camps": {
        "name": "wp camps",
        "list": [
            "wordcamp-for-ios-renamed-to-wp-camps-more-0",
            "wordcamp-for-ios-renamed-to-wp-camps-more"
        ]
    },
    "sustywp": {
        "name": "sustywp",
        "list": [
            "sustainability-wordpress-sustywp"
        ]
    },
    "wordpress": {
        "name": "wordpress",
        "list": [
            "sustainability-wordpress-sustywp",
            "scott-bolinger-shares-unique-perspective-of-wordpress-from"
        ]
    },
    "community": {
        "name": "community",
        "list": [
            "community-spotlight-james-huff-macmanx",
            "wpweekly-episode-310-community-management-php-and-hello",
            "wordcamp-us-to-experiment-with-a-community-bazaar",
            "cape-town-to-host-4th-annual-wordpress-charity",
            "wphugs-a-community-devoted-to-educating-discussing-and",
            "wordpress-plugin-directory-redesign-why-so-many-people",
            "help-jesse-petersen-and-his-family-by-donating",
            "why-are-you-thankful-for-wordpress",
            "john-james-jacoby-publishes-35-part-tweetstorm-on",
            "wordcamp-organizers-get-new-tool-for-creating-personalized"
        ]
    },
    "spotlight": {
        "name": "spotlight",
        "list": [
            "community-spotlight-james-huff-macmanx"
        ]
    },
    "support": {
        "name": "support",
        "list": [
            "community-spotlight-james-huff-macmanx",
            "wordpress-support-team-to-host-free-workshop-august",
            "headway-389-patches-potential-xss-vulnerability",
            "commercial-wordpress-product-descriptions-can-mislead-customers-into",
            "how-authors-with-plugins-in-the-official-directory",
            "wordpressorg-support-forums-adds-accessibility-section",
            "a-tip-for-convincing-customers-to-renew-license"
        ]
    },
    "15": {
        "name": "15",
        "list": [
            "wpweekly-episode-318-happy-15th-birthday-wordpress-070",
            "the-first-release-of-wordpress-turns-15-years",
            "wordpress-turns-15-years-old"
        ]
    },
    "birthday": {
        "name": "birthday",
        "list": [
            "wpweekly-episode-318-happy-15th-birthday-wordpress-070",
            "the-first-release-of-wordpress-turns-15-years",
            "wpweekly-episode-313-buddypress-gutenberg-and-an-upcoming",
            "10up-turns-seven",
            "wordpress-turns-15-years-old",
            "wpweekly-episode-275-the-javascript-framework-rabbit-hole",
            "in-case-you-missed-it-issue-20",
            "in-case-you-missed-it-issue-10",
            "wpweekly-episode-236-wordpress-turns-13-years-old",
            "jetpack-turns-5-and-celebrates-with-a-new",
            "in-case-you-missed-it-issue-3"
        ]
    },
    "release-history": {
        "name": "release history",
        "list": [
            "wpweekly-episode-318-happy-15th-birthday-wordpress-070"
        ]
    },
    "wordpress-070": {
        "name": "wordpress 0.70",
        "list": [
            "wpweekly-episode-318-happy-15th-birthday-wordpress-070"
        ]
    },
    "blacklist": {
        "name": "blacklist",
        "list": [
            "one-way-to-whitelist-and-blacklist-blocks-in"
        ]
    },
    "whitelist": {
        "name": "whitelist",
        "list": [
            "one-way-to-whitelist-and-blacklist-blocks-in"
        ]
    },
    "2018": {
        "name": "2018",
        "list": [
            "wordcamp-us-2018-is-accepting-speaker-proposals-until"
        ]
    },
    "speakers": {
        "name": "speakers",
        "list": [
            "wordcamp-us-2018-is-accepting-speaker-proposals-until",
            "wpweekly-episode-287-wordpress-meetups-events-and-wordcamps"
        ]
    },
    "wordcamp-us": {
        "name": "wordcamp us",
        "list": [
            "wordcamp-us-2018-is-accepting-speaker-proposals-until",
            "wordcamp-us-2017-is-livestreaming-all-sessions-for",
            "results-from-the-2017-wordpress-user-survey-are",
            "wordcamp-us-to-experiment-with-a-community-bazaar",
            "interview-with-wordcamp-us-2017-organizers-dustin-meza",
            "wordcamp-us-2017-ramps-up-ticket-sales-organizers",
            "wpweekly-episode-255-all-about-the-customizer",
            "pantheons-100k-wordcamp-us-sponsorship-revoked-the-night",
            "state-of-the-word-2016-mullenweg-pushes-calypso",
            "elizabeth-shilling-awarded-the-kim-parsell-memorial-scholarship",
            "wpweekly-episode-254-wp-ecommerce-wordcamp-us-2017",
            "nashville-to-host-wordcamp-us-2017-2018",
            "wpweekly-episode-253-buddypress-28-wordcamp-us-and",
            "wordcamp-us-live-stream-tickets-now-available",
            "lizz-ehrenpreis-wins-kinstas-1500-travel-scholarship",
            "the-deadline-to-apply-for-the-kim-parsell",
            "kinsta-to-award-1500-travel-scholarship-for-wordcamp",
            "wordcamp-us-calls-for-volunteers-organizers-estimate-3000",
            "wordcamp-us-2016-speaker-applications-now-open"
        ]
    },
    "anniversary": {
        "name": "anniversary",
        "list": [
            "the-first-release-of-wordpress-turns-15-years",
            "wordcamp-miami-celebrates-its-10th-consecutive-year-march"
        ]
    },
    "gdpr": {
        "name": "GDPR",
        "list": [
            "wpweekly-episode-317-minor-major-major-minor-release",
            "wordpress-496-released-with-user-data-export-and",
            "wordpress-496-rc1-released",
            "wordpress-496-beta-1-adds-tools-for-gdpr",
            "jetpack-61-now-with-even-more-privacy-information",
            "plugins-hosted-on-wordpressorg-can-no-longer-guarantee",
            "wpweekly-episode-312-dragon-drop-wordpress-accessibility-statement",
            "jetpack-60-takes-steps-towards-gdpr-compliance",
            "wpweekly-episode-306-amp-gdpr-and-brewing-beer",
            "new-team-forms-to-facilitate-gdpr-compliance-in",
            "wpweekly-episode-298-gdpr-user-privacy-and-more",
            "delete-me-wordpress-plugin-assists-website-owners-in",
            "gdpr-for-wordpress-project-gains-momentum-proposal-receives",
            "gdpr-for-wordpress-project-seeks-to-provide-a",
            "gravity-forms-stop-entries-plugin-aims-to-help",
            "wordpress-telemetry-proposal-addresses-long-standing-privacy-concerns"
        ]
    },
    "magento": {
        "name": "magento",
        "list": [
            "wpweekly-episode-317-minor-major-major-minor-release"
        ]
    },
    "trademarks": {
        "name": "trademarks",
        "list": [
            "wpweekly-episode-317-minor-major-major-minor-release",
            "wpweekly-episode-284-catching-up-with-david-peralty",
            "trademark-trial-and-appeal-board-dismisses-automattics-trademark",
            "wpweekly-episode-234-all-things-wordcamp-with-andrea",
            "automattic-is-protecting-its-woo-woothemes-and-woocommerce"
        ]
    },
    "496": {
        "name": "4.9.6",
        "list": [
            "why-sites-didnt-automatically-update-to-wordpress-496"
        ]
    },
    "auto-updates": {
        "name": "auto updates",
        "list": [
            "why-sites-didnt-automatically-update-to-wordpress-496",
            "wordpress-494-fixes-critical-auto-update-bug-in"
        ]
    },
    "app": {
        "name": "app",
        "list": [
            "marcel-schmitz-releases-unofficial-wordcamp-for-ios-app"
        ]
    },
    "privacy": {
        "name": "privacy",
        "list": [
            "wordpress-496-released-with-user-data-export-and",
            "wordpress-496-beta-1-adds-tools-for-gdpr",
            "jetpack-61-now-with-even-more-privacy-information",
            "jetpack-60-takes-steps-towards-gdpr-compliance",
            "new-team-forms-to-facilitate-gdpr-compliance-in",
            "wpweekly-episode-298-gdpr-user-privacy-and-more",
            "playing-the-role-of-online-reputation-manager",
            "uk-home-secretary-amber-rudd-links-wordpresscom-to",
            "solving-the-mystery-of-how-people-actually-use",
            "wordpress-telemetry-proposal-addresses-long-standing-privacy-concerns",
            "what-wordpressorg-does-with-the-data-it-collects"
        ]
    },
    "wordpress-496": {
        "name": "wordpress 4.9.6",
        "list": [
            "wordpress-496-released-with-user-data-export-and",
            "wpweekly-episode-316-stone-cold-wordpress"
        ]
    },
    "alex-mills": {
        "name": "alex mills",
        "list": [
            "wpweekly-episode-316-stone-cold-wordpress"
        ]
    },
    "gadwp": {
        "name": "GADWP",
        "list": [
            "wpweekly-episode-316-stone-cold-wordpress"
        ]
    },
    "human-made": {
        "name": "human made",
        "list": [
            "wpweekly-episode-316-stone-cold-wordpress",
            "in-case-you-missed-it-issue-19",
            "human-made-is-giving-away-two-full-scholarships",
            "a-week-of-rest-developer-workshop-to-be",
            "a-week-of-rest-wordpress-rest-api-developer",
            "in-case-you-missed-it-issue-5"
        ]
    },
    "medium": {
        "name": "medium",
        "list": [
            "wpweekly-episode-316-stone-cold-wordpress",
            "medium-opens-partner-program-allows-anyone-to-publish",
            "user-experience-tests-show-gutenbergs-ui-elements-can",
            "wpweekly-episode-284-catching-up-with-david-peralty",
            "publishers-are-moving-back-to-wordpress-after-short",
            "medium-aims-to-fix-broken-media-with-new",
            "wordpresscom-announces-new-importer-for-medium-posts",
            "improving-the-user-experience-by-rearranging-the-wordpress"
        ]
    },
    "plugin-directory": {
        "name": "plugin directory",
        "list": [
            "to-free-up-resources-wordpressorg-plugin-review-team",
            "wordpress-plugin-directory-restores-stats-and-links-to",
            "wordpress-plugin-directory-redesign-why-so-many-people",
            "community-created-mockups-suggest-improvements-to-the-wordpress",
            "new-wordpress-plugin-directory-now-in-open-beta"
        ]
    },
    "slugs": {
        "name": "slugs",
        "list": [
            "to-free-up-resources-wordpressorg-plugin-review-team",
            "buddypress-29-adds-ability-to-safely-edit-a"
        ]
    },
    "unused-plugins": {
        "name": "unused plugins",
        "list": [
            "to-free-up-resources-wordpressorg-plugin-review-team"
        ]
    },
    "releases": {
        "name": "releases",
        "list": [
            "wordpress-496-rc1-released",
            "the-wow-factor-in-major-wordpress-releases-is"
        ]
    },
    "wordpress-496-rc1": {
        "name": "wordpress 4.9.6 rc1",
        "list": [
            "wordpress-496-rc1-released"
        ]
    },
    "woocommerce": {
        "name": "woocommerce",
        "list": [
            "wpweekly-episode-315-wordpress-496-gutenberg-and-stolen",
            "wpweekly-episode-312-dragon-drop-wordpress-accessibility-statement",
            "wpweekly-episode-304-desktopserver-life-and-health-with",
            "woocommerce-331-released-addresses-template-conflicts",
            "woocommerce-33-removed-from-plugin-directory-due-to",
            "woocommerce-33-increases-theme-compatibility-auto-regenerates-thumbnails",
            "wpweekly-episode-295-turkey-with-a-side-of",
            "woocommerce-explores-the-possibilities-and-challenges-for-e",
            "watch-the-state-of-the-woo-after-you",
            "new-dispensary-details-plugin-for-woocommerce-adds-cannabis",
            "wpweekly-episode-292-recap-of-wooconf-and-cabopress",
            "woocommerce-retires-canvas-theme-recommends-customers-migrate-to",
            "woocommerce-stores-on-track-to-surpass-10b-in",
            "wpweekly-episode-291-all-hands-on-deck-on",
            "woocommerce-32-adds-ability-to-apply-coupons-in",
            "wooconf-2017-livestream-tickets-now-on-sale",
            "wpweekly-episode-289-where-did-wordpress-ease-of",
            "scott-bolinger-shares-unique-perspective-of-wordpress-from",
            "woocommerce-32-to-introduce-pre-update-extension-version",
            "wpweekly-episode-285-not-every-wordpress-is-the",
            "woocommerce-forks-select2-releases-selectwoo-as-a-drop",
            "wpweekly-episode-282-talking-woocommerce-with-cody-landefeld",
            "woocommerce-31-adds-new-csv-product-importer-exporter",
            "woocommerce-drops-50-renewal-discount-on-subscriptions",
            "storefront-220-released-includes-design-refresh-and-major",
            "seattle-to-host-wooconf-2017-in-october-conference",
            "wpweekly-episode-270-going-camp-press-with-mendel",
            "woocommerce-30-brings-major-improvements-to-product-gallery",
            "wpweekly-episode-267-interview-with-aaron-d-campbell",
            "woocommerce-300-scheduled-for-release-april-4th",
            "logging-into-woocommercecom-now-requires-a-wordpresscom-account",
            "wpweekly-episode-257-my-side-project-wordpress-47",
            "woocommerce-powers-42-of-all-online-stores",
            "studiopress-puts-woocommerce-compatibility-on-the-roadmap-for",
            "woocommerce-releases-square-integration-to-sync-online-and",
            "woothemescom-domain-redirected-as-woocommerce-takes-front-seat",
            "wpweekly-episode-238-interview-with-adam-warner-sitelocks",
            "woocommerce-26-introduces-shipping-zones-and-a-new",
            "automattic-is-protecting-its-woo-woothemes-and-woocommerce",
            "woocommerce-releases-storefront-20-with-major-improvements-to",
            "automattic-introduces-woocommerce-connect-hosted-components-for-e",
            "in-case-you-missed-it-issue-7",
            "do-the-woo-a-new-podcast-for-woocommerce",
            "stripe-payment-gateway-for-woocommerce-is-now-available",
            "10up-open-sources-elasticpress-plugin-for-woocommerce",
            "paypal-for-woocommerce-how-andrew-angell-is-building",
            "early-bird-tickets-for-wooconf-2016-now-on"
        ]
    },
    "wordcamp-retreat": {
        "name": "wordcamp retreat",
        "list": [
            "wpweekly-episode-315-wordpress-496-gutenberg-and-stolen",
            "recap-of-attending-the-first-wordcamp-retreat"
        ]
    },
    "wordpress-496-beta-1": {
        "name": "wordpress 4.9.6 beta 1",
        "list": [
            "wpweekly-episode-315-wordpress-496-gutenberg-and-stolen"
        ]
    },
    "guest-post": {
        "name": "guest post",
        "list": [
            "recap-of-attending-the-first-wordcamp-retreat",
            "why-gutenberg-and-why-now",
            "10-lessons-learned-from-five-years-of-selling",
            "content-creation-is-about-more-than-an-editor"
        ]
    },
    "beta": {
        "name": "beta",
        "list": [
            "wordpress-496-beta-1-adds-tools-for-gdpr",
            "noteworthy-changes-coming-in-wordpress-495",
            "wordpress-49-beta-4-removes-try-gutenberg-call",
            "wordpress-481-adds-a-dedicated-custom-html-widget",
            "versionpress-40-beta-adds-user-editable-location-for",
            "disqus-30-beta-improves-comment-syncing",
            "what-to-expect-in-wordpress-48",
            "wordpress-46-beta-1-is-available-for-testing",
            "new-wordpress-plugin-directory-now-in-open-beta"
        ]
    },
    "data": {
        "name": "data",
        "list": [
            "wordpress-496-beta-1-adds-tools-for-gdpr",
            "freemius-launches-insights-for-wordpress-themes",
            "solving-the-mystery-of-how-people-actually-use",
            "blogvault-security-breach-infects-customers-sites-with-malware",
            "year-in-wp-creates-a-personalized-review-of",
            "what-wordpressorg-does-with-the-data-it-collects"
        ]
    },
    "jetpack": {
        "name": "jetpack",
        "list": [
            "jetpack-61-now-with-even-more-privacy-information",
            "wpweekly-episode-314-getting-squeebly-with-it",
            "jetpack-60-takes-steps-towards-gdpr-compliance",
            "wpweekly-episode-307-thirty-percent-of-the-web",
            "wpweekly-episode-305-10up-javascript-for-wordpress-conference",
            "jetpack-58-adds-lazy-loading-for-images-module",
            "consultants-are-wordpress-boots-on-the-ground",
            "jetpack-55-removes-syntax-highlighting-and-gallery-widget",
            "woocommerce-stores-on-track-to-surpass-10b-in",
            "jetpack-54-introduces-beta-version-of-new-search",
            "wordpresscom-adds-google-photos-integration-available-now-for",
            "jetpack-53-adds-php-71-compatibility-better-control",
            "jetpack-52-brings-major-improvements-to-the-contact",
            "wpweekly-episode-282-talking-woocommerce-with-cody-landefeld",
            "jetpack-professional-plan-introduces-unlimited-access-to-200",
            "wordpresscom-introduces-scheduling-for-social-media-posts",
            "quick-tip-how-to-access-jetpacks-alternative-module",
            "jetpack-49-introduces-eu-cookie-law-banner-widget",
            "blog-helper-an-alexa-skill-for-managing-a",
            "jetpack-48-introduces-settings-redesign-adds-global-wordpresscom",
            "wordpress-app-for-android-adds-better-support-for",
            "jetpack-introduces-theme-installation-from-wordpresscom-sparks-controversy",
            "jetpack-45-expands-monetization-with-wordads-integration",
            "w3techs-ranks-wordpress-as-the-fastest-growing-cms",
            "wordpresscom-launches-vr-content-coming-soon-to-jetpack",
            "wordpress-passes-27-market-share-banks-on-customizer",
            "a-preview-of-the-custom-css-editor-added",
            "results-of-the-measure-jetpack-project-likely-to",
            "jetpack-43-released-features-new-reactjs-powered-admin",
            "wordpresscom-introduces-content-options-customizer-panel-plans-to",
            "jetpack-43-now-in-beta-admin-interface-rebuilt",
            "jetpack-42-released-with-performance-and-security-updates",
            "wpweekly-episode-241-wordcamp-warmup-jetpack-41-and",
            "jetpack-41-adds-telegram-and-whatsapp-sharing-buttons",
            "automattic-pushes-the-advanced-wordpress-facebook-group-giveaway",
            "jetpack-404-released-patches-3-security-vulnerabilities",
            "wpweekly-episode-237-dont-take-my-booze-away",
            "jetpack-launches-new-developer-code-reference",
            "jetpack-403-patches-a-critical-xss-vulnerability",
            "jetpack-40-released-with-ui-improvements-and-new",
            "jetpack-396-fixes-bug-that-inserts-random-vimeo",
            "jetpack-393-maintenance-release-adds-compatibility-for-wordpress",
            "jetpack-turns-5-and-celebrates-with-a-new",
            "jetpack-39-introduces-new-sitemaps-module"
        ]
    },
    "square": {
        "name": "square",
        "list": [
            "wpweekly-episode-314-getting-squeebly-with-it",
            "woocommerce-releases-square-integration-to-sync-online-and"
        ]
    },
    "theme-review-team": {
        "name": "theme review team",
        "list": [
            "wpweekly-episode-314-getting-squeebly-with-it",
            "wordpress-theme-review-team-making-progress-on-clearing",
            "jetpack-introduces-theme-installation-from-wordpresscom-sparks-controversy",
            "zerif-lite-returns-to-wordpressorg-after-5-month",
            "wordpress-theme-review-team-moves-towards-automating-review"
        ]
    },
    "weebly": {
        "name": "weebly",
        "list": [
            "wpweekly-episode-314-getting-squeebly-with-it"
        ]
    },
    "virtual-conference": {
        "name": "virtual conference",
        "list": [
            "wordsesh-5-scheduled-for-july-25th",
            "wpcampus-online-scheduled-for-january-23rd-2017"
        ]
    },
    "wordsesh": {
        "name": "wordsesh",
        "list": [
            "wordsesh-5-scheduled-for-july-25th",
            "wordsesh-4-now-available-on-video",
            "wordsesh-4-this-saturday-august-20-at-0000",
            "wpweekly-episode-239-wordcamp-europe-wordsesh-4-and",
            "wordsesh-4-scheduled-for-august-19-20"
        ]
    },
    "theme-review": {
        "name": "theme review",
        "list": [
            "wordpress-theme-review-team-launches-trusted-authors-program",
            "theme-review-changes-place-more-onus-onto-theme"
        ]
    },
    "trusted-authors": {
        "name": "trusted authors",
        "list": [
            "wordpress-theme-review-team-launches-trusted-authors-program"
        ]
    },
    "classic-editor": {
        "name": "classic editor",
        "list": [
            "a-gutenberg-migration-guide-for-developers"
        ]
    },
    "migration": {
        "name": "migration",
        "list": [
            "a-gutenberg-migration-guide-for-developers"
        ]
    },
    "buddypress": {
        "name": "BuddyPress",
        "list": [
            "wpweekly-episode-313-buddypress-gutenberg-and-an-upcoming",
            "wpweekly-episode-283-a-visit-from-st-gutenberg",
            "bbpress-26-beta-3-likely-as-team-focuses",
            "wefoster-launches-hosting-platform-catered-to-online-communities",
            "wpweekly-episode-266-clef-is-shutting-down-configuring",
            "how-to-make-buddypress-user-registration-invite-only",
            "bbpress-2511-adds-wordpress-47-compatibility",
            "wpweekly-episode-253-buddypress-28-wordcamp-us-and",
            "wpweekly-episode-229-versionpress-goes-open-source"
        ]
    },
    "webdevstudios": {
        "name": "webdevstudios",
        "list": [
            "wpweekly-episode-313-buddypress-gutenberg-and-an-upcoming",
            "wpweekly-episode-290-putting-the-rad-in-brad",
            "constant-contact-releases-official-plugin-for-wordpress"
        ]
    },
    "google": {
        "name": "google",
        "list": [
            "amp-for-wordpress-07-rc-1-released",
            "wpweekly-episode-309-all-amped-up",
            "wordpresscom-adds-google-photos-integration-available-now-for",
            "google-launches-invisible-recaptcha",
            "google-is-retiring-its-adsense-for-wordpress-plugin",
            "googles-new-perspective-project-filters-online-comments-based",
            "google-updates-amp-to-allow-sharing-of-canonical",
            "wordpresscom-adds-customization-for-amp-pages-pushes-update",
            "dennis-cooper-booted-from-blogger-relaunches-on-wordpress",
            "wpweekly-episode-245-google-envato-wpcampus-and-a",
            "google-to-penalize-pages-with-intrusive-popup-ads",
            "google-is-amping-up-mobile-search-results-as",
            "automattic-adds-amp-support-to-wordpresscom-releases-plugin"
        ]
    },
    "release-candidate": {
        "name": "release candidate",
        "list": [
            "amp-for-wordpress-07-rc-1-released",
            "wordpress-493-rescheduled-for-february-5th"
        ]
    },
    "deliciousbrains": {
        "name": "deliciousbrains",
        "list": [
            "how-delicious-brains-creates-and-releases-wordpress-plugins"
        ]
    },
    "plugins": {
        "name": "Plugins",
        "list": [
            "how-delicious-brains-creates-and-releases-wordpress-plugins",
            "from-building-wordpress-sites-to-selling-plugins-in",
            "10-lessons-learned-from-five-years-of-selling",
            "wordpresscom-experiments-with-allowing-business-plan-customers-to",
            "how-to-find-the-age-of-a-plugin",
            "wpweekly-episode-231-an-inside-look-at-the"
        ]
    },
    "resources": {
        "name": "resources",
        "list": [
            "how-delicious-brains-creates-and-releases-wordpress-plugins",
            "new-toolkit-simplifies-the-process-of-creating-gutenberg",
            "wpshout-updates-and-acquires-wphierarchycom",
            "how-to-find-the-age-of-a-plugin",
            "mark-root-wiley-publishes-free-guide-for-nonprofits"
        ]
    },
    "compatibility": {
        "name": "compatibility",
        "list": [
            "wordpress-for-ios-and-gutenberg-dont-get-along",
            "4500-plugins-need-your-help-in-determining-gutenberg"
        ]
    },
    "wordpress-for-ios": {
        "name": "WordPress for iOS",
        "list": [
            "wordpress-for-ios-and-gutenberg-dont-get-along",
            "wordpress-mobile-apps-updated-with-a-new-login",
            "new-aztec-editor-for-wordpress-mobile-apps-now",
            "edit-flow-082-released-fixes-a-number-of",
            "wpweekly-episode-232-recap-of-wordcamp-san-diego"
        ]
    },
    "permalinks": {
        "name": "permalinks",
        "list": [
            "gutenberg-27-released-adds-ability-to-edit-permalinks"
        ]
    },
    "accessibility": {
        "name": "accessibility",
        "list": [
            "wordpress-accessibility-team-is-seeking-contributors-for-its",
            "wpweekly-episode-301-wordpress-in-highered-accessibility-and",
            "woocommerce-forks-select2-releases-selectwoo-as-a-drop",
            "wpweekly-episode-279-the-future-of-underscores-with",
            "wordpress-47-improves-accessibility-by-removing-alternative-text",
            "new-wa11y-plugin-scans-wordpress-sites-for-accessibility",
            "udacity-launches-free-web-accessibility-course-built-by",
            "wordpress-46-improves-the-accessibility-of-the-tag",
            "wordpress-accessibility-team-seeks-testers-using-speech-recognition",
            "wordpressorg-support-forums-adds-accessibility-section",
            "font-awesome-cdn-now-in-beta-loads-icons",
            "font-awesome-460-adds-new-accessibility-icons-category",
            "color-safe-build-accessible-color-palettes-based-on",
            "wordpress-contributor-rian-rietveld-wins-heroes-of-accessibility",
            "wordpress-adopts-accessibility-coding-standards-for-all-new",
            "axe-an-open-source-javascript-library-for-automating",
            "your-chance-to-give-feedback-on-wordpress-accessibility"
        ]
    },
    "contribute": {
        "name": "contribute",
        "list": [
            "wordpress-accessibility-team-is-seeking-contributors-for-its"
        ]
    },
    "handbook": {
        "name": "handbook",
        "list": [
            "wordpress-accessibility-team-is-seeking-contributors-for-its"
        ]
    },
    "beta-test": {
        "name": "beta test",
        "list": [
            "buddypress-30-beta-2-released"
        ]
    },
    "buddypress-30": {
        "name": "buddypress 3.0",
        "list": [
            "buddypress-30-beta-2-released"
        ]
    },
    "nouveau": {
        "name": "nouveau",
        "list": [
            "buddypress-30-beta-2-released"
        ]
    },
    "drunken-ux": {
        "name": "drunken ux",
        "list": [
            "talking-gutenberg-on-episode-eight-of-the-drunken"
        ]
    },
    "podcast": {
        "name": "podcast",
        "list": [
            "talking-gutenberg-on-episode-eight-of-the-drunken",
            "episodes-271-280-of-wordpress-weekly-are-now",
            "tom-auger-and-greg-mount-of-agency-chat"
        ]
    },
    "compliance": {
        "name": "compliance",
        "list": [
            "plugins-hosted-on-wordpressorg-can-no-longer-guarantee"
        ]
    },
    "guidelines": {
        "name": "guidelines",
        "list": [
            "plugins-hosted-on-wordpressorg-can-no-longer-guarantee"
        ]
    },
    "legal": {
        "name": "legal",
        "list": [
            "plugins-hosted-on-wordpressorg-can-no-longer-guarantee"
        ]
    },
    "atomblocks": {
        "name": "atomblocks",
        "list": [
            "wpweekly-episode-312-dragon-drop-wordpress-accessibility-statement"
        ]
    },
    "facebook": {
        "name": "facebook",
        "list": [
            "wpweekly-episode-312-dragon-drop-wordpress-accessibility-statement",
            "facebook-is-testing-a-pay-to-play-requirement",
            "facebook-to-re-license-react-after-backlash-from",
            "wordpress-abandons-react-due-to-patents-clause-gutenberg",
            "wpweekly-episode-286-upgrading-php-facebook-not-budging",
            "facebook-isnt-budging-on-reacts-bsd-patents-license",
            "wpweekly-episode-285-not-every-wordpress-is-the",
            "petition-to-re-license-react-has-been-escalated",
            "react-users-petition-facebook-to-re-license-reactjs",
            "wpweekly-episode-275-the-javascript-framework-rabbit-hole",
            "in-case-you-missed-it-issue-15",
            "automattic-will-continue-to-use-reactjs-in-calypso",
            "wpweekly-episode-239-wordcamp-europe-wordsesh-4-and",
            "automattic-pushes-the-advanced-wordpress-facebook-group-giveaway",
            "facebook-news-feed-now-favors-articles-that-users"
        ]
    },
    "reviewers": {
        "name": "reviewers",
        "list": [
            "theme-review-changes-place-more-onus-onto-theme"
        ]
    },
    "drag-and-drop": {
        "name": "drag and drop",
        "list": [
            "gutenberg-26-introduces-drag-and-drop-block-sorting"
        ]
    },
    "26": {
        "name": "2.6",
        "list": [
            "an-update-to-my-gutenberg-experience",
            "bbpress-26-beta-3-likely-as-team-focuses",
            "bbpress-26-expected-later-this-year-two-major"
        ]
    },
    "public-post-preview": {
        "name": "public post preview",
        "list": [
            "an-update-to-my-gutenberg-experience"
        ]
    },
    "tags": {
        "name": "tags",
        "list": [
            "an-update-to-my-gutenberg-experience",
            "wordpress-46-improves-the-accessibility-of-the-tag",
            "how-authors-with-plugins-in-the-official-directory"
        ]
    },
    "organize": {
        "name": "organize",
        "list": [
            "a-wordcamp-for-organizers-is-in-the-planning"
        ]
    },
    "wordcamp-organizers": {
        "name": "wordcamp organizers",
        "list": [
            "a-wordcamp-for-organizers-is-in-the-planning",
            "wordcamp-organizers-get-new-tool-for-creating-personalized"
        ]
    },
    "code-of-conduct": {
        "name": "code of conduct",
        "list": [
            "wpweekly-episode-311-jetpack-60-wordpress-495-and",
            "in-case-you-missed-it-issue-1"
        ]
    },
    "wordpress-495": {
        "name": "wordpress 4.9.5",
        "list": [
            "wpweekly-episode-311-jetpack-60-wordpress-495-and",
            "try-gutenberg-prompt-pushed-back-to-a-later",
            "in-wordpress-495-users-will-be-two-clicks"
        ]
    },
    "495": {
        "name": "4.9.5",
        "list": [
            "wordpress-495-squashes-25-bugs"
        ]
    },
    "bugs": {
        "name": "bugs",
        "list": [
            "wordpress-495-squashes-25-bugs",
            "wordpress-493-released-fixes-34-bugs",
            "wordpress-491-released-fixes-page-template-bug",
            "workarounds-for-the-page-template-bug-in-wordpress"
        ]
    },
    "maintenance": {
        "name": "maintenance",
        "list": [
            "wordpress-495-squashes-25-bugs",
            "wordpress-493-released-fixes-34-bugs",
            "wp-site-care-acquires-wp-radius",
            "wordpress-491-released-fixes-page-template-bug",
            "wordpress-482-patches-eight-security-vulnerabilities",
            "wordpress-474-fixes-47-issues",
            "wordpress-451-fixes-12-bugs"
        ]
    },
    "try-gutenberg": {
        "name": "try gutenberg",
        "list": [
            "try-gutenberg-prompt-pushed-back-to-a-later"
        ]
    },
    "comments": {
        "name": "comments",
        "list": [
            "wpweekly-episode-310-community-management-php-and-hello",
            "how-to-whitelist-comments-in-wordpress",
            "disqus-data-breach-affects-175-million-accounts",
            "locating-restored-comments-in-wordpress-requires-detective-skills",
            "playing-the-role-of-online-reputation-manager",
            "early-results-from-nrkbetas-comment-quiz-plugin-show",
            "disqus-30-beta-improves-comment-syncing",
            "wpweekly-episode-269-interview-with-daniel-ha-ceo",
            "nrkbeta-open-sources-comment-quiz-plugin-for-wordpress",
            "googles-new-perspective-project-filters-online-comments-based",
            "disqus-hits-sites-with-unwanted-advertising-plans-to",
            "wordpress-feature-idea-add-oembed-support-to-comments",
            "wordpress-45-improves-comment-moderation-screens",
            "in-case-you-missed-it-issue-2"
        ]
    },
    "php": {
        "name": "php",
        "list": [
            "wpweekly-episode-310-community-management-php-and-hello",
            "a-plea-for-plugin-developers-to-stop-supporting",
            "wordpressorg-now-allows-plugin-authors-to-specify-a",
            "wordpressorg-to-add-new-page-educating-users-on",
            "inpsyde-open-sources-wonolog-a-monolog-based-logging",
            "buddypress-2016-survey-results-show-54-of-respondents",
            "php-56-is-now-the-most-widely-used",
            "php-7-is-now-more-widely-used-than",
            "buddypress-28-will-bump-minimum-php-requirement-to"
        ]
    },
    "user-experience": {
        "name": "user experience",
        "list": [
            "my-gutenberg-experience-thus-far",
            "locating-restored-comments-in-wordpress-requires-detective-skills",
            "managing-gravatars-in-wordpress-is-a-jarring-user"
        ]
    },
    "testing": {
        "name": "testing",
        "list": [
            "in-wordpress-495-users-will-be-two-clicks"
        ]
    },
    "innovation": {
        "name": "innovation",
        "list": [
            "why-gutenberg-and-why-now"
        ]
    },
    "cheating-uh": {
        "name": "cheating uh",
        "list": [
            "noteworthy-changes-coming-in-wordpress-495"
        ]
    },
    "hello-dolly": {
        "name": "hello dolly",
        "list": [
            "noteworthy-changes-coming-in-wordpress-495",
            "without-context-some-lyrics-inside-the-hello-dolly"
        ]
    },
    "open-web": {
        "name": "open web",
        "list": [
            "wpweekly-episode-309-all-amped-up",
            "microblog-surpasses-kickstarter-funding-goal-set-to-launch"
        ]
    },
    "xwp": {
        "name": "xwp",
        "list": [
            "wpweekly-episode-309-all-amped-up",
            "wpweekly-episode-251-amp-translation-day-2-and",
            "xwp-is-the-first-financial-sponsor-of-heropress"
        ]
    },
    "servehappy": {
        "name": "servehappy",
        "list": [
            "a-plea-for-plugin-developers-to-stop-supporting"
        ]
    },
    "firefox": {
        "name": "firefox",
        "list": [
            "how-to-disable-push-notification-requests-in-firefox",
            "goodnight-firebug",
            "new-userscript-restores-tabs-to-the-wordpress-plugin"
        ]
    },
    "notifications": {
        "name": "notifications",
        "list": [
            "how-to-disable-push-notification-requests-in-firefox",
            "how-to-check-if-installed-plugins-are-no",
            "disable-specific-wordpress-update-emails-with-the-control",
            "wpweekly-episode-231-an-inside-look-at-the",
            "the-quest-for-a-centralized-wordpress-notifications-center"
        ]
    },
    "inclusive": {
        "name": "inclusive",
        "list": [
            "without-context-some-lyrics-inside-the-hello-dolly"
        ]
    },
    "wordcamp-miami": {
        "name": "wordcamp miami",
        "list": [
            "watch-wordcamp-miami-2018-via-free-livestream",
            "wordcamp-miami-celebrates-its-10th-consecutive-year-march",
            "wordcamp-miami-2017-will-livestream-all-sessions-this",
            "wpweekly-episode-263-plugins-disappearing-wordcamp-miami-and",
            "wordcamp-miami-2017-to-host-javascript-track-ama",
            "in-case-you-missed-it-issue-4",
            "wordcamp-miami-wapuuno-cards-now-available-on-github"
        ]
    },
    "lets-encrypt": {
        "name": "let's encrypt",
        "list": [
            "lets-encrypt-wildcard-certificates-are-now-available",
            "wpweekly-episode-308-wildcard-ssl-certificates-for-all",
            "chrome-version-62-to-show-security-warnings-on",
            "wpweekly-episode-281-in-memory-of-jesse-petersen",
            "lets-encrypt-passes-100-million-certificates-issued-will",
            "more-than-50-of-web-traffic-is-now",
            "lets-encrypt-passes-20-million-active-certificates-in",
            "wordpress-will-only-recommend-hosting-companies-offering-ssl",
            "chrome-to-add-security-warning-to-http-sites",
            "lets-encrypt-passes-5-million-active-certificates",
            "how-we-fixed-the-issues-we-encountered-after",
            "sucuri-partners-with-lets-encrypt-to-offer-free",
            "lets-encrypt-is-now-out-of-beta",
            "automattic-partners-with-lets-encrypt-to-enable-https"
        ]
    },
    "ssl": {
        "name": "ssl",
        "list": [
            "lets-encrypt-wildcard-certificates-are-now-available",
            "chrome-version-62-to-show-security-warnings-on",
            "more-than-50-of-web-traffic-is-now",
            "siteground-auto-issues-lets-encrypt-certificates-for-new",
            "wordpress-will-only-recommend-hosting-companies-offering-ssl",
            "how-we-fixed-the-issues-we-encountered-after",
            "sucuri-partners-with-lets-encrypt-to-offer-free"
        ]
    },
    "wildcard": {
        "name": "wildcard",
        "list": [
            "lets-encrypt-wildcard-certificates-are-now-available"
        ]
    },
    "techcrunch": {
        "name": "techcrunch",
        "list": [
            "wpweekly-episode-308-wildcard-ssl-certificates-for-all"
        ]
    },
    "stack-overflow": {
        "name": "stack overflow",
        "list": [
            "stack-overflow-survey-respondents-still-rank-wordpress-among",
            "stack-overflow-jobs-data-shows-reactjs-skills-in",
            "stack-overflow-survey-results-show-wordpress-is-trending"
        ]
    },
    "surveys": {
        "name": "surveys",
        "list": [
            "stack-overflow-survey-respondents-still-rank-wordpress-among"
        ]
    },
    "technologies": {
        "name": "technologies",
        "list": [
            "stack-overflow-survey-respondents-still-rank-wordpress-among"
        ]
    },
    "conference": {
        "name": "conference",
        "list": [
            "wpcampus-scheduled-for-july-12-14-in-st",
            "wpweekly-episode-305-10up-javascript-for-wordpress-conference",
            "free-virtual-wordpress-for-javascript-conference-june-29th",
            "free-conference-dedicated-to-wordpress-in-higher-ed",
            "pressnomics-5-scheduled-for-april-6-8-2017",
            "loopconf-rescheduled-for-february-6-8-2017-in",
            "wordsesh-4-this-saturday-august-20-at-0000",
            "human-made-is-giving-away-two-full-scholarships",
            "my-first-impression-of-pluginscon-a-conference-dedicated",
            "the-inaugural-wpcampus-set-for-july-15-16"
        ]
    },
    "higher-ed": {
        "name": "higher ed",
        "list": [
            "wpcampus-scheduled-for-july-12-14-in-st"
        ]
    },
    "conferences": {
        "name": "conferences",
        "list": [
            "yoast-launches-fund-to-increase-speaker-diversity-at"
        ]
    },
    "diversity": {
        "name": "diversity",
        "list": [
            "yoast-launches-fund-to-increase-speaker-diversity-at"
        ]
    },
    "funds": {
        "name": "funds",
        "list": [
            "yoast-launches-fund-to-increase-speaker-diversity-at"
        ]
    },
    "yoast": {
        "name": "yoast",
        "list": [
            "yoast-launches-fund-to-increase-speaker-diversity-at",
            "wpweekly-episode-307-thirty-percent-of-the-web",
            "yoast-office-hosts-bring-your-parents-to-work",
            "yoast-seos-php-upgrade-nag-is-producing-a",
            "yoast-seo-45-urges-users-to-upgrade-to",
            "syed-balkhi-acquires-google-analytics-by-yoast-renames"
        ]
    },
    "marketshare": {
        "name": "marketshare",
        "list": [
            "wpweekly-episode-307-thirty-percent-of-the-web"
        ]
    },
    "blocks": {
        "name": "blocks",
        "list": [
            "conceptual-ideas-on-how-the-customizer-could-integrate"
        ]
    },
    "customize": {
        "name": "customize",
        "list": [
            "conceptual-ideas-on-how-the-customizer-could-integrate"
        ]
    },
    "30-percent": {
        "name": "30 percent",
        "list": [
            "wordpress-now-used-on-30-of-the-top"
        ]
    },
    "market-share": {
        "name": "market share",
        "list": [
            "wordpress-now-used-on-30-of-the-top"
        ]
    },
    "w3techs": {
        "name": "w3techs",
        "list": [
            "wordpress-now-used-on-30-of-the-top"
        ]
    },
    "cryptography": {
        "name": "cryptography",
        "list": [
            "new-plugin-makes-wordpress-core-updates-more-secure",
            "matt-mullenweg-responds-to-security-rant-digital-signatures"
        ]
    },
    "updates": {
        "name": "updates",
        "list": [
            "new-plugin-makes-wordpress-core-updates-more-secure",
            "wordpress-482-patches-eight-security-vulnerabilities",
            "disable-specific-wordpress-update-emails-with-the-control",
            "take-granular-control-of-wordpress-update-system-with"
        ]
    },
    "advanced-wordpress": {
        "name": "advanced wordpress",
        "list": [
            "matt-cromwell-hosts-matt-mullenweg-in-qa-gutenberg",
            "advanced-wordpress-facebook-group-is-giving-40k-worth"
        ]
    },
    "plugin-competition": {
        "name": "plugin competition",
        "list": [
            "wordcamp-orange-county-plugin-a-palooza-first-place"
        ]
    },
    "10up": {
        "name": "10up",
        "list": [
            "wpweekly-episode-305-10up-javascript-for-wordpress-conference",
            "10up-turns-seven",
            "distributor-plugin-now-in-beta-a-new-wordpress",
            "wpweekly-episode-281-in-memory-of-jesse-petersen",
            "10up-acquires-lift-ux",
            "10up-unveils-elasticpressio-elasticsearch-as-a-service-for",
            "10up-open-sources-elasticpress-plugin-for-woocommerce"
        ]
    },
    "seven": {
        "name": "seven",
        "list": [
            "10up-turns-seven"
        ]
    },
    "zac-gordon": {
        "name": "zac gordon",
        "list": [
            "free-virtual-wordpress-for-javascript-conference-june-29th",
            "zac-gordon-launches-gutenberg-development-course-includes-more",
            "fall-enrollment-for-zac-gordons-javascript-for-wordpress"
        ]
    },
    "elastic": {
        "name": "elastic",
        "list": [
            "jetpack-58-adds-lazy-loading-for-images-module"
        ]
    },
    "lazy-load": {
        "name": "lazy load",
        "list": [
            "jetpack-58-adds-lazy-loading-for-images-module"
        ]
    },
    "dos": {
        "name": "dos",
        "list": [
            "wpweekly-episode-304-desktopserver-life-and-health-with"
        ]
    },
    "wordpress-494": {
        "name": "wordpress 4.9.4",
        "list": [
            "wpweekly-episode-304-desktopserver-life-and-health-with"
        ]
    },
    "331": {
        "name": "3.3.1",
        "list": [
            "woocommerce-331-released-addresses-template-conflicts",
            "woocommerce-33-removed-from-plugin-directory-due-to"
        ]
    },
    "templates": {
        "name": "templates",
        "list": [
            "woocommerce-331-released-addresses-template-conflicts",
            "workarounds-for-the-page-template-bug-in-wordpress"
        ]
    },
    "themes": {
        "name": "Themes",
        "list": [
            "woocommerce-331-released-addresses-template-conflicts",
            "wordpresscoms-business-plan-gives-subscribers-a-way-to",
            "10-lessons-learned-from-five-years-of-selling",
            "wordpresscom-experiments-with-allowing-business-plan-customers-to",
            "a-new-way-to-search-preview-and-install"
        ]
    },
    "494": {
        "name": "4.9.4",
        "list": [
            "wordpress-494-fixes-critical-auto-update-bug-in"
        ]
    },
    "critical": {
        "name": "critical",
        "list": [
            "wordpress-494-fixes-critical-auto-update-bug-in"
        ]
    },
    "493": {
        "name": "4.9.3",
        "list": [
            "wordpress-493-released-fixes-34-bugs"
        ]
    },
    "ithemes": {
        "name": "ithemes",
        "list": [
            "liquid-web-acquires-ithemes-in-multi-million-dollar",
            "aj-morris-acquires-ithemes-exchange",
            "the-div-selected-by-codeorg-to-help-expand",
            "a-little-communication-goes-a-long-way",
            "wpweekly-episode-223-celebrating-8-years-of-ithemes",
            "wpweekly-episode-222-ithemes-enters-the-real-time"
        ]
    },
    "liquid-web": {
        "name": "liquid web",
        "list": [
            "liquid-web-acquires-ithemes-in-multi-million-dollar"
        ]
    },
    "wordpress-493": {
        "name": "wordpress 4.9.3",
        "list": [
            "wordpress-493-rescheduled-for-february-5th"
        ]
    },
    "33": {
        "name": "3.3",
        "list": [
            "woocommerce-33-removed-from-plugin-directory-due-to",
            "woocommerce-33-increases-theme-compatibility-auto-regenerates-thumbnails"
        ]
    },
    "education": {
        "name": "education",
        "list": [
            "wpweekly-episode-303-interview-with-zac-gordon-technology",
            "zac-gordon-launches-gutenberg-development-course-includes-more",
            "from-building-wordpress-sites-to-selling-plugins-in",
            "wpcampus-2017-will-be-streamed-live-for-free",
            "wpcampus-2017-to-take-place-july-14-15",
            "fall-enrollment-for-zac-gordons-javascript-for-wordpress",
            "linkedin-learning-is-offering-free-access-this-week",
            "wordsesh-4-scheduled-for-august-19-20",
            "the-inaugural-wpcampus-set-for-july-15-16"
        ]
    },
    "efrain-rivera": {
        "name": "efrain rivera",
        "list": [
            "efrain-rivera-a-longtime-community-member-wordcamp-organizer"
        ]
    },
    "florida": {
        "name": "florida",
        "list": [
            "efrain-rivera-a-longtime-community-member-wordcamp-organizer",
            "inuagural-cabinpress-takes-place-november-3-5-at"
        ]
    },
    "easy-updates-manager": {
        "name": "easy updates manager",
        "list": [
            "updraftplus-acquires-easy-updates-manager-plugin"
        ]
    },
    "genesis": {
        "name": "genesis",
        "list": [
            "wpweekly-episode-302-brian-gardner-founder-of-studiopress",
            "jesse-petersen-founder-of-genesis-theme-passes-away",
            "9seeds-acquires-web-savvy-marketings-genesis-theme-store"
        ]
    },
    "toolkit": {
        "name": "toolkit",
        "list": [
            "new-toolkit-simplifies-the-process-of-creating-gutenberg"
        ]
    },
    "384": {
        "name": "3.8.4",
        "list": [
            "desktopserver-384-includes-a-gift-to-the-community"
        ]
    },
    "desktopserver": {
        "name": "desktopserver",
        "list": [
            "desktopserver-384-includes-a-gift-to-the-community"
        ]
    },
    "local-development": {
        "name": "local development",
        "list": [
            "desktopserver-384-includes-a-gift-to-the-community"
        ]
    },
    "492": {
        "name": "4.9.2",
        "list": [
            "wordpress-492-patches-xss-vulnerability"
        ]
    },
    "mediaelement": {
        "name": "mediaelement",
        "list": [
            "wordpress-492-patches-xss-vulnerability"
        ]
    },
    "xss": {
        "name": "xss",
        "list": [
            "wordpress-492-patches-xss-vulnerability",
            "learn-how-to-find-and-exploit-xss-vulnerabilities",
            "wp-super-cache-149-patches-multiple-xss-vulnerabilities",
            "all-in-one-seo-237-patches-persistent-xss"
        ]
    },
    "20": {
        "name": "2.0",
        "list": [
            "gutenberg-20-released-with-numerous-accessibility-and-keyboard"
        ]
    },
    "state-of-the-word": {
        "name": "state of the word",
        "list": [
            "wpweekly-episode-300-interview-with-matt-gutenbeard-mullenweg",
            "four-things-id-like-to-see-in-this",
            "state-of-the-word-2016-mullenweg-pushes-calypso",
            "take-the-2016-wordpress-user-survey"
        ]
    },
    "roundup": {
        "name": "roundup",
        "list": [
            "a-collection-of-gutenberg-conversations-resources-and-videos"
        ]
    },
    "2017": {
        "name": "2017",
        "list": [
            "wpweekly-episode-299-2017-year-in-review"
        ]
    },
    "headlines": {
        "name": "headlines",
        "list": [
            "wpweekly-episode-299-2017-year-in-review"
        ]
    },
    "year-in-review": {
        "name": "year in review",
        "list": [
            "wpweekly-episode-299-2017-year-in-review",
            "wpweekly-episode-259-2016-year-in-review-part"
        ]
    },
    "telemetry": {
        "name": "telemetry",
        "list": [
            "wpweekly-episode-298-gdpr-user-privacy-and-more",
            "wpweekly-episode-296-gutenberg-telemetry-calypso-and-more",
            "in-case-you-missed-it-issue-23",
            "user-tracking-to-be-removed-from-gutenberg-in",
            "solving-the-mystery-of-how-people-actually-use",
            "wpweekly-episode-262-interview-with-morten-rand-hendriksen"
        ]
    },
    "wp-site-care": {
        "name": "wp site care",
        "list": [
            "wpweekly-episode-298-gdpr-user-privacy-and-more"
        ]
    },
    "wp-radius": {
        "name": "wp radius",
        "list": [
            "wp-site-care-acquires-wp-radius"
        ]
    },
    "storify": {
        "name": "storify",
        "list": [
            "wpweekly-episode-297-wordcamp-us-2017-recap",
            "storify-to-close-may-16-2018-wordpress-plugin"
        ]
    },
    "wcus2017": {
        "name": "wcus2017",
        "list": [
            "wpweekly-episode-297-wordcamp-us-2017-recap",
            "gutenberg-and-the-wordpress-of-tomorrow-by-morten"
        ]
    },
    "closing": {
        "name": "closing",
        "list": [
            "storify-to-close-may-16-2018-wordpress-plugin"
        ]
    },
    "opportunity": {
        "name": "opportunity",
        "list": [
            "storify-to-close-may-16-2018-wordpress-plugin"
        ]
    },
    "calypso": {
        "name": "calypso",
        "list": [
            "wpweekly-episode-296-gutenberg-telemetry-calypso-and-more",
            "four-things-id-like-to-see-in-this",
            "wordpress-abandons-react-due-to-patents-clause-gutenberg",
            "popular-wordpress-plugins-slow-to-add-meta-box",
            "state-of-the-word-2016-mullenweg-pushes-calypso",
            "edit-flow-082-released-fixes-a-number-of",
            "automattic-will-continue-to-use-reactjs-in-calypso",
            "in-case-you-missed-it-issue-5"
        ]
    },
    "hackerone": {
        "name": "hackerone",
        "list": [
            "wpweekly-episode-296-gutenberg-telemetry-calypso-and-more",
            "wordpress-is-now-on-hackerone-launches-bug-bounties",
            "hackerone-launches-free-community-edition-for-non-commercial",
            "bbpress-2510-patches-security-vulnerability"
        ]
    },
    "pressable": {
        "name": "pressable",
        "list": [
            "wpweekly-episode-296-gutenberg-telemetry-calypso-and-more",
            "pressable-rolls-back-database-change-that-caused-customer"
        ]
    },
    "491": {
        "name": "4.9.1",
        "list": [
            "wordpress-491-released-fixes-page-template-bug"
        ]
    },
    "distributor": {
        "name": "distributor",
        "list": [
            "distributor-plugin-now-in-beta-a-new-wordpress"
        ]
    },
    "syndication": {
        "name": "syndication",
        "list": [
            "distributor-plugin-now-in-beta-a-new-wordpress",
            "how-to-connect-your-wordpress-powered-site-to"
        ]
    },
    "wcus": {
        "name": "wcus",
        "list": [
            "four-things-id-like-to-see-in-this",
            "practicing-the-pac-man-rule-at-wordcamp-us",
            "in-case-you-missed-it-issue-22"
        ]
    },
    "engagement": {
        "name": "engagement",
        "list": [
            "practicing-the-pac-man-rule-at-wordcamp-us"
        ]
    },
    "pac-man": {
        "name": "pac-man",
        "list": [
            "practicing-the-pac-man-rule-at-wordcamp-us"
        ]
    },
    "social": {
        "name": "social",
        "list": [
            "practicing-the-pac-man-rule-at-wordcamp-us"
        ]
    },
    "usability": {
        "name": "usability",
        "list": [
            "gutenberg-team-is-ramping-up-usability-testing-at"
        ]
    },
    "thanks": {
        "name": "thanks",
        "list": [
            "wpweekly-episode-295-turkey-with-a-side-of"
        ]
    },
    "wordpress-49": {
        "name": "WordPress 4.9",
        "list": [
            "wpweekly-episode-295-turkey-with-a-side-of",
            "workarounds-for-the-page-template-bug-in-wordpress",
            "wordpress-49-released-with-major-improvements-to-customizer",
            "press-this-removed-from-wordpress-49-in-favor",
            "wpweekly-episode-293-wordpress-483-rip-firebug-and",
            "wordpress-49-will-support-shortcodes-and-embedded-media",
            "wordpress-49-beta-4-removes-try-gutenberg-call",
            "wordpress-49-protects-users-from-fatal-errors-created",
            "new-core-gallery-widget-targeted-for-wordpress-49",
            "wordpress-49-to-focus-on-managing-plugins-and"
        ]
    },
    "cache": {
        "name": "cache",
        "list": [
            "workarounds-for-the-page-template-bug-in-wordpress",
            "wp-super-cache-149-patches-multiple-xss-vulnerabilities"
        ]
    },
    "wordpress-plugin-directory": {
        "name": "wordpress plugin directory",
        "list": [
            "tide-project-aims-to-audit-and-score-wordpress",
            "wordpress-plugin-directory-restores-tabbed-interface",
            "new-wpstatsme-site-displays-wordpressorg-plugin-download-stats",
            "wordpress-relaunches-plugin-directory-with-new-design-and",
            "why-plugins-sometimes-disappear-from-the-wordpress-plugin",
            "wordpress-plugin-team-publishes-revamped-guidelines-for-plugin",
            "wordpress-plugin-team-revamps-guidelines-invites-feedback-on",
            "wordpress-plugin-directory-cracks-down-on-incentivized-reviews",
            "wordpress-plugin-review-team-to-add-new-members",
            "wordpress-theme-review-team-votes-on-new-guidelines",
            "keep-track-of-your-wordpressorg-themes-and-plugins",
            "the-wordpress-plugin-directory-will-no-longer-accept",
            "the-wordpress-plugin-directory-is-getting-a-makeover"
        ]
    },
    "envato": {
        "name": "envato",
        "list": [
            "envato-elements-adds-unlimited-wordpress-theme-and-plugin",
            "upvato-backup-service-confirms-files-are-lost-plans",
            "upvato-backup-service-terminated-by-storage-provider-files",
            "wordpress-theme-authors-experiment-with-new-pricing-on",
            "wpweekly-episode-245-google-envato-wpcampus-and-a",
            "envato-celebrates-10-years-in-business",
            "layers-ends-exclusive-arrangement-with-envato-launches-new",
            "wpweekly-episode-235-interview-with-james-giroux-envatos",
            "in-case-you-missed-it-issue-2"
        ]
    },
    "page-builders": {
        "name": "page builders",
        "list": [
            "tailor-page-builder-plugin-discontinued-owners-cite-funding",
            "how-do-you-educate-people-new-to-wordpress"
        ]
    },
    "tailor": {
        "name": "tailor",
        "list": [
            "tailor-page-builder-plugin-discontinued-owners-cite-funding"
        ]
    },
    "github": {
        "name": "github",
        "list": [
            "github-launches-security-alerts-for-javascript-and-ruby",
            "github-launches-community-forums-to-connect-developers",
            "github-launches-new-dependency-graph-feature-with-security",
            "digitalocean-partners-with-github-to-support-open-source",
            "github-introduces-temporary-interaction-limits-to-promote-healthier",
            "atom-editor-adds-git-and-github-integration",
            "github-adds-plain-english-explanations-to-license-pages",
            "bitbucket-pricing-hike-increases-cost-per-user-by",
            "github-adds-code-review-and-project-management-tools",
            "gitlab-courts-disgruntled-github-customers-with-response-to",
            "github-introduces-unlimited-private-repositories-hikes-prices-for",
            "project-owners-can-now-block-abusive-users-on",
            "github-issue-and-pull-request-templates-choose-your",
            "submit-pull-requests-to-wordpress-core-with-the",
            "github-now-supports-emoji-reactions-for-pull-requests",
            "github-introduces-issue-and-pull-request-templates",
            "wp-pusher-210-offers-tighter-integration-with-github",
            "github-responds-to-letter-from-open-source-project",
            "deployer-app-pushes-plugins-from-github-to-wordpressorg"
        ]
    },
    "growth": {
        "name": "growth",
        "list": [
            "consultants-are-wordpress-boots-on-the-ground"
        ]
    },
    "platform": {
        "name": "platform",
        "list": [
            "consultants-are-wordpress-boots-on-the-ground"
        ]
    },
    "heropress": {
        "name": "heropress",
        "list": [
            "wpweekly-episode-294-heropress-community-and-winningwp-with",
            "heropress-partners-with-wpshout-to-offer-wordpress-education",
            "in-case-you-missed-it-issue-19",
            "wpweekly-episode-251-amp-translation-day-2-and",
            "you-are-responsible-for-your-own-awesome",
            "xwp-is-the-first-financial-sponsor-of-heropress",
            "in-case-you-missed-it-issue-13",
            "heropress-publishes-essays-from-18-countries-in-its",
            "wpweekly-episode-227-the-heropress-story-with-topher",
            "in-case-you-missed-it-issue-5",
            "in-case-you-missed-it-issue-1"
        ]
    },
    "topher-derosia": {
        "name": "topher derosia",
        "list": [
            "wpweekly-episode-294-heropress-community-and-winningwp-with"
        ]
    },
    "winningwp": {
        "name": "winningwp",
        "list": [
            "wpweekly-episode-294-heropress-community-and-winningwp-with"
        ]
    },
    "ia-writer": {
        "name": "ia Writer",
        "list": [
            "ia-writer-5-for-ios-released-web-collaboration"
        ]
    },
    "marketers": {
        "name": "marketers",
        "list": [
            "watch-the-state-of-the-woo-after-you"
        ]
    },
    "state-of-the-woo": {
        "name": "state of the woo",
        "list": [
            "watch-the-state-of-the-woo-after-you"
        ]
    },
    "multilingual-wordpress": {
        "name": "multilingual wordpress",
        "list": [
            "weglot-passes-eur44k-in-monthly-revenue-plans-to",
            "weglot-multilingual-wordpress-plugin-passes-eur10000-in-monthly"
        ]
    },
    "weglot": {
        "name": "weglot",
        "list": [
            "weglot-passes-eur44k-in-monthly-revenue-plans-to",
            "weglot-multilingual-plugin-closes-eur450k-in-seed-funding",
            "weglot-multilingual-wordpress-plugin-passes-eur10000-in-monthly"
        ]
    },
    "moderation": {
        "name": "moderation",
        "list": [
            "how-to-whitelist-comments-in-wordpress"
        ]
    },
    "whitelisting": {
        "name": "whitelisting",
        "list": [
            "how-to-whitelist-comments-in-wordpress"
        ]
    },
    "meta-boxes": {
        "name": "meta boxes",
        "list": [
            "gutenberg-contributors-discuss-the-drawbacks-of-using-iframes",
            "wordpress-core-fields-api-project-sees-renewed-interest",
            "gutenberg-development-team-confirms-meta-box-api-will",
            "popular-wordpress-plugins-slow-to-add-meta-box"
        ]
    },
    "bianca-welds": {
        "name": "bianca welds",
        "list": [
            "bianca-welds-awarded-kim-parsell-travel-scholarship"
        ]
    },
    "kim-parsell": {
        "name": "kim parsell",
        "list": [
            "bianca-welds-awarded-kim-parsell-travel-scholarship",
            "elizabeth-shilling-awarded-the-kim-parsell-memorial-scholarship",
            "the-deadline-to-apply-for-the-kim-parsell"
        ]
    },
    "scholarship": {
        "name": "scholarship",
        "list": [
            "bianca-welds-awarded-kim-parsell-travel-scholarship",
            "in-case-you-missed-it-issue-22",
            "elizabeth-shilling-awarded-the-kim-parsell-memorial-scholarship",
            "lizz-ehrenpreis-wins-kinstas-1500-travel-scholarship",
            "the-deadline-to-apply-for-the-kim-parsell",
            "kinsta-to-award-1500-travel-scholarship-for-wordcamp"
        ]
    },
    "wordpress-foundation": {
        "name": "wordpress foundation",
        "list": [
            "bianca-welds-awarded-kim-parsell-travel-scholarship",
            "wordpress-foundation-to-sponsor-open-source-educational-events",
            "my-first-impression-of-pluginscon-a-conference-dedicated",
            "syed-balkhi-donates-wporg-to-the-wordpress-foundation"
        ]
    },
    "press-this": {
        "name": "press this",
        "list": [
            "press-this-removed-from-wordpress-49-in-favor"
        ]
    },
    "firebug": {
        "name": "firebug",
        "list": [
            "wpweekly-episode-293-wordpress-483-rip-firebug-and"
        ]
    },
    "patreon": {
        "name": "patreon",
        "list": [
            "wpweekly-episode-293-wordpress-483-rip-firebug-and",
            "patreon-launches-app-directory-and-free-wordpress-plugin"
        ]
    },
    "483": {
        "name": "4.8.3",
        "list": [
            "wordpress-483-a-security-release-six-weeks-in"
        ]
    },
    "disclosure": {
        "name": "disclosure",
        "list": [
            "wordpress-483-a-security-release-six-weeks-in"
        ]
    },
    "marijuana": {
        "name": "marijuana",
        "list": [
            "new-dispensary-details-plugin-for-woocommerce-adds-cannabis",
            "lifted-a-wordpress-theme-and-plugin-shop-for"
        ]
    },
    "results": {
        "name": "results",
        "list": [
            "results-from-the-2017-wordpress-user-survey-are"
        ]
    },
    "survey": {
        "name": "survey",
        "list": [
            "results-from-the-2017-wordpress-user-survey-are",
            "in-case-you-missed-it-issue-19",
            "take-the-wordpress-editor-experience-survey",
            "take-the-2016-wordpress-user-survey",
            "help-wpcampus-gather-data-on-how-schools-and"
        ]
    },
    "crowdfunding": {
        "name": "crowdfunding",
        "list": [
            "patreon-launches-app-directory-and-free-wordpress-plugin",
            "peter-meth-launches-kickstarter-campaign-to-produce-7",
            "daniel-bachhuber-discusses-wp-cli-the-wp-rest"
        ]
    },
    "media": {
        "name": "media",
        "list": [
            "wordpress-49-will-support-shortcodes-and-embedded-media",
            "pdf-image-previews-among-the-improvements-to-media"
        ]
    },
    "text-widgets": {
        "name": "text widgets",
        "list": [
            "wordpress-49-will-support-shortcodes-and-embedded-media",
            "wordpress-481-adds-a-dedicated-custom-html-widget"
        ]
    },
    "widgets": {
        "name": "widgets",
        "list": [
            "wordpress-49-will-support-shortcodes-and-embedded-media",
            "new-core-gallery-widget-targeted-for-wordpress-49",
            "wordpress-481-released-adds-custom-html-widget",
            "wordpress-48-evans-released-featuring-nearby-wordpress-events",
            "what-to-expect-in-wordpress-48",
            "adding-images-to-wordpress-sidebars-is-about-to",
            "get-your-widgets-ready-for-wordpress-45"
        ]
    },
    "cabopress": {
        "name": "cabopress",
        "list": [
            "wpweekly-episode-292-recap-of-wooconf-and-cabopress"
        ]
    },
    "wooconf": {
        "name": "wooconf",
        "list": [
            "wpweekly-episode-292-recap-of-wooconf-and-cabopress",
            "wpweekly-episode-291-all-hands-on-deck-on",
            "wooconf-2017-livestream-tickets-now-on-sale",
            "seattle-to-host-wooconf-2017-in-october-conference",
            "austin-wordpress-meetup-to-host-charity-hackathon-april",
            "wpweekly-episode-223-celebrating-8-years-of-ithemes",
            "early-bird-tickets-for-wooconf-2016-now-on"
        ]
    },
    "mozilla": {
        "name": "mozilla",
        "list": [
            "goodnight-firebug",
            "developers-urge-white-house-to-consider-open-by"
        ]
    },
    "storefront": {
        "name": "storefront",
        "list": [
            "woocommerce-retires-canvas-theme-recommends-customers-migrate-to",
            "wpweekly-episode-274-wordpress-commercials-storefront-and-the",
            "storefront-220-released-includes-design-refresh-and-major",
            "woocommerce-releases-storefront-20-with-major-improvements-to"
        ]
    },
    "camp-press": {
        "name": "camp press",
        "list": [
            "camp-press-is-coming-to-iceland-april-19",
            "camp-press-a-detox-from-digital-life",
            "wpweekly-episode-270-going-camp-press-with-mendel",
            "disconnect-from-technology-at-camp-press-september-23"
        ]
    },
    "iceland": {
        "name": "iceland",
        "list": [
            "camp-press-is-coming-to-iceland-april-19"
        ]
    },
    "clients": {
        "name": "clients",
        "list": [
            "from-building-wordpress-sites-to-selling-plugins-in",
            "brad-touesnard-on-why-clients-should-own-their"
        ]
    },
    "extensions": {
        "name": "extensions",
        "list": [
            "woocommerce-stores-on-track-to-surpass-10b-in",
            "woocommerce-drops-50-renewal-discount-on-subscriptions"
        ]
    },
    "chrome": {
        "name": "chrome",
        "list": [
            "google-chrome-v62-adds-support-for-opentype-variable",
            "wordpress-474-fixes-47-issues",
            "chrome-to-add-security-warning-to-http-sites",
            "wordpress-admin-switcher-a-new-google-chrome-extension",
            "wordpress-451-expected-early-next-week"
        ]
    },
    "opentype-font-variations": {
        "name": "OpenType Font Variations",
        "list": [
            "google-chrome-v62-adds-support-for-opentype-variable"
        ]
    },
    "godaddy": {
        "name": "godaddy",
        "list": [
            "godaddy-launches-new-managed-wordpress-hosting-platform-aimed",
            "ostraining-partners-with-godaddy-to-launch-free-wordpress",
            "godaddy-acquires-wp-curve-aims-to-become-a",
            "wordpress-passes-27-market-share-banks-on-customizer",
            "managewp-launches-automated-security-scanning",
            "wpweekly-episode-248-insight-into-the-managewp-acquisition",
            "godaddy-launches-new-onboarding-experience-for-wordpress-customers",
            "godaddy-acquires-wordpress-site-management-service-managewp",
            "wpweekly-episode-246-interview-with-gabriel-mays-head"
        ]
    },
    "managed-wordpress-hosting": {
        "name": "managed wordpress hosting",
        "list": [
            "godaddy-launches-new-managed-wordpress-hosting-platform-aimed",
            "pagely-celebrates-7-years-of-managed-wordpress-hosting",
            "wp-engine-adds-2fa-to-user-portal-opt"
        ]
    },
    "bear": {
        "name": "bear",
        "list": [
            "bear-app-users-want-wordpress-publishing-integration"
        ]
    },
    "distraction-free-writing": {
        "name": "distraction free writing",
        "list": [
            "bear-app-users-want-wordpress-publishing-integration",
            "wordpresscom-updates-its-post-editor-with-a-distraction"
        ]
    },
    "codemirror": {
        "name": "codemirror",
        "list": [
            "wordpress-49-protects-users-from-fatal-errors-created"
        ]
    },
    "editors": {
        "name": "editors",
        "list": [
            "wordpress-49-protects-users-from-fatal-errors-created",
            "why-gutenberg"
        ]
    },
    "webpack": {
        "name": "webpack",
        "list": [
            "wordpress-replaces-browserify-with-webpack-for-build-process"
        ]
    },
    "disqus": {
        "name": "disqus",
        "list": [
            "wpweekly-episode-291-all-hands-on-deck-on",
            "disqus-30-beta-improves-comment-syncing",
            "wpweekly-episode-269-interview-with-daniel-ha-ceo",
            "wpweekly-episode-264-rest-api-disqus-and-happy",
            "disqus-hits-sites-with-unwanted-advertising-plans-to",
            "disqus-adds-support-for-akismet"
        ]
    },
    "gitlab": {
        "name": "gitlab",
        "list": [
            "gitlab-raises-20-million-series-c-round-adds",
            "gitlab-raises-20-million-series-b-funding",
            "koding-open-sources-cloud-based-ide-partners-with",
            "gitlab-courts-disgruntled-github-customers-with-response-to",
            "github-responds-to-letter-from-open-source-project"
        ]
    },
    "draft": {
        "name": "draft",
        "list": [
            "wordpress-49-adds-scheduling-drafts-and-front-end"
        ]
    },
    "preview": {
        "name": "preview",
        "list": [
            "wordpress-49-adds-scheduling-drafts-and-front-end",
            "a-new-way-to-search-preview-and-install"
        ]
    },
    "schedule": {
        "name": "schedule",
        "list": [
            "wordpress-49-adds-scheduling-drafts-and-front-end"
        ]
    },
    "documentation": {
        "name": "documentation",
        "list": [
            "wpthemedoc-a-single-file-html-template-for-documenting"
        ]
    },
    "passwords": {
        "name": "passwords",
        "list": [
            "disqus-data-breach-affects-175-million-accounts",
            "cloudflare-memory-leak-exposes-private-data"
        ]
    },
    "sandbox": {
        "name": "sandbox",
        "list": [
            "poopylife-launches-pro-version-at-wpsandboxio-aimed-at"
        ]
    },
    "donatewc": {
        "name": "donatewc",
        "list": [
            "donatewc-successfully-sponsors-its-first-applicant-to-wordcamp",
            "wpweekly-episode-289-where-did-wordpress-ease-of",
            "donatewc-reaches-fundraising-goal"
        ]
    },
    "donations": {
        "name": "donations",
        "list": [
            "donatewc-successfully-sponsors-its-first-applicant-to-wordcamp",
            "donatewc-aims-to-provide-travel-sponsorships-to-attend"
        ]
    },
    "camppress": {
        "name": "camppress",
        "list": [
            "wpweekly-episode-290-putting-the-rad-in-brad"
        ]
    },
    "five-for-the-future": {
        "name": "five for the future",
        "list": [
            "wpweekly-episode-290-putting-the-rad-in-brad"
        ]
    },
    "elasticsearch": {
        "name": "elasticsearch",
        "list": [
            "jetpack-54-introduces-beta-version-of-new-search",
            "10up-unveils-elasticpressio-elasticsearch-as-a-service-for"
        ]
    },
    "wordpresscom-vip": {
        "name": "wordpress.com vip",
        "list": [
            "jetpack-54-introduces-beta-version-of-new-search"
        ]
    },
    "drupal": {
        "name": "drupal",
        "list": [
            "drupal-core-maintainers-propose-adopting-react-for-administrative",
            "in-case-you-missed-it-issue-13"
        ]
    },
    "wp-cli": {
        "name": "wp-cli",
        "list": [
            "new-wp-cli-project-aims-to-extend-checksum",
            "wp-cli-120-released-project-unveils-new-logo",
            "wp-cli-names-alain-schlesser-new-co-maintainer",
            "wp-cli-110-released-project-shifts-to-expand",
            "wp-cli-gets-official-wordpressorg-support",
            "wp-cli-project-launches-patron-support-model-to",
            "wp-cli-gui-an-interface-to-speed-up",
            "wp-cli-contributors-work-towards-a-more-sustainable",
            "wp-cli-024-will-deprecate-wp-settings-cliphp",
            "daniel-bachhuber-discusses-wp-cli-the-wp-rest",
            "versions-of-wp-cli-prior-to-0230-are"
        ]
    },
    "hacktoberfest": {
        "name": "hacktoberfest",
        "list": [
            "digitalocean-partners-with-github-to-support-open-source"
        ]
    },
    "git": {
        "name": "git",
        "list": [
            "a-very-brief-introduction-to-version-control-and",
            "take-the-2016-git-users-survey",
            "linus-torvalds-explains-how-open-source-led-to",
            "3-signs-your-wordpress-development-team-is-not",
            "versionpress-transitions-into-a-free-open-source-project"
        ]
    },
    "version-control": {
        "name": "version control",
        "list": [
            "a-very-brief-introduction-to-version-control-and"
        ]
    },
    "apply-filters": {
        "name": "Apply Filters",
        "list": [
            "wpweekly-episode-289-where-did-wordpress-ease-of",
            "apply-filters-podcast-to-be-retired-after-83",
            "matt-mullenweg-discusses-core-focuses-downsides-of-a"
        ]
    },
    "shopify": {
        "name": "shopify",
        "list": [
            "wpweekly-episode-289-where-did-wordpress-ease-of",
            "scott-bolinger-shares-unique-perspective-of-wordpress-from",
            "wpweekly-episode-271-recapping-wordcamp-chicago-2017-with",
            "shopify-discontinues-its-official-plugin-for-wordpress",
            "shopify-launches-official-plugin-for-wordpress"
        ]
    },
    "wordpresscom": {
        "name": "wordpress.com",
        "list": [
            "wordpresscom-adds-google-photos-integration-available-now-for",
            "wpweekly-episode-285-not-every-wordpress-is-the",
            "wordpresscoms-business-plan-gives-subscribers-a-way-to",
            "wordpresscom-introduces-scheduling-for-social-media-posts",
            "wpweekly-episode-274-wordpress-commercials-storefront-and-the",
            "wordpresscoms-tv-commercials-are-confusing",
            "wordpresscom-experiments-with-allowing-business-plan-customers-to",
            "blog-helper-an-alexa-skill-for-managing-a",
            "uk-home-secretary-amber-rudd-links-wordpresscom-to",
            "jetpack-introduces-theme-installation-from-wordpresscom-sparks-controversy",
            "wordpresscom-updates-its-post-editor-with-a-distraction",
            "wordpresscom-releases-chrome-add-on-for-google-docs",
            "wordpresscom-announces-new-importer-for-medium-posts",
            "logging-into-woocommercecom-now-requires-a-wordpresscom-account",
            "behind-the-scenes-of-wordpresscom-themes-with-david",
            "wordpresscom-adds-customization-for-amp-pages-pushes-update",
            "wordpresscom-adds-seo-tools-to-business-plan",
            "wordpresscom-introduces-content-options-customizer-panel-plans-to",
            "wordpresscom-launches-browser-notifications",
            "wordpresscom-adds-sharing-buttons-for-whatsapp-telegram-and",
            "automattic-partners-with-lets-encrypt-to-enable-https"
        ]
    },
    "camping": {
        "name": "camping",
        "list": [
            "camp-press-a-detox-from-digital-life"
        ]
    },
    "vue": {
        "name": "vue",
        "list": [
            "wordpress-core-javascript-framework-selection-discussion-continues-with",
            "wordpress-explores-a-javascript-framework-agnostic-approach-to",
            "why-vuejs-creator-evan-you-thinks-vue-could",
            "vue-project-launches-community-campaign-on-opencollective",
            "wordpress-abandons-react-due-to-patents-clause-gutenberg",
            "vuejs-creator-evan-you-weighs-in-on-wordpress",
            "wordpress-core-javascript-framework-debate-heats-up-contributors"
        ]
    },
    "web-components": {
        "name": "web components",
        "list": [
            "wordpress-core-javascript-framework-selection-discussion-continues-with"
        ]
    },
    "preact": {
        "name": "preact",
        "list": [
            "wordpress-explores-a-javascript-framework-agnostic-approach-to",
            "why-vuejs-creator-evan-you-thinks-vue-could",
            "vue-project-launches-community-campaign-on-opencollective"
        ]
    },
    "sponsorships": {
        "name": "sponsorships",
        "list": [
            "donatewc-reaches-fundraising-goal",
            "donatewc-aims-to-provide-travel-sponsorships-to-attend",
            "the-value-of-sponsoring-a-wordcamp-from-a",
            "pantheons-100k-wordcamp-us-sponsorship-revoked-the-night"
        ]
    },
    "wordcamp-for-publishers": {
        "name": "WordCamp for Publishers",
        "list": [
            "wordcamp-for-publishers-videos-now-available-on-youtube",
            "wordcamp-for-publishers-opens-up-ticket-sales-50",
            "wordcamp-for-publishers-to-be-held-in-denver"
        ]
    },
    "podcasts": {
        "name": "podcasts",
        "list": [
            "apply-filters-podcast-to-be-retired-after-83",
            "hard-refresh-a-new-wordpress-related-tech-podcast",
            "cory-miller-and-matt-danner-launch-new-business"
        ]
    },
    "bbpress": {
        "name": "bbPress",
        "list": [
            "wpweekly-episode-288-no-reactjs-framework-for-gutenberg",
            "bbpress-26-beta-3-likely-as-team-focuses",
            "wpweekly-episode-253-buddypress-28-wordcamp-us-and",
            "wpweekly-episode-241-wordcamp-warmup-jetpack-41-and",
            "bbpress-2510-patches-security-vulnerability",
            "wpweekly-episode-229-versionpress-goes-open-source"
        ]
    },
    "equifax": {
        "name": "equifax",
        "list": [
            "wpweekly-episode-288-no-reactjs-framework-for-gutenberg"
        ]
    },
    "swfupload": {
        "name": "swfupload",
        "list": [
            "wpweekly-episode-288-no-reactjs-framework-for-gutenberg",
            "swfupload-will-officially-be-removed-from-wordpress"
        ]
    },
    "wordcamp-dublin": {
        "name": "wordcamp dublin",
        "list": [
            "first-wordcamp-dublin-set-for-october-14-15",
            "wordpress-meetup-groups-in-belfast-and-dublin-are"
        ]
    },
    "atom": {
        "name": "atom",
        "list": [
            "github-partners-with-facebook-to-release-atom-ide",
            "atom-editor-adds-git-and-github-integration",
            "new-atom-editor-package-offers-code-snippets-for"
        ]
    },
    "plugin-support": {
        "name": "plugin support",
        "list": [
            "wordpressorg-adds-new-support-rep-role-for-plugin"
        ]
    },
    "wordpress-50": {
        "name": "WordPress 5.0",
        "list": [
            "gutenberg-to-offer-new-approach-to-tinymce-in",
            "matt-mullenweg-addresses-concerns-about-gutenberg-confirms-new",
            "wordpress-49-to-focus-on-managing-plugins-and"
        ]
    },
    "o2": {
        "name": "o2",
        "list": [
            "the-final-word-plugin-extends-o2-to-pin"
        ]
    },
    "p2": {
        "name": "p2",
        "list": [
            "the-final-word-plugin-extends-o2-to-pin",
            "in-case-you-missed-it-issue-2"
        ]
    },
    "deprecated": {
        "name": "deprecated",
        "list": [
            "swfupload-will-officially-be-removed-from-wordpress"
        ]
    },
    "plupload": {
        "name": "plupload",
        "list": [
            "swfupload-will-officially-be-removed-from-wordpress"
        ]
    },
    "ann-arbor": {
        "name": "ann arbor",
        "list": [
            "wordcamp-ann-arbor-to-host-second-wordcamp-warmup"
        ]
    },
    "warmup": {
        "name": "warmup",
        "list": [
            "wordcamp-ann-arbor-to-host-second-wordcamp-warmup"
        ]
    },
    "events": {
        "name": "events",
        "list": [
            "wpweekly-episode-287-wordpress-meetups-events-and-wordcamps",
            "wordpress-48-evans-released-featuring-nearby-wordpress-events",
            "community-team-releases-plugin-that-displays-wordpress-events",
            "how-to-view-upcoming-wordcamps-in-the-wordpress",
            "wordcamp-central-now-lets-you-track-an-events"
        ]
    },
    "interviews": {
        "name": "interviews",
        "list": [
            "wpweekly-episode-287-wordpress-meetups-events-and-wordcamps"
        ]
    },
    "meetups": {
        "name": "meetups",
        "list": [
            "wpweekly-episode-287-wordpress-meetups-events-and-wordcamps",
            "what-to-expect-in-wordpress-48",
            "how-the-san-francisco-wordpress-meetup-is-using",
            "community-team-releases-plugin-that-displays-wordpress-events",
            "do-you-enjoy-wordpress-meetups-let-the-community"
        ]
    },
    "wordads": {
        "name": "wordads",
        "list": [
            "jetpack-53-adds-php-71-compatibility-better-control",
            "jetpack-45-expands-monetization-with-wordads-integration"
        ]
    },
    "automatic-updates": {
        "name": "automatic updates",
        "list": [
            "core-team-explores-idea-to-automatically-upgrade-sites"
        ]
    },
    "wordpress-37": {
        "name": "wordpress 3.7",
        "list": [
            "core-team-explores-idea-to-automatically-upgrade-sites"
        ]
    },
    "wordpress-38": {
        "name": "wordpress 3.8",
        "list": [
            "core-team-explores-idea-to-automatically-upgrade-sites"
        ]
    },
    "reputation": {
        "name": "reputation",
        "list": [
            "playing-the-role-of-online-reputation-manager"
        ]
    },
    "merlin": {
        "name": "merlin",
        "list": [
            "wpweekly-episode-286-upgrading-php-facebook-not-budging"
        ]
    },
    "future": {
        "name": "future",
        "list": [
            "morten-rand-hendriksen-on-what-gutenberg-means-for"
        ]
    },
    "rest-api": {
        "name": "rest api",
        "list": [
            "morten-rand-hendriksen-on-what-gutenberg-means-for",
            "wordpress-474-fixes-47-issues",
            "in-case-you-missed-it-issue-18",
            "wpweekly-episode-264-rest-api-disqus-and-happy",
            "wpweekly-episode-263-plugins-disappearing-wordcamp-miami-and",
            "wpweekly-episode-240-interview-with-matt-mullenweg-2016"
        ]
    },
    "wordpress-themes": {
        "name": "wordpress themes",
        "list": [
            "new-merlin-wp-onboarding-wizard-makes-wordpress-theme"
        ]
    },
    "tinymce": {
        "name": "tinymce",
        "list": [
            "user-experience-tests-show-gutenbergs-ui-elements-can",
            "wordpress-451-expected-early-next-week"
        ]
    },
    "wordpressorg-themes": {
        "name": "wordpress.org themes",
        "list": [
            "wordpress-support-team-to-host-free-workshop-august"
        ]
    },
    "twitter": {
        "name": "twitter",
        "list": [
            "wpweekly-episode-285-not-every-wordpress-is-the",
            "in-case-you-missed-it-issue-23",
            "new-twitter-bot-automatically-tweets-links-to-trac",
            "twitter-moments-now-open-to-all-users-wordpress",
            "new-wordpress-plugin-displays-a-live-twitter-wall",
            "wpweekly-episode-245-google-envato-wpcampus-and-a",
            "wordpress-45-to-add-oembed-support-for-twitter"
        ]
    },
    "contact-forms": {
        "name": "contact forms",
        "list": [
            "gravity-forms-stop-entries-plugin-aims-to-help",
            "wpforms-aims-to-be-the-most-beginner-friendly"
        ]
    },
    "gravity-forms": {
        "name": "gravity forms",
        "list": [
            "gravity-forms-stop-entries-plugin-aims-to-help"
        ]
    },
    "mobile-apps": {
        "name": "mobile apps",
        "list": [
            "wordpress-mobile-apps-updated-with-a-new-login"
        ]
    },
    "wordpress-for-android": {
        "name": "wordpress for android",
        "list": [
            "wordpress-mobile-apps-updated-with-a-new-login",
            "new-aztec-editor-for-wordpress-mobile-apps-now",
            "wordpress-app-for-android-adds-better-support-for",
            "wordpress-for-android-closes-google-community-for-beta",
            "wordpress-for-android-57-adds-path-to-upgrade",
            "wordpress-for-android-56-adds-screen-to-invite",
            "wordpress-for-android-55-debuts-new-visual-editor",
            "wordpress-for-android-54-adds-gravatar-updating-and"
        ]
    },
    "bazaar": {
        "name": "bazaar",
        "list": [
            "wordcamp-us-to-experiment-with-a-community-bazaar"
        ]
    },
    "experiment": {
        "name": "experiment",
        "list": [
            "wordcamp-us-to-experiment-with-a-community-bazaar",
            "my-apple-news-publisher-experience-three-weeks-later"
        ]
    },
    "wpremote": {
        "name": "wpremote",
        "list": [
            "maekit-acquires-wp-remote-plans-to-add-cloud"
        ]
    },
    "glutenberg": {
        "name": "glutenberg",
        "list": [
            "in-case-you-missed-it-issue-23"
        ]
    },
    "hellosales": {
        "name": "hellosales",
        "list": [
            "in-case-you-missed-it-issue-23"
        ]
    },
    "syntax-highlighting": {
        "name": "syntax highlighting",
        "list": [
            "wordpress-49-to-focus-on-code-editing-and"
        ]
    },
    "ecosystem": {
        "name": "ecosystem",
        "list": [
            "wordpresscoms-business-plan-gives-subscribers-a-way-to"
        ]
    },
    "managed-hosting": {
        "name": "managed hosting",
        "list": [
            "wordpresscoms-business-plan-gives-subscribers-a-way-to"
        ]
    },
    "david-peralty": {
        "name": "david peralty",
        "list": [
            "wpweekly-episode-284-catching-up-with-david-peralty"
        ]
    },
    "open-source": {
        "name": "open-source",
        "list": [
            "wordpress-foundation-to-sponsor-open-source-educational-events",
            "new-wordpress-contributors-meeting-provides-opportunities-to-ask",
            "cokinetic-systems-pursues-100-million-gpl-license-violation",
            "sustain-event-draws-100-attendees-to-discuss-the",
            "nadia-eghbal-and-mikeal-rogers-join-a16z-podcast",
            "versionpress-launches-versionpresscom-to-fund-open-source-project",
            "2017-open-source-security-and-risk-analysis-report",
            "open-collective-is-a-new-transparent-way-to",
            "github-adds-plain-english-explanations-to-license-pages",
            "us-department-of-defense-launches-codemil-open-source",
            "open-source-in-brazil-ebook-now-available-for",
            "linus-torvalds-shares-lessons-from-25-years-of",
            "fossa-raises-22m-to-automate-open-source-license",
            "discourse-creates-encouragement-fund-to-pay-contributors-for",
            "wix-removes-gpl-licensed-wordpress-code-from-mobile",
            "2nd-edition-of-producing-open-source-software-now",
            "nadia-eghbal-publishes-guide-to-financial-support-for",
            "ford-foundation-publishes-non-technical-white-paper-on",
            "wordcamp-new-york-city-takes-part-in-united",
            "bulgarian-government-now-requires-custom-software-to-be",
            "developers-urge-white-house-to-consider-open-by",
            "linus-torvalds-explains-how-open-source-led-to",
            "versionpress-transitions-into-a-free-open-source-project"
        ]
    },
    "core": {
        "name": "core",
        "list": [
            "wordpress-core-fields-api-project-sees-renewed-interest",
            "in-case-you-missed-it-issue-9"
        ]
    },
    "fields-api": {
        "name": "fields api",
        "list": [
            "wordpress-core-fields-api-project-sees-renewed-interest",
            "wpweekly-episode-225-interview-with-scott-kingsley-clark"
        ]
    },
    "thesis": {
        "name": "thesis",
        "list": [
            "trademark-trial-and-appeal-board-dismisses-automattics-trademark",
            "wpweekly-episode-240-interview-with-matt-mullenweg-2016"
        ]
    },
    "economy": {
        "name": "economy",
        "list": [
            "in-case-you-missed-it-issue-22"
        ]
    },
    "law-firms": {
        "name": "law firms",
        "list": [
            "in-case-you-missed-it-issue-22"
        ]
    },
    "preferred-languages": {
        "name": "preferred languages",
        "list": [
            "in-case-you-missed-it-issue-22"
        ]
    },
    "bug-fix": {
        "name": "bug fix",
        "list": [
            "wordpress-481-released-adds-custom-html-widget"
        ]
    },
    "html": {
        "name": "html",
        "list": [
            "wordpress-481-released-adds-custom-html-widget"
        ]
    },
    "adobe": {
        "name": "adobe",
        "list": [
            "wpweekly-episode-283-a-visit-from-st-gutenberg",
            "adobe-to-discontinue-flash-support-and-updates-in"
        ]
    },
    "pocket-casts": {
        "name": "pocket casts",
        "list": [
            "wpweekly-episode-283-a-visit-from-st-gutenberg",
            "a-fix-for-wordpress-weekly-subscribers-using-pocket"
        ]
    },
    "sitelock": {
        "name": "sitelock",
        "list": [
            "wpweekly-episode-283-a-visit-from-st-gutenberg",
            "sitelock-acquires-patchmans-malware-and-vulnerability-detection-technology"
        ]
    },
    "polyglots": {
        "name": "polyglots",
        "list": [
            "wordpress-polyglots-team-fuels-international-community-growth-with",
            "wordpress-polyglots-team-calls-for-volunteers-to-organize",
            "2nd-global-wordpress-translation-day-brings-780-translators",
            "polyglots-team-to-host-2nd-global-wordpress-translation",
            "wpweekly-episode-245-google-envato-wpcampus-and-a",
            "polyglots-team-experiences-record-annual-growth-expands-wordpress",
            "wordpress-is-now-100-translated-into-marathi",
            "global-wordpress-translation-day-draws-448-participants-from",
            "wordpress-global-translation-day-set-for-april-24"
        ]
    },
    "translation": {
        "name": "translation",
        "list": [
            "wordpress-polyglots-team-fuels-international-community-growth-with",
            "poedit-2-introduces-direct-connection-to-wordpress-adds",
            "wordpress-global-translation-day-set-for-april-24"
        ]
    },
    "contact-form": {
        "name": "contact form",
        "list": [
            "jetpack-52-brings-major-improvements-to-the-contact"
        ]
    },
    "itunes": {
        "name": "itunes",
        "list": [
            "a-fix-for-wordpress-weekly-subscribers-using-pocket"
        ]
    },
    "wordpress-weekly": {
        "name": "WordPress Weekly",
        "list": [
            "a-fix-for-wordpress-weekly-subscribers-using-pocket",
            "episodes-271-280-of-wordpress-weekly-are-now"
        ]
    },
    "admin-notices": {
        "name": "admin notices",
        "list": [
            "new-dobby-plugin-captures-and-hides-unwanted-wordpress",
            "new-wordpress-plugin-shows-users-where-a-plugins",
            "new-framework-helps-wordpress-plugin-developers-create-persistently",
            "the-quest-for-a-centralized-wordpress-notifications-center"
        ]
    },
    "groups": {
        "name": "groups",
        "list": [
            "buddypress-29-adds-ability-to-safely-edit-a",
            "buddypress-core-contributors-working-on-a-way-to",
            "how-to-add-users-to-buddypress-groups-in"
        ]
    },
    "invites": {
        "name": "invites",
        "list": [
            "buddypress-29-adds-ability-to-safely-edit-a"
        ]
    },
    "la-lombarda": {
        "name": "La Lombarda",
        "list": [
            "buddypress-29-adds-ability-to-safely-edit-a"
        ]
    },
    "wordcamp-moscow": {
        "name": "WordCamp Moscow",
        "list": [
            "dmitry-mayorov-discusses-the-challenges-of-organizing-wordcamp"
        ]
    },
    "customize-snapshots": {
        "name": "customize snapshots",
        "list": [
            "customize-snapshots-060-adds-the-ability-to-name",
            "customize-snapshots-050-introduces-scheduled-publishing-and-frontend"
        ]
    },
    "blog": {
        "name": "blog",
        "list": [
            "blog-passes-100000-registrations-665-of-purchased-domains",
            "automattic-clarifies-blog-landrush-process-after-bait-and",
            "in-case-you-missed-it-issue-9",
            "the-blog-domain-extension-is-now-open-to"
        ]
    },
    "flash": {
        "name": "flash",
        "list": [
            "adobe-to-discontinue-flash-support-and-updates-in"
        ]
    },
    "wapuu": {
        "name": "wapuu",
        "list": [
            "watch-wordcamp-varna-wapuus-get-designed-in-real",
            "in-case-you-missed-it-issue-20",
            "automattic-releases-free-wordpress-stickers-app-for-ios",
            "peter-meth-launches-kickstarter-campaign-to-produce-7",
            "crochet-your-own-wapuu-with-this-free-pattern",
            "json-api-now-available-for-wordpress-wapuu-archive",
            "giant-wapuu-among-the-attendees-at-wordcamp-london",
            "limited-edition-r2-wapuu-will-debut-at-wordcamp",
            "wordcamp-miami-wapuuno-cards-now-available-on-github",
            "in-case-you-missed-it-issue-1"
        ]
    },
    "wordpress-mobile-apps": {
        "name": "wordpress mobile apps",
        "list": [
            "new-aztec-editor-for-wordpress-mobile-apps-now"
        ]
    },
    "free-wordpress-themes": {
        "name": "free wordpress themes",
        "list": [
            "hamilton-a-free-wordpress-portfolio-theme-for-photographers",
            "checathlon-a-free-wordpress-business-theme-with-support",
            "wedding-bride-a-free-one-page-wordpress-wedding",
            "digitale-pracht-a-minimalist-blogging-theme-for-wordpress",
            "snowbird-a-free-wordpress-theme-for-bloggers-and",
            "baton-a-free-wordpress-business-theme-with-a",
            "canape-an-elegant-free-restaurant-theme-for-wordpress",
            "affinity-a-free-wordpress-wedding-theme-from-automattic",
            "array-cuts-theme-club-pricing-releases-free-theme",
            "silk-lite-a-free-wordpress-magazine-theme-for",
            "latte-a-free-one-page-wordpress-theme-to",
            "dyad-a-beautiful-free-wordpress-theme-for-photographers",
            "onepress-a-free-single-page-wordpress-theme-built",
            "magnus-a-bold-new-photoblogging-theme-for-wordpress"
        ]
    },
    "portfolio": {
        "name": "portfolio",
        "list": [
            "hamilton-a-free-wordpress-portfolio-theme-for-photographers"
        ]
    },
    "members": {
        "name": "members",
        "list": [
            "members-20-adds-capability-registration-system-introduces-new",
            "how-to-change-the-default-members-landing-tab"
        ]
    },
    "membership": {
        "name": "membership",
        "list": [
            "members-20-adds-capability-registration-system-introduces-new"
        ]
    },
    "481": {
        "name": "4.8.1",
        "list": [
            "wordpress-481-adds-a-dedicated-custom-html-widget"
        ]
    },
    "bbpress-26": {
        "name": "bbpress 2.6",
        "list": [
            "bbpress-2513-readds-sanitization-to-anonymous-user-data"
        ]
    },
    "bug-fixes": {
        "name": "bug fixes",
        "list": [
            "bbpress-2513-readds-sanitization-to-anonymous-user-data",
            "wordpress-451-fixes-12-bugs"
        ]
    },
    "croatia": {
        "name": "croatia",
        "list": [
            "zagreb-to-host-3rd-wordcamp-in-croatia-september"
        ]
    },
    "contributors": {
        "name": "contributors",
        "list": [
            "new-wordpress-contributors-meeting-provides-opportunities-to-ask",
            "discourse-creates-encouragement-fund-to-pay-contributors-for",
            "first-global-wordpress-contributor-drive-set-for-january"
        ]
    },
    "meetings": {
        "name": "meetings",
        "list": [
            "new-wordpress-contributors-meeting-provides-opportunities-to-ask"
        ]
    },
    "plugin-updates": {
        "name": "plugin updates",
        "list": [
            "wp-rollback-adds-multisite-compatibility-and-changelog-preview",
            "wp-safe-updates-plugin-test-wordpress-plugin-updates"
        ]
    },
    "forecasts": {
        "name": "forecasts",
        "list": [
            "stylishly-display-weather-conditions-with-the-weather-atlas"
        ]
    },
    "weather": {
        "name": "weather",
        "list": [
            "stylishly-display-weather-conditions-with-the-weather-atlas"
        ]
    },
    "widget": {
        "name": "widget",
        "list": [
            "stylishly-display-weather-conditions-with-the-weather-atlas"
        ]
    },
    "metaboxes": {
        "name": "metaboxes",
        "list": [
            "gutenberg-boilerplate-demonstrates-how-to-build-custom-blocks",
            "butterbean-post-meta-box-framework-10-released"
        ]
    },
    "editor": {
        "name": "editor",
        "list": [
            "gutenberg-050-adds-new-verse-block-for-poetry",
            "wordpress-editor-experience-survey-shows-75-of-respondents",
            "take-the-wordpress-editor-experience-survey",
            "wordpress-core-editor-team-publishes-ui-prototype-for",
            "content-creation-is-about-more-than-an-editor",
            "matt-mullenweg-announces-tech-and-design-leads-for",
            "a-preview-of-the-custom-css-editor-added",
            "wordpress-47-removes-the-underline-and-justify-buttons",
            "the-days-of-creating-child-themes-for-simple",
            "improving-the-user-experience-by-rearranging-the-wordpress",
            "ulysses-26-released-users-can-now-publish-posts"
        ]
    },
    "gpl": {
        "name": "gpl",
        "list": [
            "cokinetic-systems-pursues-100-million-gpl-license-violation",
            "unsplash-updates-its-license-raises-gpl-compatibility-concerns",
            "us-district-court-denies-pre-trial-motion-to",
            "2017-open-source-security-and-risk-analysis-report",
            "wix-removes-gpl-licensed-wordpress-code-from-mobile",
            "mullenweg-takes-aim-at-wix-over-gpl-abuses",
            "in-case-you-missed-it-issue-16",
            "commercial-wordpress-product-descriptions-can-mislead-customers-into",
            "in-case-you-missed-it-issue-6"
        ]
    },
    "ecommerce": {
        "name": "ecommerce",
        "list": [
            "aj-morris-acquires-ithemes-exchange",
            "wp-ecommerce-3114-patches-sql-injection-vulnerability"
        ]
    },
    "exchange": {
        "name": "exchange",
        "list": [
            "aj-morris-acquires-ithemes-exchange"
        ]
    },
    "jesse-petersen": {
        "name": "jesse petersen",
        "list": [
            "wpweekly-episode-281-in-memory-of-jesse-petersen",
            "jesse-petersen-founder-of-genesis-theme-passes-away",
            "help-jesse-petersen-and-his-family-by-donating"
        ]
    },
    "lift-ux": {
        "name": "lift ux",
        "list": [
            "wpweekly-episode-281-in-memory-of-jesse-petersen"
        ]
    },
    "net-neutrality": {
        "name": "net neutrality",
        "list": [
            "wpweekly-episode-281-in-memory-of-jesse-petersen",
            "automattic-releases-net-neutrality-wordpress-plugin-ahead-of",
            "automattic-joins-amazon-github-mozilla-reddit-and-twitter"
        ]
    },
    "versionpress": {
        "name": "versionpress",
        "list": [
            "versionpress-40-beta-adds-user-editable-location-for",
            "versionpress-launches-versionpresscom-to-fund-open-source-project",
            "versionpress-co-founder-shares-his-thoughts-on-mergebot",
            "versionpress-will-offer-optional-services-to-fund-plugin",
            "versionpress-30-adds-new-search-feature-bulk-undo",
            "wpweekly-episode-229-versionpress-goes-open-source",
            "versionpress-transitions-into-a-free-open-source-project"
        ]
    },
    "stream": {
        "name": "stream",
        "list": [
            "wpcampus-2017-will-be-streamed-live-for-free"
        ]
    },
    "stitcher": {
        "name": "stitcher",
        "list": [
            "episodes-271-280-of-wordpress-weekly-are-now"
        ]
    },
    "fight-for-the-future": {
        "name": "fight for the future",
        "list": [
            "automattic-joins-amazon-github-mozilla-reddit-and-twitter",
            "fight-for-the-future-launches-save-security-campaign"
        ]
    },
    "wangguard": {
        "name": "wangguard",
        "list": [
            "wangguard-plugin-author-shuts-down-splog-hunting-service",
            "wpweekly-episode-280-behind-the-scenes-of-tuniversity",
            "wangguard-plugin-launches-indiegogo-campaign-to-fund-development"
        ]
    },
    "wordcamp-asia": {
        "name": "WordCamp Asia",
        "list": [
            "wordsesh-asia-now-in-planning-for-2018-wordcamp"
        ]
    },
    "cystic-fibrosis": {
        "name": "cystic fibrosis",
        "list": [
            "jesse-petersen-founder-of-genesis-theme-passes-away"
        ]
    },
    "apple": {
        "name": "apple",
        "list": [
            "wpweekly-episode-280-behind-the-scenes-of-tuniversity",
            "wordpress-for-ios-adds-people-and-user-role",
            "ulysses-26-released-users-can-now-publish-posts",
            "my-apple-news-publisher-experience-three-weeks-later",
            "fight-for-the-future-launches-save-security-campaign",
            "how-to-connect-your-wordpress-powered-site-to",
            "in-case-you-missed-it-issue-3"
        ]
    },
    "ibook": {
        "name": "ibook",
        "list": [
            "wpweekly-episode-280-behind-the-scenes-of-tuniversity"
        ]
    },
    "tuniversity": {
        "name": "tuniversity",
        "list": [
            "wpweekly-episode-280-behind-the-scenes-of-tuniversity"
        ]
    },
    "wordpress-seo": {
        "name": "wordpress seo",
        "list": [
            "popular-wordpress-plugins-slow-to-add-meta-box"
        ]
    },
    "regional-wordcamps": {
        "name": "regional wordcamps",
        "list": [
            "wordcamp-netherlands-reinstated-for-2018"
        ]
    },
    "wordcamp-netherlands": {
        "name": "WordCamp Netherlands",
        "list": [
            "wordcamp-netherlands-reinstated-for-2018",
            "wordpress-community-support-shuts-down-wordcamp-netherlands-in"
        ]
    },
    "wordpress-community": {
        "name": "wordpress community",
        "list": [
            "wordcamp-netherlands-reinstated-for-2018"
        ]
    },
    "underscores": {
        "name": "underscores",
        "list": [
            "wpweekly-episode-279-the-future-of-underscores-with",
            "automattic-to-renew-efforts-on-underscores-retire-components",
            "automattic-launches-components-with-5-new-starter-themes"
        ]
    },
    "psychology": {
        "name": "psychology",
        "list": [
            "catalina-alvarez-is-conducting-the-first-occupational-psychology"
        ]
    },
    "matt-mullenweg": {
        "name": "matt mullenweg",
        "list": [
            "matt-mullenweg-discusses-core-focuses-downsides-of-a",
            "in-case-you-missed-it-issue-16",
            "wpweekly-episode-240-interview-with-matt-mullenweg-2016"
        ]
    },
    "marketing": {
        "name": "marketing",
        "list": [
            "wordpress-marketing-team-launches-case-studies-and-usage",
            "in-case-you-missed-it-issue-20",
            "wpweekly-episode-260-siteground-affiliate-summit-recap-and"
        ]
    },
    "wphierarchy": {
        "name": "wphierarchy",
        "list": [
            "wpshout-updates-and-acquires-wphierarchycom"
        ]
    },
    "belgrade": {
        "name": "belgrade",
        "list": [
            "wpweekly-episode-278-recap-of-wordcamp-europe-2017",
            "wordcamp-europe-2018-to-be-held-in-belgrade"
        ]
    },
    "europe": {
        "name": "europe",
        "list": [
            "wpweekly-episode-278-recap-of-wordcamp-europe-2017"
        ]
    },
    "paris": {
        "name": "paris",
        "list": [
            "wpweekly-episode-278-recap-of-wordcamp-europe-2017"
        ]
    },
    "serbia": {
        "name": "serbia",
        "list": [
            "wordcamp-europe-2018-to-be-held-in-belgrade"
        ]
    },
    "renewals": {
        "name": "renewals",
        "list": [
            "woocommerce-drops-50-renewal-discount-on-subscriptions"
        ]
    },
    "products": {
        "name": "products",
        "list": [
            "10-lessons-learned-from-five-years-of-selling"
        ]
    },
    "rebecca-gill": {
        "name": "rebecca gill",
        "list": [
            "10-lessons-learned-from-five-years-of-selling",
            "wordcamp-warmup-is-a-success",
            "wpweekly-episode-244-myths-lies-and-the-truth"
        ]
    },
    "industry": {
        "name": "industry",
        "list": [
            "lifted-a-wordpress-theme-and-plugin-shop-for"
        ]
    },
    "9seeds": {
        "name": "9seeds",
        "list": [
            "9seeds-acquires-web-savvy-marketings-genesis-theme-store"
        ]
    },
    "web-savvy-marketing": {
        "name": "web savvy marketing",
        "list": [
            "9seeds-acquires-web-savvy-marketings-genesis-theme-store"
        ]
    },
    "tips": {
        "name": "tips",
        "list": [
            "wpweekly-episode-277-wordpress-48-filing-good-bug",
            "quick-tip-how-to-access-jetpacks-alternative-module"
        ]
    },
    "wordpress-48": {
        "name": "wordpress 4.8",
        "list": [
            "wpweekly-episode-277-wordpress-48-filing-good-bug",
            "wordpress-48-improves-accessibility-on-admin-screens",
            "wpweekly-episode-273-mental-health-awareness-with-bridget",
            "what-to-expect-in-wordpress-48",
            "wordpress-48-release-targeted-for-june-8",
            "customizer-team-proposes-image-widget-for-wordpress-48",
            "matt-mullenweg-announces-tech-and-design-leads-for",
            "wordpress-to-bump-recommended-php-version-from-56"
        ]
    },
    "wp-super-cache": {
        "name": "wp super cache",
        "list": [
            "wpweekly-episode-277-wordpress-48-filing-good-bug",
            "major-update-coming-to-wp-super-cache-new"
        ]
    },
    "imagely": {
        "name": "imagely",
        "list": [
            "imagely-acquires-teslathemes-is-seeking-other-acquisition-opportunities"
        ]
    },
    "teslathemes": {
        "name": "teslathemes",
        "list": [
            "imagely-acquires-teslathemes-is-seeking-other-acquisition-opportunities"
        ]
    },
    "freedoms": {
        "name": "freedoms",
        "list": [
            "unsplash-updates-its-license-raises-gpl-compatibility-concerns"
        ]
    },
    "restrictions": {
        "name": "restrictions",
        "list": [
            "unsplash-updates-its-license-raises-gpl-compatibility-concerns"
        ]
    },
    "unsplash": {
        "name": "unsplash",
        "list": [
            "unsplash-updates-its-license-raises-gpl-compatibility-concerns"
        ]
    },
    "bill-evans": {
        "name": "bill evans",
        "list": [
            "wordpress-48-evans-released-featuring-nearby-wordpress-events"
        ]
    },
    "link-boundaries": {
        "name": "link boundaries",
        "list": [
            "wordpress-48-evans-released-featuring-nearby-wordpress-events",
            "what-to-expect-in-wordpress-48"
        ]
    },
    "popup": {
        "name": "popup",
        "list": [
            "holler-box-a-smart-notification-plugin-for-wordpress"
        ]
    },
    "remote-work": {
        "name": "remote work",
        "list": [
            "wpweekly-episode-276-interview-with-jon-brown-a",
            "in-case-you-missed-it-issue-15"
        ]
    },
    "travel": {
        "name": "travel",
        "list": [
            "wpweekly-episode-276-interview-with-jon-brown-a"
        ]
    },
    "hosting": {
        "name": "hosting",
        "list": [
            "versionpress-launches-versionpresscom-to-fund-open-source-project",
            "php-56-is-now-the-most-widely-used",
            "wefoster-launches-hosting-platform-catered-to-online-communities",
            "siteground-auto-issues-lets-encrypt-certificates-for-new",
            "bluehost-network-outage-hits-customers-with-12-hours",
            "digitalcube-launches-shifter-serverless-hosting-for-wordpress",
            "wp-engine-adds-2fa-to-user-portal-opt"
        ]
    },
    "cory-miller": {
        "name": "cory miller",
        "list": [
            "cory-miller-and-dr-sherry-walling-launch-zentribes",
            "the-div-selected-by-codeorg-to-help-expand"
        ]
    },
    "entrepreneur-groups": {
        "name": "entrepreneur groups",
        "list": [
            "cory-miller-and-dr-sherry-walling-launch-zentribes"
        ]
    },
    "zentribes": {
        "name": "zentribes",
        "list": [
            "cory-miller-and-dr-sherry-walling-launch-zentribes"
        ]
    },
    "mental-health": {
        "name": "mental health",
        "list": [
            "open-sourcing-mental-illness-surpasses-50k-fundraising-goal",
            "wpweekly-episode-273-mental-health-awareness-with-bridget",
            "wphugs-a-community-devoted-to-educating-discussing-and",
            "wp-elevation-is-focusing-all-content-on-mental",
            "geek-mental-help-week-2016-explores-issues-related",
            "wpweekly-episode-243-the-struggle-is-real",
            "take-the-mental-health-in-tech-2016-survey",
            "cory-miller-and-pippin-williamson-discuss-the-importance"
        ]
    },
    "osmi": {
        "name": "osmi",
        "list": [
            "open-sourcing-mental-illness-surpasses-50k-fundraising-goal",
            "wpweekly-episode-273-mental-health-awareness-with-bridget"
        ]
    },
    "magazine-themes": {
        "name": "magazine themes",
        "list": [
            "in-case-you-missed-it-issue-21"
        ]
    },
    "managewp": {
        "name": "managewp",
        "list": [
            "in-case-you-missed-it-issue-21",
            "godaddy-acquires-sucuri",
            "managewp-launches-automated-security-scanning",
            "wpweekly-episode-248-insight-into-the-managewp-acquisition",
            "godaddy-acquires-wordpress-site-management-service-managewp"
        ]
    },
    "wabster": {
        "name": "wabster",
        "list": [
            "in-case-you-missed-it-issue-21"
        ]
    },
    "vagrant": {
        "name": "vagrant",
        "list": [
            "chassis-desktop-application-for-local-wordpress-development-now",
            "primary-vagrant-40-updated-to-use-php-71",
            "varying-vagrant-vagrants-200-introduces-yaml-configuration-revamps",
            "varying-vagrant-vagrants-130-released-with-support-for"
        ]
    },
    "hhvm": {
        "name": "hhvm",
        "list": [
            "wpweekly-episode-275-the-javascript-framework-rabbit-hole",
            "wordpress-removes-hhvm-from-testing-infrastructure"
        ]
    },
    "27-beta": {
        "name": "2.7 beta",
        "list": [
            "pods-27-beta-introduces-flexible-relationships-rewrites-fields"
        ]
    },
    "flexible-relationships": {
        "name": "flexible relationships",
        "list": [
            "pods-27-beta-introduces-flexible-relationships-rewrites-fields"
        ]
    },
    "pods": {
        "name": "pods",
        "list": [
            "pods-27-beta-introduces-flexible-relationships-rewrites-fields",
            "wpweekly-episode-225-interview-with-scott-kingsley-clark"
        ]
    },
    "php-7": {
        "name": "php 7",
        "list": [
            "wordpress-removes-hhvm-from-testing-infrastructure",
            "yoast-seos-php-upgrade-nag-is-producing-a",
            "yoast-seo-45-urges-users-to-upgrade-to"
        ]
    },
    "copyblogger": {
        "name": "copyblogger",
        "list": [
            "rainmaker-digital-to-partner-with-nimble-worldwide"
        ]
    },
    "nimble": {
        "name": "nimble",
        "list": [
            "rainmaker-digital-to-partner-with-nimble-worldwide"
        ]
    },
    "rainmaker": {
        "name": "rainmaker",
        "list": [
            "rainmaker-digital-to-partner-with-nimble-worldwide"
        ]
    },
    "feeds": {
        "name": "feeds",
        "list": [
            "json-feed-creators-aim-to-revitalize-interest-in"
        ]
    },
    "json": {
        "name": "JSON",
        "list": [
            "json-feed-creators-aim-to-revitalize-interest-in"
        ]
    },
    "json-feed": {
        "name": "JSON Feed",
        "list": [
            "json-feed-creators-aim-to-revitalize-interest-in"
        ]
    },
    "rss": {
        "name": "rss",
        "list": [
            "json-feed-creators-aim-to-revitalize-interest-in"
        ]
    },
    "cape-town": {
        "name": "cape town",
        "list": [
            "wpweekly-episode-274-wordpress-commercials-storefront-and-the"
        ]
    },
    "accessiblity": {
        "name": "accessiblity",
        "list": [
            "wordpress-48-improves-accessibility-on-admin-screens"
        ]
    },
    "headings": {
        "name": "headings",
        "list": [
            "wordpress-48-improves-accessibility-on-admin-screens"
        ]
    },
    "charity-hackathon": {
        "name": "charity hackathon",
        "list": [
            "cape-town-to-host-4th-annual-wordpress-charity",
            "austin-wordpress-meetup-to-host-charity-hackathon-april"
        ]
    },
    "resizer": {
        "name": "resizer",
        "list": [
            "wordpress-48-increases-maximum-width-of-the-customizer"
        ]
    },
    "avada": {
        "name": "avada",
        "list": [
            "avada-theme-version-515-patches-stored-xss-and"
        ]
    },
    "modules": {
        "name": "modules",
        "list": [
            "quick-tip-how-to-access-jetpacks-alternative-module"
        ]
    },
    "advertising": {
        "name": "advertising",
        "list": [
            "wordpresscoms-tv-commercials-are-confusing",
            "please-stop-abusing-wordpress-admin-notices"
        ]
    },
    "commercials": {
        "name": "commercials",
        "list": [
            "wordpresscoms-tv-commercials-are-confusing"
        ]
    },
    "docker": {
        "name": "docker",
        "list": [
            "primary-vagrant-40-updated-to-use-php-71",
            "10up-releases-wp-docker-an-open-source-docker",
            "composing-a-wordpress-development-environment-with-docker"
        ]
    },
    "hookr": {
        "name": "hookr",
        "list": [
            "hookr-plugin-rebrands-as-wp-inspect-project-to"
        ]
    },
    "wp-inspect": {
        "name": "wp inspect",
        "list": [
            "hookr-plugin-rebrands-as-wp-inspect-project-to"
        ]
    },
    "business-plan": {
        "name": "business plan",
        "list": [
            "wordpresscom-experiments-with-allowing-business-plan-customers-to",
            "wordpresscom-adds-seo-tools-to-business-plan"
        ]
    },
    "incsub": {
        "name": "incsub",
        "list": [
            "wpweekly-episode-272-interview-with-james-farmer-co"
        ]
    },
    "james-farmer": {
        "name": "james farmer",
        "list": [
            "wpweekly-episode-272-interview-with-james-farmer-co"
        ]
    },
    "wpmu-dev": {
        "name": "wpmu dev",
        "list": [
            "wpweekly-episode-272-interview-with-james-farmer-co"
        ]
    },
    "registrations": {
        "name": "registrations",
        "list": [
            "new-wordpress-plugin-blocks-spam-user-registrations-using",
            "how-to-make-buddypress-user-registration-invite-only"
        ]
    },
    "spam": {
        "name": "spam",
        "list": [
            "new-wordpress-plugin-blocks-spam-user-registrations-using",
            "google-launches-invisible-recaptcha"
        ]
    },
    "stop-forum-spam": {
        "name": "stop forum spam",
        "list": [
            "new-wordpress-plugin-blocks-spam-user-registrations-using"
        ]
    },
    "wphugs": {
        "name": "wphugs",
        "list": [
            "wphugs-a-community-devoted-to-educating-discussing-and"
        ]
    },
    "jjj": {
        "name": "jjj",
        "list": [
            "wpweekly-episode-271-recapping-wordcamp-chicago-2017-with",
            "john-james-jacoby-publishes-35-part-tweetstorm-on"
        ]
    },
    "internet-defense-league": {
        "name": "internet defense league",
        "list": [
            "jetpack-49-introduces-eu-cookie-law-banner-widget"
        ]
    },
    "review": {
        "name": "review",
        "list": [
            "manage-multiple-social-media-accounts-in-wordpress-with",
            "watsonfinds-wordpress-plugin-uses-ibms-watson-to-determine",
            "community-team-releases-plugin-that-displays-wordpress-events",
            "how-to-view-upcoming-wordcamps-in-the-wordpress",
            "easily-hide-wordpress-blogging-features-with-the-disable",
            "easily-add-remove-and-rearrange-columns-with-the",
            "new-plugin-adds-the-ability-to-categorize-and",
            "wpforms-aims-to-be-the-most-beginner-friendly"
        ]
    },
    "social-media": {
        "name": "social media",
        "list": [
            "manage-multiple-social-media-accounts-in-wordpress-with"
        ]
    },
    "social-media-suite": {
        "name": "social media suite",
        "list": [
            "manage-multiple-social-media-accounts-in-wordpress-with"
        ]
    },
    "vvv": {
        "name": "VVV",
        "list": [
            "10up-releases-wp-docker-an-open-source-docker",
            "varying-vagrant-vagrants-200-introduces-yaml-configuration-revamps",
            "varying-vagrant-vagrants-130-released-with-support-for",
            "learn-how-to-test-wordpress-core-patches-with"
        ]
    },
    "open-collective": {
        "name": "open collective",
        "list": [
            "how-the-san-francisco-wordpress-meetup-is-using",
            "open-collective-is-a-new-transparent-way-to"
        ]
    },
    "articifical-intelligence": {
        "name": "articifical intelligence",
        "list": [
            "watsonfinds-wordpress-plugin-uses-ibms-watson-to-determine"
        ]
    },
    "ibm": {
        "name": "IBM",
        "list": [
            "watsonfinds-wordpress-plugin-uses-ibms-watson-to-determine"
        ]
    },
    "watson": {
        "name": "watson",
        "list": [
            "watsonfinds-wordpress-plugin-uses-ibms-watson-to-determine"
        ]
    },
    "browser": {
        "name": "browser",
        "list": [
            "wordpress-48-will-end-support-for-internet-explorer"
        ]
    },
    "recommended-plugins": {
        "name": "recommended plugins",
        "list": [
            "new-plugin-offers-better-plugin-recommendations-in-the",
            "what-do-you-think-of-the-recommended-plugins"
        ]
    },
    "mastodon": {
        "name": "mastodon",
        "list": [
            "embed-mastodon-statuses-in-wordpress"
        ]
    },
    "blox": {
        "name": "blox",
        "list": [
            "headway-themes-appears-to-be-dying-a-slow"
        ]
    },
    "flywheel": {
        "name": "flywheel",
        "list": [
            "headway-themes-appears-to-be-dying-a-slow",
            "flywheel-acquires-wordpress-local-development-tool-pressmatic",
            "wpweekly-episode-252-flywheel-hosting-three-years-later"
        ]
    },
    "headwaythemes": {
        "name": "headwaythemes",
        "list": [
            "headway-themes-appears-to-be-dying-a-slow",
            "headway-themes-future-is-uncertain-amidst-financial-troubles"
        ]
    },
    "influx": {
        "name": "influx",
        "list": [
            "headway-themes-appears-to-be-dying-a-slow"
        ]
    },
    "scholarships": {
        "name": "scholarships",
        "list": [
            "heropress-partners-with-wpshout-to-offer-wordpress-education",
            "human-made-is-giving-away-two-full-scholarships"
        ]
    },
    "wpshout": {
        "name": "wpshout",
        "list": [
            "heropress-partners-with-wpshout-to-offer-wordpress-education",
            "wpweekly-episode-268-behind-the-scenes-of-wordpress"
        ]
    },
    "474": {
        "name": "4.7.4",
        "list": [
            "wordpress-474-fixes-47-issues"
        ]
    },
    "settings": {
        "name": "settings",
        "list": [
            "new-wordpress-plugin-shows-users-where-a-plugins"
        ]
    },
    "fundraising": {
        "name": "fundraising",
        "list": [
            "open-collective-is-a-new-transparent-way-to"
        ]
    },
    "office": {
        "name": "office",
        "list": [
            "automattic-to-close-san-francisco-office"
        ]
    },
    "san-francisco": {
        "name": "san francisco",
        "list": [
            "automattic-to-close-san-francisco-office"
        ]
    },
    "design": {
        "name": "design",
        "list": [
            "automattic-to-host-a-free-remote-conference-on",
            "john-maedas-2017-design-in-tech-report-puts",
            "wordpress-27-is-the-role-model-for-how",
            "wordpress-meta-team-publishes-prototypes-of-the-plugin"
        ]
    },
    "cabins": {
        "name": "cabins",
        "list": [
            "inuagural-cabinpress-takes-place-november-3-5-at"
        ]
    },
    "disconnect": {
        "name": "disconnect",
        "list": [
            "inuagural-cabinpress-takes-place-november-3-5-at"
        ]
    },
    "image-widget": {
        "name": "image widget",
        "list": [
            "customizer-team-proposes-image-widget-for-wordpress-48"
        ]
    },
    "good-first-bugs": {
        "name": "good-first-bugs",
        "list": [
            "new-twitter-bot-automatically-tweets-links-to-trac"
        ]
    },
    "trac": {
        "name": "trac",
        "list": [
            "new-twitter-bot-automatically-tweets-links-to-trac"
        ]
    },
    "resilient-web-design": {
        "name": "resilient web design",
        "list": [
            "recommended-reading-resilient-web-design-a-free-e"
        ]
    },
    "greasemonkey": {
        "name": "greasemonkey",
        "list": [
            "new-userscript-restores-tabs-to-the-wordpress-plugin"
        ]
    },
    "tabs": {
        "name": "tabs",
        "list": [
            "new-userscript-restores-tabs-to-the-wordpress-plugin"
        ]
    },
    "userscripts": {
        "name": "userscripts",
        "list": [
            "new-userscript-restores-tabs-to-the-wordpress-plugin"
        ]
    },
    "stats": {
        "name": "stats",
        "list": [
            "wordpress-plugin-directory-restores-stats-and-links-to",
            "in-case-you-missed-it-issue-18",
            "solving-the-mystery-of-how-people-actually-use"
        ]
    },
    "versions": {
        "name": "versions",
        "list": [
            "wordpress-plugin-directory-restores-stats-and-links-to"
        ]
    },
    "smashing-mag": {
        "name": "smashing mag",
        "list": [
            "wpweekly-episode-270-going-camp-press-with-mendel"
        ]
    },
    "alexa": {
        "name": "alexa",
        "list": [
            "blog-helper-an-alexa-skill-for-managing-a"
        ]
    },
    "oklahoma": {
        "name": "oklahoma",
        "list": [
            "disconnect-from-technology-at-camp-press-september-23"
        ]
    },
    "technology": {
        "name": "technology",
        "list": [
            "disconnect-from-technology-at-camp-press-september-23"
        ]
    },
    "blog-in-a-box": {
        "name": "blog in a box",
        "list": [
            "blog-in-a-box-project-integrates-wordpress-with"
        ]
    },
    "raspberry-pi": {
        "name": "raspberry pi",
        "list": [
            "blog-in-a-box-project-integrates-wordpress-with"
        ]
    },
    "feedback": {
        "name": "feedback",
        "list": [
            "wordpress-plugin-directory-redesign-why-so-many-people"
        ]
    },
    "iteration": {
        "name": "iteration",
        "list": [
            "wordpress-plugin-directory-redesign-why-so-many-people"
        ]
    },
    "global": {
        "name": "global",
        "list": [
            "wordpress-polyglots-team-calls-for-volunteers-to-organize"
        ]
    },
    "translations": {
        "name": "translations",
        "list": [
            "wordpress-polyglots-team-calls-for-volunteers-to-organize",
            "wordpress-47-is-the-first-release-to-be",
            "polyglots-team-to-host-2nd-global-wordpress-translation",
            "wpweekly-episode-232-recap-of-wordcamp-san-diego",
            "global-wordpress-translation-day-draws-448-participants-from",
            "wpweekly-episode-226-burnout"
        ]
    },
    "reviews": {
        "name": "Reviews",
        "list": [
            "data-from-theme-reviews-shows-authors-need-more",
            "how-authors-with-plugins-in-the-official-directory"
        ]
    },
    "encryption": {
        "name": "encryption",
        "list": [
            "uk-home-secretary-amber-rudd-links-wordpresscom-to"
        ]
    },
    "age": {
        "name": "age",
        "list": [
            "how-to-find-the-age-of-a-plugin"
        ]
    },
    "ebook": {
        "name": "ebook",
        "list": [
            "wpweekly-episode-268-behind-the-scenes-of-wordpress"
        ]
    },
    "sucuri": {
        "name": "sucuri",
        "list": [
            "wpweekly-episode-268-behind-the-scenes-of-wordpress",
            "godaddy-acquires-sucuri",
            "wordpress-rest-api-vulnerability-exploits-continue",
            "wpweekly-episode-256-interview-with-tony-perez-ceo",
            "sucuri-partners-with-lets-encrypt-to-offer-free",
            "custom-content-type-manager-plugin-update-creates-a"
        ]
    },
    "acquitision": {
        "name": "acquitision",
        "list": [
            "godaddy-acquires-sucuri"
        ]
    },
    "wp-rest-api": {
        "name": "wp rest api",
        "list": [
            "foxhound-is-the-first-rest-api-powered-theme",
            "wordpress-rest-api-vulnerability-is-being-actively-exploited",
            "matt-mullenweg-announces-tech-and-design-leads-for",
            "wordpress-47-introduces-twenty-seventeen-default-theme-and",
            "wp-rest-api-content-endpoints-officially-approved-for",
            "wp-rest-api-content-endpoints-conditionally-approved-for",
            "wp-rest-api-team-proposes-to-merge-content",
            "a-week-of-rest-developer-workshop-to-be",
            "daniel-bachhuber-discusses-wp-cli-the-wp-rest",
            "guggenheimorg-relaunches-on-wordpress-using-the-wp-rest",
            "a-day-of-rest-is-coming-to-boston",
            "wp-rest-api-team-aims-for-wordpress-47",
            "a-week-of-rest-wordpress-rest-api-developer",
            "wp-rest-api-team-releases-version-2-beta",
            "wordpress-contributors-look-for-a-path-forward-for",
            "wordpressorg-has-fewer-than-20-plugins-using-the",
            "wp-rest-api-delayed-contributors-facing-gridlock",
            "a-day-of-rest-conference-successful-81-would"
        ]
    },
    "generosity": {
        "name": "generosity",
        "list": [
            "help-jesse-petersen-and-his-family-by-donating"
        ]
    },
    "audio": {
        "name": "audio",
        "list": [
            "adding-images-to-wordpress-sidebars-is-about-to"
        ]
    },
    "images": {
        "name": "images",
        "list": [
            "adding-images-to-wordpress-sidebars-is-about-to"
        ]
    },
    "video": {
        "name": "Video",
        "list": [
            "adding-images-to-wordpress-sidebars-is-about-to"
        ]
    },
    "edit-flow": {
        "name": "edit flow",
        "list": [
            "pressshack-forks-edit-flow-to-create-publishpress-aims",
            "wpweekly-episode-249-zerif-lite-kinsta-scholarship-w3",
            "edit-flow-082-released-fixes-a-number-of",
            "edit-flow-lives-new-update-fixes-bugs-and",
            "hey-automattic-whats-going-on-with-edit-flow"
        ]
    },
    "publishpress": {
        "name": "publishpress",
        "list": [
            "pressshack-forks-edit-flow-to-create-publishpress-aims"
        ]
    },
    "mainwp": {
        "name": "mainwp",
        "list": [
            "in-case-you-missed-it-issue-19"
        ]
    },
    "nextgen": {
        "name": "nextgen",
        "list": [
            "in-case-you-missed-it-issue-19"
        ]
    },
    "semver": {
        "name": "semver",
        "list": [
            "woocommerce-300-scheduled-for-release-april-4th"
        ]
    },
    "timestamp": {
        "name": "timestamp",
        "list": [
            "woocommerce-300-scheduled-for-release-april-4th"
        ]
    },
    "varying-vagrant-vagrants": {
        "name": "varying vagrant vagrants",
        "list": [
            "varying-vagrant-vagrants-200-introduces-yaml-configuration-revamps"
        ]
    },
    "wefoster": {
        "name": "wefoster",
        "list": [
            "wefoster-launches-hosting-platform-catered-to-online-communities"
        ]
    },
    "jobs": {
        "name": "jobs",
        "list": [
            "stack-overflow-jobs-data-shows-reactjs-skills-in"
        ]
    },
    "recaptcha": {
        "name": "recaptcha",
        "list": [
            "google-launches-invisible-recaptcha"
        ]
    },
    "clef": {
        "name": "clef",
        "list": [
            "wpweekly-episode-266-clef-is-shutting-down-configuring",
            "clef-is-shutting-down-june-6th"
        ]
    },
    "google-adsense-for-wordpress": {
        "name": "google adsense for wordpress",
        "list": [
            "google-is-retiring-its-adsense-for-wordpress-plugin"
        ]
    },
    "two-factor-authentication": {
        "name": "two-factor authentication",
        "list": [
            "clef-is-shutting-down-june-6th"
        ]
    },
    "google-docs": {
        "name": "Google Docs",
        "list": [
            "wordpresscom-releases-chrome-add-on-for-google-docs"
        ]
    },
    "avatars": {
        "name": "avatars",
        "list": [
            "configuring-a-user-avatar-in-wordpress-is-not"
        ]
    },
    "gravatar": {
        "name": "gravatar",
        "list": [
            "configuring-a-user-avatar-in-wordpress-is-not",
            "managing-gravatars-in-wordpress-is-a-jarring-user"
        ]
    },
    "profile-image": {
        "name": "profile image",
        "list": [
            "configuring-a-user-avatar-in-wordpress-is-not"
        ]
    },
    "permalink": {
        "name": "permalink",
        "list": [
            "buddypress-core-contributors-working-on-a-way-to"
        ]
    },
    "slug": {
        "name": "slug",
        "list": [
            "buddypress-core-contributors-working-on-a-way-to"
        ]
    },
    "hypothesis": {
        "name": "hypothesis",
        "list": [
            "web-annotations-are-now-a-w3c-standard-paving"
        ]
    },
    "w3c": {
        "name": "w3c",
        "list": [
            "web-annotations-are-now-a-w3c-standard-paving"
        ]
    },
    "web-annotations": {
        "name": "web annotations",
        "list": [
            "web-annotations-are-now-a-w3c-standard-paving"
        ]
    },
    "testimonials": {
        "name": "testimonials",
        "list": [
            "do-you-enjoy-wordpress-meetups-let-the-community",
            "in-case-you-missed-it-issue-1"
        ]
    },
    "importer": {
        "name": "importer",
        "list": [
            "wordpresscom-announces-new-importer-for-medium-posts"
        ]
    },
    "freemius": {
        "name": "freemius",
        "list": [
            "wpweekly-episode-265-interview-with-matt-medeiros",
            "freemius-launches-insights-for-wordpress-themes",
            "includewp-a-directory-that-caters-to-wordpress-frameworks",
            "freemius-checkout-aims-to-take-the-hassle-out"
        ]
    },
    "nextgen-gallery": {
        "name": "nextgen gallery",
        "list": [
            "wpweekly-episode-265-interview-with-matt-medeiros"
        ]
    },
    "slocum-studio": {
        "name": "slocum studio",
        "list": [
            "wpweekly-episode-265-interview-with-matt-medeiros"
        ]
    },
    "insights": {
        "name": "insights",
        "list": [
            "freemius-launches-insights-for-wordpress-themes"
        ]
    },
    "amazon": {
        "name": "amazon",
        "list": [
            "amazon-s3-outage-hits-wordpress-businesses-disrupting-services"
        ]
    },
    "s3": {
        "name": "s3",
        "list": [
            "amazon-s3-outage-hits-wordpress-businesses-disrupting-services"
        ]
    },
    "sql-injection": {
        "name": "sql injection",
        "list": [
            "nextgen-gallery-patches-critical-sql-injection-vulnerability"
        ]
    },
    "vulnerability": {
        "name": "vulnerability",
        "list": [
            "nextgen-gallery-patches-critical-sql-injection-vulnerability",
            "buddypress-274-patches-security-vulnerability-that-could-allow",
            "wpweekly-episode-238-interview-with-adam-warner-sitelocks",
            "ninja-forms-update-patches-critical-security-vulnerability"
        ]
    },
    "linux": {
        "name": "linux",
        "list": [
            "linus-torvalds-shares-lessons-from-25-years-of",
            "linus-torvalds-explains-how-open-source-led-to"
        ]
    },
    "xss-vulnerability": {
        "name": "xss vulnerability",
        "list": [
            "learn-how-to-find-and-exploit-xss-vulnerabilities"
        ]
    },
    "discourse": {
        "name": "discourse",
        "list": [
            "discourse-creates-encouragement-fund-to-pay-contributors-for",
            "wpweekly-episode-264-rest-api-disqus-and-happy"
        ]
    },
    "cloudflare": {
        "name": "cloudflare",
        "list": [
            "cloudflare-memory-leak-exposes-private-data",
            "cloudflare-releases-major-30-update-to-official-wordpress"
        ]
    },
    "community-summit": {
        "name": "community summit",
        "list": [
            "wordpress-community-summit-2017-set-for-june-13"
        ]
    },
    "zerif-lite": {
        "name": "zerif lite",
        "list": [
            "zerif-lite-returns-to-wordpressorg-after-5-month",
            "wpweekly-episode-249-zerif-lite-kinsta-scholarship-w3"
        ]
    },
    "prototype": {
        "name": "prototype",
        "list": [
            "wordpress-core-editor-team-publishes-ui-prototype-for"
        ]
    },
    "twenty-seventeen": {
        "name": "twenty seventeen",
        "list": [
            "buddypress-28-boosts-minimum-php-requirement-adds-twenty",
            "wordpress-47-introduces-twenty-seventeen-default-theme-and",
            "wordpress-47-beta-1-now-available-for-testing",
            "new-wordpress-default-theme-twenty-seventeen-merged-into",
            "wordpress-47-to-ship-with-new-twenty-seventeen"
        ]
    },
    "contact-form-db": {
        "name": "contact form db",
        "list": [
            "how-to-check-if-installed-plugins-are-no"
        ]
    },
    "ostraining": {
        "name": "ostraining",
        "list": [
            "wpweekly-episode-263-plugins-disappearing-wordcamp-miami-and"
        ]
    },
    "digital-signatures": {
        "name": "digital signatures",
        "list": [
            "matt-mullenweg-responds-to-security-rant-digital-signatures"
        ]
    },
    "update-signing": {
        "name": "update signing",
        "list": [
            "matt-mullenweg-responds-to-security-rant-digital-signatures"
        ]
    },
    "wordfence": {
        "name": "wordfence",
        "list": [
            "wordpress-rest-api-vulnerability-exploits-continue"
        ]
    },
    "elasticpress": {
        "name": "elasticpress",
        "list": [
            "10up-unveils-elasticpressio-elasticsearch-as-a-service-for",
            "10up-open-sources-elasticpress-plugin-for-woocommerce"
        ]
    },
    "supportpress": {
        "name": "supportpress",
        "list": [
            "in-case-you-missed-it-issue-17"
        ]
    },
    "widget-logic": {
        "name": "widget logic",
        "list": [
            "in-case-you-missed-it-issue-17"
        ]
    },
    "wp101": {
        "name": "wp101",
        "list": [
            "in-case-you-missed-it-issue-17",
            "in-case-you-missed-it-issue-16"
        ]
    },
    "wpsessions": {
        "name": "wpsessions",
        "list": [
            "in-case-you-missed-it-issue-17"
        ]
    },
    "creative-commons": {
        "name": "creative commons",
        "list": [
            "creative-commons-new-search-tool-is-now-in"
        ]
    },
    "google-alerts": {
        "name": "google alerts",
        "list": [
            "google-webmaster-tools-fixes-confusing-messages-about-updating"
        ]
    },
    "wordpress-472": {
        "name": "wordpress 4.7.2",
        "list": [
            "google-webmaster-tools-fixes-confusing-messages-about-updating"
        ]
    },
    "proposal": {
        "name": "proposal",
        "list": [
            "wpweekly-episode-262-interview-with-morten-rand-hendriksen"
        ]
    },
    "blogvault": {
        "name": "blogvault",
        "list": [
            "blogvault-security-breach-infects-customers-sites-with-malware"
        ]
    },
    "breach": {
        "name": "breach",
        "list": [
            "blogvault-security-breach-infects-customers-sites-with-malware"
        ]
    },
    "atomic-web-design": {
        "name": "atomic web design",
        "list": [
            "content-creation-is-about-more-than-an-editor"
        ]
    },
    "content-creation": {
        "name": "content creation",
        "list": [
            "content-creation-is-about-more-than-an-editor"
        ]
    },
    "cameron-barrett": {
        "name": "cameron barrett",
        "list": [
            "wpweekly-episode-261-wordpress-for-schools-with-cameron"
        ]
    },
    "schools": {
        "name": "schools",
        "list": [
            "wpweekly-episode-261-wordpress-for-schools-with-cameron"
        ]
    },
    "client-management": {
        "name": "client management",
        "list": [
            "logging-into-woocommercecom-now-requires-a-wordpresscom-account"
        ]
    },
    "microblog": {
        "name": "micro.blog",
        "list": [
            "microblog-project-surges-past-65k-on-kickstarter-gains",
            "microblog-surpasses-kickstarter-funding-goal-set-to-launch"
        ]
    },
    "webmentions": {
        "name": "webmentions",
        "list": [
            "microblog-project-surges-past-65k-on-kickstarter-gains",
            "is-w3c-replicating-the-wordpress-pingback-system"
        ]
    },
    "sponsors": {
        "name": "sponsors",
        "list": [
            "wordcamp-europe-2017-to-experiment-with-sponsors-workshops"
        ]
    },
    "wix": {
        "name": "wix",
        "list": [
            "wix-removes-gpl-licensed-wordpress-code-from-mobile",
            "mullenweg-takes-aim-at-wix-over-gpl-abuses"
        ]
    },
    "affiliate-summit": {
        "name": "affiliate summit",
        "list": [
            "wpweekly-episode-260-siteground-affiliate-summit-recap-and"
        ]
    },
    "security-czar": {
        "name": "security czar",
        "list": [
            "wpweekly-episode-260-siteground-affiliate-summit-recap-and"
        ]
    },
    "siteground": {
        "name": "siteground",
        "list": [
            "wpweekly-episode-260-siteground-affiliate-summit-recap-and",
            "siteground-auto-issues-lets-encrypt-certificates-for-new"
        ]
    },
    "bulk": {
        "name": "bulk",
        "list": [
            "how-to-add-users-to-buddypress-groups-in"
        ]
    },
    "users": {
        "name": "users",
        "list": [
            "how-to-add-users-to-buddypress-groups-in"
        ]
    },
    "epoch": {
        "name": "epoch",
        "list": [
            "postmatic-basic-rebrands-as-replyable-moves-two-way"
        ]
    },
    "postmatic": {
        "name": "postmatic",
        "list": [
            "postmatic-basic-rebrands-as-replyable-moves-two-way",
            "wpweekly-episode-237-dont-take-my-booze-away",
            "postmatic-2-features-email-digests-comment-intelligence-and"
        ]
    },
    "wordpress-comments": {
        "name": "wordpress comments",
        "list": [
            "postmatic-basic-rebrands-as-replyable-moves-two-way"
        ]
    },
    "aaron-campbell": {
        "name": "aaron campbell",
        "list": [
            "aaron-d-campbell-replaces-nikolay-bachiyski-as-wordpress"
        ]
    },
    "czar": {
        "name": "czar",
        "list": [
            "aaron-d-campbell-replaces-nikolay-bachiyski-as-wordpress"
        ]
    },
    "lightroom": {
        "name": "lightroom",
        "list": [
            "automattic-releases-free-plugin-for-exporting-photos-from"
        ]
    },
    "2016": {
        "name": "2016",
        "list": [
            "wpweekly-episode-259-2016-year-in-review-part",
            "wpweekly-episode-258-2016-year-in-review-part"
        ]
    },
    "predictions": {
        "name": "predictions",
        "list": [
            "wpweekly-episode-259-2016-year-in-review-part"
        ]
    },
    "book": {
        "name": "book",
        "list": [
            "2nd-edition-of-producing-open-source-software-now"
        ]
    },
    "adopt-me-tag": {
        "name": "adopt-me tag",
        "list": [
            "tom-mcfarlin-to-launch-marketplace-for-blogging-plugins"
        ]
    },
    "plugin-abandonment": {
        "name": "plugin abandonment",
        "list": [
            "tom-mcfarlin-to-launch-marketplace-for-blogging-plugins"
        ]
    },
    "plugin-adoption": {
        "name": "plugin adoption",
        "list": [
            "tom-mcfarlin-to-launch-marketplace-for-blogging-plugins"
        ]
    },
    "phpmailer": {
        "name": "phpmailer",
        "list": [
            "wordpress-471-fixes-eight-security-issues"
        ]
    },
    "wordpress-471": {
        "name": "wordpress 4.7.1",
        "list": [
            "wordpress-471-fixes-eight-security-issues"
        ]
    },
    "facebook-instant-articles": {
        "name": "facebook instant articles",
        "list": [
            "facebook-launches-journalism-project-plans-to-expand-monetization",
            "automattic-releases-wordpress-plugin-for-facebooks-instant-articles"
        ]
    },
    "statistics": {
        "name": "statistics",
        "list": [
            "year-in-wp-creates-a-personalized-review-of",
            "what-wordpressorg-does-with-the-data-it-collects"
        ]
    },
    "year-in-wordpress": {
        "name": "year in wordpress",
        "list": [
            "year-in-wp-creates-a-personalized-review-of"
        ]
    },
    "laravel": {
        "name": "laravel",
        "list": [
            "how-laravel-forge-can-help-you-run-wordpress",
            "laravel-releases-valet-a-minimalist-development-environment-with"
        ]
    },
    "laravel-forge": {
        "name": "laravel forge",
        "list": [
            "how-laravel-forge-can-help-you-run-wordpress"
        ]
    },
    "new-user-experience": {
        "name": "new user experience",
        "list": [
            "how-do-you-educate-people-new-to-wordpress"
        ]
    },
    "new-users": {
        "name": "new users",
        "list": [
            "how-do-you-educate-people-new-to-wordpress"
        ]
    },
    "indonesia": {
        "name": "indonesia",
        "list": [
            "incubator-wordcamp-denpasar-a-success"
        ]
    },
    "cms": {
        "name": "cms",
        "list": [
            "w3techs-ranks-wordpress-as-the-fastest-growing-cms",
            "in-case-you-missed-it-issue-12"
        ]
    },
    "new-year": {
        "name": "new year",
        "list": [
            "wpweekly-episode-258-2016-year-in-review-part"
        ]
    },
    "news": {
        "name": "News",
        "list": [
            "wpweekly-episode-258-2016-year-in-review-part"
        ]
    },
    "wordpressorg": {
        "name": "wordpress.org",
        "list": [
            "wordpressorg-launches-homepage-redesign",
            "the-wordpressorg-homepage-is-getting-a-redesign",
            "wordpressorg-ux-research-begins-as-part-of-long"
        ]
    },
    "seriously-simple-podcasting": {
        "name": "seriously simple podcasting",
        "list": [
            "wpweekly-episode-257-my-side-project-wordpress-47",
            "podcast-motor-acquires-seriously-simple-podcasting-plugin"
        ]
    },
    "updraftplus": {
        "name": "updraftplus",
        "list": [
            "wpweekly-episode-257-my-side-project-wordpress-47",
            "updraftplus-acquires-wp-optimize-will-be-integrated-into"
        ]
    },
    "wordpress-47": {
        "name": "wordpress 4.7",
        "list": [
            "wpweekly-episode-257-my-side-project-wordpress-47",
            "wordpress-47-introduces-twenty-seventeen-default-theme-and",
            "visible-edit-shortcuts-in-wordpress-47-makes-customizing",
            "wordpress-47-improves-accessibility-by-removing-alternative-text",
            "wordpress-47-removes-the-underline-and-justify-buttons",
            "wordpress-47-beta-1-now-available-for-testing",
            "new-wordpress-default-theme-twenty-seventeen-merged-into",
            "wp-rest-api-content-endpoints-officially-approved-for",
            "wordpress-47-to-ship-with-infrastructure-from-the",
            "wp-rest-api-content-endpoints-conditionally-approved-for",
            "wp-rest-api-team-proposes-to-merge-content",
            "wordpress-47-to-allow-255-character-passwords-for",
            "wordpress-47-to-ship-with-new-twenty-seventeen",
            "wordpress-47-development-kicks-off-this-week"
        ]
    },
    "funding": {
        "name": "funding",
        "list": [
            "nadia-eghbal-publishes-guide-to-financial-support-for"
        ]
    },
    "invitations": {
        "name": "invitations",
        "list": [
            "how-to-make-buddypress-user-registration-invite-only"
        ]
    },
    "activity": {
        "name": "activity",
        "list": [
            "how-to-change-the-default-members-landing-tab"
        ]
    },
    "profile": {
        "name": "profile",
        "list": [
            "how-to-change-the-default-members-landing-tab"
        ]
    },
    "tony-perez": {
        "name": "tony perez",
        "list": [
            "wpweekly-episode-256-interview-with-tony-perez-ceo"
        ]
    },
    "thailand": {
        "name": "thailand",
        "list": [
            "wordcamp-bangkok-2017-adds-english-track-debuts-new"
        ]
    },
    "wordcamp-bangkok": {
        "name": "wordcamp bangkok",
        "list": [
            "wordcamp-bangkok-2017-adds-english-track-debuts-new"
        ]
    },
    "podcast-motor": {
        "name": "podcast motor",
        "list": [
            "podcast-motor-acquires-seriously-simple-podcasting-plugin"
        ]
    },
    "vr-content": {
        "name": "VR content",
        "list": [
            "wordpresscom-launches-vr-content-coming-soon-to-jetpack"
        ]
    },
    "wordpress-growth-council": {
        "name": "WordPress Growth Council",
        "list": [
            "matt-mullenweg-proposes-wordpress-growth-council"
        ]
    },
    "wp-optimize": {
        "name": "wp optimize",
        "list": [
            "updraftplus-acquires-wp-optimize-will-be-integrated-into"
        ]
    },
    "crazyhorse": {
        "name": "crazyhorse",
        "list": [
            "wordpress-27-is-the-role-model-for-how"
        ]
    },
    "wordpress-27": {
        "name": "wordpress 2.7",
        "list": [
            "wordpress-27-is-the-role-model-for-how"
        ]
    },
    "bluehost": {
        "name": "bluehost",
        "list": [
            "bluehost-network-outage-hits-customers-with-12-hours",
            "bluehost-open-sources-script-used-to-update-25"
        ]
    },
    "wordpres-47": {
        "name": "wordpres 4.7",
        "list": [
            "wpweekly-episode-255-all-about-the-customizer"
        ]
    },
    "wp-curve": {
        "name": "wp curve",
        "list": [
            "godaddy-acquires-wp-curve-aims-to-become-a"
        ]
    },
    "foundation": {
        "name": "foundation",
        "list": [
            "the-value-of-sponsoring-a-wordcamp-from-a"
        ]
    },
    "pakistan": {
        "name": "pakistan",
        "list": [
            "wordpress-47-is-the-first-release-to-be",
            "first-wordpress-meetup-in-karachi-draws-125-attendees"
        ]
    },
    "urdu": {
        "name": "urdu",
        "list": [
            "wordpress-47-is-the-first-release-to-be"
        ]
    },
    "pantheon": {
        "name": "pantheon",
        "list": [
            "pantheons-100k-wordcamp-us-sponsorship-revoked-the-night",
            "pantheon-launches-community-resource-for-scaling-wordpress"
        ]
    },
    "php7": {
        "name": "php7",
        "list": [
            "state-of-the-word-2016-mullenweg-pushes-calypso",
            "wordpress-to-bump-recommended-php-version-from-56",
            "wp-engine-adds-2fa-to-user-portal-opt"
        ]
    },
    "shifter": {
        "name": "shifter",
        "list": [
            "digitalcube-launches-shifter-serverless-hosting-for-wordpress"
        ]
    },
    "headway-themes": {
        "name": "headway themes",
        "list": [
            "flywheel-acquires-wordpress-local-development-tool-pressmatic",
            "wpweekly-episode-249-zerif-lite-kinsta-scholarship-w3",
            "tom-auger-and-greg-mount-of-agency-chat",
            "headway-themes-confirms-financial-difficulties-issues-apology-to",
            "former-headway-themes-employee-goes-public-staff-has",
            "customers-still-in-the-dark-concerning-the-future",
            "in-case-you-missed-it-issue-14"
        ]
    },
    "pressmatic": {
        "name": "pressmatic",
        "list": [
            "flywheel-acquires-wordpress-local-development-tool-pressmatic",
            "headway-389-patches-potential-xss-vulnerability",
            "wpweekly-episode-247-interview-with-marc-benzakein-operations"
        ]
    },
    "pdf": {
        "name": "pdf",
        "list": [
            "pdf-image-previews-among-the-improvements-to-media"
        ]
    },
    "thanksgiving": {
        "name": "thanksgiving",
        "list": [
            "why-are-you-thankful-for-wordpress"
        ]
    },
    "communication": {
        "name": "communication",
        "list": [
            "automattic-clarifies-blog-landrush-process-after-bait-and",
            "tom-auger-and-greg-mount-of-agency-chat",
            "headway-themes-future-is-uncertain-amidst-financial-troubles",
            "monsterinsights-addresses-user-criticism-with-immediate-changes",
            "hey-automattic-whats-going-on-with-edit-flow",
            "wpweekly-episode-228-communication-is-key",
            "a-little-communication-goes-a-long-way"
        ]
    },
    "domains": {
        "name": "domains",
        "list": [
            "automattic-clarifies-blog-landrush-process-after-bait-and",
            "syed-balkhi-donates-wporg-to-the-wordpress-foundation"
        ]
    },
    "translation-day": {
        "name": "translation day",
        "list": [
            "2nd-global-wordpress-translation-day-brings-780-translators",
            "wpweekly-episode-251-amp-translation-day-2-and"
        ]
    },
    "upvato": {
        "name": "upvato",
        "list": [
            "wpweekly-episode-254-wp-ecommerce-wordcamp-us-2017",
            "upvato-backup-service-confirms-files-are-lost-plans",
            "upvato-backup-service-terminated-by-storage-provider-files",
            "wpweekly-episode-222-ithemes-enters-the-real-time"
        ]
    },
    "wp-ecommerce": {
        "name": "wp ecommerce",
        "list": [
            "wpweekly-episode-254-wp-ecommerce-wordcamp-us-2017"
        ]
    },
    "shortcuts": {
        "name": "shortcuts",
        "list": [
            "visible-edit-shortcuts-in-wordpress-47-makes-customizing"
        ]
    },
    "alt-text": {
        "name": "alt text",
        "list": [
            "wordpress-47-improves-accessibility-by-removing-alternative-text",
            "new-plugin-uses-microsofts-computer-vision-api-to"
        ]
    },
    "emoji": {
        "name": "emoji",
        "list": [
            "new-wordpress-plugin-serves-pre-compressed-emoji",
            "new-plugin-adds-emoji-reactions-to-the-buddypress",
            "new-super-emoji-plus-plugin-adds-an-elegant",
            "new-feature-plugin-for-wordpress-adds-emoji-reactions"
        ]
    },
    "blogging": {
        "name": "Blogging",
        "list": [
            "andy-baio-relaunches-waxyorg-on-wordpress"
        ]
    },
    "locales": {
        "name": "locales",
        "list": [
            "bbpress-2511-adds-wordpress-47-compatibility"
        ]
    },
    "pressnomics": {
        "name": "pressnomics",
        "list": [
            "wpweekly-episode-253-buddypress-28-wordcamp-us-and",
            "pressnomics-5-scheduled-for-april-6-8-2017",
            "in-case-you-missed-it-issue-4",
            "joshua-strebel-interviews-alex-king-10-days-before",
            "joshua-strebel-interviews-alex-king-10-days-before-0"
        ]
    },
    "summit": {
        "name": "summit",
        "list": [
            "wordpress-community-team-proposes-new-selection-process-for",
            "wordcamp-europe-2017-will-host-the-next-wordpress"
        ]
    },
    "buddypress-survey": {
        "name": "buddypress survey",
        "list": [
            "buddypress-28-development-kicks-off-2016-survey-now"
        ]
    },
    "css": {
        "name": "css",
        "list": [
            "a-preview-of-the-custom-css-editor-added",
            "the-days-of-creating-child-themes-for-simple",
            "wpweekly-episode-242-interview-with-eric-meyer"
        ]
    },
    "nanowrimo": {
        "name": "nanowrimo",
        "list": [
            "nanowrimo-2016-kicks-off-today-write-your-novel"
        ]
    },
    "self-publishing": {
        "name": "self-publishing",
        "list": [
            "nanowrimo-2016-kicks-off-today-write-your-novel"
        ]
    },
    "baidu": {
        "name": "baidu",
        "list": [
            "beware-of-links-to-baidu-in-skype-messages"
        ]
    },
    "linkedin": {
        "name": "linkedin",
        "list": [
            "beware-of-links-to-baidu-in-skype-messages",
            "wpweekly-episode-252-flywheel-hosting-three-years-later",
            "linkedin-learning-is-offering-free-access-this-week"
        ]
    },
    "skype": {
        "name": "skype",
        "list": [
            "beware-of-links-to-baidu-in-skype-messages",
            "wordpresscom-adds-sharing-buttons-for-whatsapp-telegram-and"
        ]
    },
    "buttons": {
        "name": "buttons",
        "list": [
            "wordpress-47-removes-the-underline-and-justify-buttons",
            "improving-the-user-experience-by-rearranging-the-wordpress"
        ]
    },
    "custom-post-types": {
        "name": "custom post types",
        "list": [
            "wordpress-47-brings-custom-page-template-functionality-to"
        ]
    },
    "post-type-templates": {
        "name": "post type templates",
        "list": [
            "wordpress-47-brings-custom-page-template-functionality-to"
        ]
    },
    "colombia": {
        "name": "colombia",
        "list": [
            "the-challenges-of-organizing-a-wordcamp-from-abroad"
        ]
    },
    "incubator": {
        "name": "incubator",
        "list": [
            "the-challenges-of-organizing-a-wordcamp-from-abroad"
        ]
    },
    "wordpress-theme-directory": {
        "name": "WordPress Theme Directory",
        "list": [
            "controversy-surrounding-wordpressorg-popular-themes-exposes-weaknesses-in",
            "new-and-updated-theme-tags-now-available-to",
            "wordpress-theme-review-team-votes-on-new-guidelines",
            "wordpress-46-to-update-theme-filter-tags-in"
        ]
    },
    "los-angeles": {
        "name": "los angeles",
        "list": [
            "wordpress-and-web-development-communities-get-together-to",
            "wordpress-to-take-center-stage-during-website-weekend"
        ]
    },
    "non-profits": {
        "name": "non profits",
        "list": [
            "wordpress-and-web-development-communities-get-together-to"
        ]
    },
    "website-weekend": {
        "name": "website weekend",
        "list": [
            "wordpress-and-web-development-communities-get-together-to",
            "wordpress-to-take-center-stage-during-website-weekend"
        ]
    },
    "lynda": {
        "name": "lynda",
        "list": [
            "linkedin-learning-is-offering-free-access-this-week"
        ]
    },
    "telegram": {
        "name": "telegram",
        "list": [
            "automattic-releases-free-wordpress-stickers-app-for-ios",
            "get-wordpress-news-on-telegram-via-the-new",
            "jetpack-41-adds-telegram-and-whatsapp-sharing-buttons",
            "wordpresscom-adds-sharing-buttons-for-whatsapp-telegram-and"
        ]
    },
    "kickstarter": {
        "name": "kickstarter",
        "list": [
            "peter-meth-launches-kickstarter-campaign-to-produce-7"
        ]
    },
    "orlando": {
        "name": "orlando",
        "list": [
            "wordcamp-orlando-rescheduled-for-november-12-13",
            "wordcamp-orlando-rescheduled-for-november-12-14",
            "wordcamp-orlando-cancelled-due-to-hurricane",
            "loopconf-postponed-due-to-hurricane-matthew-wordcamp-orlando"
        ]
    },
    "loopconf": {
        "name": "loopconf",
        "list": [
            "loopconf-rescheduled-for-february-6-8-2017-in",
            "wpweekly-episode-250-interview-with-matt-cromwell-head",
            "loopconf-postponed-due-to-hurricane-matthew-wordcamp-orlando"
        ]
    },
    "wordcamp-ann-arbor": {
        "name": "wordcamp ann arbor",
        "list": [
            "wordcamp-warmup-is-a-success",
            "wordcamp-warmup-an-experimental-event-aimed-at-breaking"
        ]
    },
    "wordcamp-warmup": {
        "name": "wordcamp warmup",
        "list": [
            "wordcamp-warmup-is-a-success",
            "wordcamp-warmup-an-experimental-event-aimed-at-breaking"
        ]
    },
    "themeforest": {
        "name": "themeforest",
        "list": [
            "why-pixelgrade-is-experimenting-with-a-225-wordpress",
            "wordpress-theme-authors-experiment-with-new-pricing-on",
            "wpweekly-episode-235-interview-with-james-giroux-envatos",
            "array-cuts-theme-club-pricing-releases-free-theme"
        ]
    },
    "headway": {
        "name": "headway",
        "list": [
            "headway-389-patches-potential-xss-vulnerability"
        ]
    },
    "kinsta": {
        "name": "kinsta",
        "list": [
            "lizz-ehrenpreis-wins-kinstas-1500-travel-scholarship",
            "wpweekly-episode-249-zerif-lite-kinsta-scholarship-w3",
            "kinsta-to-award-1500-travel-scholarship-for-wordcamp"
        ]
    },
    "bitbucket": {
        "name": "bitbucket",
        "list": [
            "bitbucket-pricing-hike-increases-cost-per-user-by",
            "wp-pusher-210-offers-tighter-integration-with-github"
        ]
    },
    "wordpress-theme-review": {
        "name": "WordPress Theme Review",
        "list": [
            "godaddys-new-primer-theme-bypasses-theme-review-queue",
            "responsive-design-should-be-required-for-wordpressorg-themes",
            "wordpress-theme-review-team-works-to-address-bottlenecks",
            "wordpress-theme-review-team-votes-on-new-guidelines"
        ]
    },
    "wordpress-theme-review-team": {
        "name": "wordpress theme review team",
        "list": [
            "godaddys-new-primer-theme-bypasses-theme-review-queue",
            "zerif-lite-suspended-from-wordpress-theme-directory-300k",
            "wordpress-theme-review-team-works-to-address-bottlenecks",
            "wordpress-theme-review-team-recommends-authors-start-keeping"
        ]
    },
    "child-themes": {
        "name": "child themes",
        "list": [
            "wpweekly-episode-251-amp-translation-day-2-and",
            "child-theme-check-plugin-helps-wordpress-users-navigate"
        ]
    },
    "47": {
        "name": "4.7",
        "list": [
            "the-days-of-creating-child-themes-for-simple"
        ]
    },
    "people": {
        "name": "people",
        "list": [
            "you-are-responsible-for-your-own-awesome",
            "wordpress-for-ios-adds-people-and-user-role"
        ]
    },
    "stories": {
        "name": "stories",
        "list": [
            "you-are-responsible-for-your-own-awesome"
        ]
    },
    "graphql": {
        "name": "graphql",
        "list": [
            "wordexpress-project-experiments-with-bringing-graphql-to-wordpress"
        ]
    },
    "wordexpress": {
        "name": "wordexpress",
        "list": [
            "wordexpress-project-experiments-with-bringing-graphql-to-wordpress"
        ]
    },
    "sponsorship": {
        "name": "sponsorship",
        "list": [
            "xwp-is-the-first-financial-sponsor-of-heropress"
        ]
    },
    "givewp": {
        "name": "givewp",
        "list": [
            "wpweekly-episode-250-interview-with-matt-cromwell-head"
        ]
    },
    "wordimpress": {
        "name": "wordimpress",
        "list": [
            "wpweekly-episode-250-interview-with-matt-cromwell-head"
        ]
    },
    "hurricane": {
        "name": "hurricane",
        "list": [
            "wordcamp-orlando-cancelled-due-to-hurricane",
            "loopconf-postponed-due-to-hurricane-matthew-wordcamp-orlando"
        ]
    },
    "seo": {
        "name": "seo",
        "list": [
            "wordpresscom-adds-seo-tools-to-business-plan",
            "wpweekly-episode-244-myths-lies-and-the-truth",
            "all-in-one-seo-237-patches-persistent-xss",
            "jetpack-39-introduces-new-sitemaps-module"
        ]
    },
    "the-div": {
        "name": "the div",
        "list": [
            "the-div-selected-by-codeorg-to-help-expand"
        ]
    },
    "bob-dunn": {
        "name": "bob dunn",
        "list": [
            "in-case-you-missed-it-issue-16",
            "do-the-woo-a-new-podcast-for-woocommerce"
        ]
    },
    "fooplugins": {
        "name": "fooplugins",
        "list": [
            "in-case-you-missed-it-issue-16"
        ]
    },
    "page-builder-plugins": {
        "name": "page builder plugins",
        "list": [
            "pippin-williamson-shakes-up-page-builder-plugins-with"
        ]
    },
    "emails": {
        "name": "emails",
        "list": [
            "disable-specific-wordpress-update-emails-with-the-control"
        ]
    },
    "w3-total-cache": {
        "name": "w3 total cache",
        "list": [
            "wpweekly-episode-249-zerif-lite-kinsta-scholarship-w3",
            "w3-total-cache-095-packages-xss-vulnerability-patch",
            "high-risk-xss-vulnerability-discovered-in-w3-total",
            "wpweekly-episode-228-communication-is-key",
            "frederick-townes-confirms-w3-total-cache-is-not"
        ]
    },
    "pagely": {
        "name": "pagely",
        "list": [
            "pagely-celebrates-7-years-of-managed-wordpress-hosting"
        ]
    },
    "benchmarks": {
        "name": "benchmarks",
        "list": [
            "results-of-the-measure-jetpack-project-likely-to"
        ]
    },
    "performance": {
        "name": "performance",
        "list": [
            "results-of-the-measure-jetpack-project-likely-to",
            "simple-cache-a-new-one-click-install-caching",
            "pantheon-launches-community-resource-for-scaling-wordpress"
        ]
    },
    "listings": {
        "name": "listings",
        "list": [
            "automattic-to-revive-wp-job-manager",
            "wp-job-manager-forked-to-create-listings-a"
        ]
    },
    "wp-job-manager": {
        "name": "wp job manager",
        "list": [
            "automattic-to-revive-wp-job-manager"
        ]
    },
    "agency-chat": {
        "name": "agency chat",
        "list": [
            "tom-auger-and-greg-mount-of-agency-chat"
        ]
    },
    "19": {
        "name": "1.9",
        "list": [
            "aesop-19-adds-hero-gallery-type-updates-parallax"
        ]
    },
    "aesop": {
        "name": "aesop",
        "list": [
            "aesop-19-adds-hero-gallery-type-updates-parallax"
        ]
    },
    "girl-develop-it": {
        "name": "girl develop it",
        "list": [
            "wordpress-to-take-center-stage-during-website-weekend"
        ]
    },
    "constant-contact": {
        "name": "constant contact",
        "list": [
            "constant-contact-releases-official-plugin-for-wordpress"
        ]
    },
    "jeff-king": {
        "name": "jeff king",
        "list": [
            "wpweekly-episode-248-insight-into-the-managewp-acquisition"
        ]
    },
    "vladimir-prelovac": {
        "name": "vladimir prelovac",
        "list": [
            "wpweekly-episode-248-insight-into-the-managewp-acquisition"
        ]
    },
    "wordpress-managed-hosting": {
        "name": "wordpress managed hosting",
        "list": [
            "godaddy-launches-new-onboarding-experience-for-wordpress-customers"
        ]
    },
    "wordpress-hosting": {
        "name": "wordpress hosting",
        "list": [
            "review-signal-publishes-2016-wordpress-hosting-performance-benchmarks"
        ]
    },
    "wordcamp-san-jose": {
        "name": "wordcamp san jose",
        "list": [
            "san-jose-costa-rica-to-host-its-first"
        ]
    },
    "codecademy": {
        "name": "codecademy",
        "list": [
            "codecademy-launches-free-reactjs-courses"
        ]
    },
    "461": {
        "name": "4.6.1",
        "list": [
            "wpweekly-episode-247-interview-with-marc-benzakein-operations",
            "wordpress-461-released-patches-two-security-vulnerabilities"
        ]
    },
    "serverpress": {
        "name": "serverpress",
        "list": [
            "wpweekly-episode-247-interview-with-marc-benzakein-operations",
            "quickly-migrate-content-from-one-wordpress-site-to"
        ]
    },
    "wpsitesync": {
        "name": "wpsitesync",
        "list": [
            "wpweekly-episode-247-interview-with-marc-benzakein-operations",
            "quickly-migrate-content-from-one-wordpress-site-to"
        ]
    },
    "happy-days": {
        "name": "happy days",
        "list": [
            "wordcamp-milwaukee-september-17-18-to-be-themed"
        ]
    },
    "milwaukee": {
        "name": "milwaukee",
        "list": [
            "wordcamp-milwaukee-september-17-18-to-be-themed"
        ]
    },
    "wisconsin": {
        "name": "wisconsin",
        "list": [
            "wordcamp-milwaukee-september-17-18-to-be-themed"
        ]
    },
    "authentication": {
        "name": "authentication",
        "list": [
            "iovation-acquires-launchkey-plans-to-continue-supporting-wordpress"
        ]
    },
    "launchkey": {
        "name": "launchkey",
        "list": [
            "iovation-acquires-launchkey-plans-to-continue-supporting-wordpress"
        ]
    },
    "ninja-forms": {
        "name": "ninja forms",
        "list": [
            "ninja-forms-30-released-features-new-drag-and",
            "ninja-forms-update-patches-critical-security-vulnerability"
        ]
    },
    "acqusition": {
        "name": "acqusition",
        "list": [
            "godaddy-acquires-wordpress-site-management-service-managewp"
        ]
    },
    "cmb2": {
        "name": "cmb2",
        "list": [
            "easy-meta-builder-launches-no-code-plugin-for"
        ]
    },
    "meta": {
        "name": "meta",
        "list": [
            "easy-meta-builder-launches-no-code-plugin-for",
            "wordpress-meta-team-publishes-prototypes-of-the-plugin"
        ]
    },
    "changelogs": {
        "name": "changelogs",
        "list": [
            "wpweekly-episode-246-interview-with-gabriel-mays-head",
            "new-plugin-adds-changelog-support-to-wordpress-themes"
        ]
    },
    "oembed": {
        "name": "oembed",
        "list": [
            "wpweekly-episode-246-interview-with-gabriel-mays-head",
            "poll-have-you-used-the-oembed-feature-for",
            "wordpress-feature-idea-add-oembed-support-to-comments",
            "wordpress-45-to-add-oembed-support-for-twitter"
        ]
    },
    "tumblr": {
        "name": "tumblr",
        "list": [
            "improving-the-user-experience-by-rearranging-the-wordpress"
        ]
    },
    "cutsomization": {
        "name": "cutsomization",
        "list": [
            "two-distinct-approaches-aimed-at-making-site-customization"
        ]
    },
    "user-roles": {
        "name": "user roles",
        "list": [
            "wordpress-for-ios-adds-people-and-user-role"
        ]
    },
    "embeds": {
        "name": "embeds",
        "list": [
            "poll-have-you-used-the-oembed-feature-for"
        ]
    },
    "wordpress-44": {
        "name": "wordpress 4.4",
        "list": [
            "poll-have-you-used-the-oembed-feature-for"
        ]
    },
    "cognitive": {
        "name": "cognitive",
        "list": [
            "new-plugin-uses-microsofts-computer-vision-api-to"
        ]
    },
    "akismet": {
        "name": "akismet",
        "list": [
            "disqus-adds-support-for-akismet"
        ]
    },
    "mergebot": {
        "name": "mergebot",
        "list": [
            "versionpress-co-founder-shares-his-thoughts-on-mergebot"
        ]
    },
    "services": {
        "name": "services",
        "list": [
            "versionpress-will-offer-optional-services-to-fund-plugin"
        ]
    },
    "applications": {
        "name": "applications",
        "list": [
            "wpcampus-is-accepting-applications-to-host-the-event"
        ]
    },
    "native-system-fonts": {
        "name": "native system fonts",
        "list": [
            "in-case-you-missed-it-issue-15"
        ]
    },
    "fear": {
        "name": "fear",
        "list": [
            "us-vs-them"
        ]
    },
    "leadership": {
        "name": "leadership",
        "list": [
            "us-vs-them",
            "john-james-jacoby-publishes-35-part-tweetstorm-on"
        ]
    },
    "cookbook": {
        "name": "cookbook",
        "list": [
            "wp-site-care-to-launch-cookbook-a-commercial"
        ]
    },
    "native-fonts": {
        "name": "native fonts",
        "list": [
            "wordpress-46-pepper-released-streamlines-plugin-and-theme"
        ]
    },
    "pepper-adams": {
        "name": "pepper adams",
        "list": [
            "wordpress-46-pepper-released-streamlines-plugin-and-theme"
        ]
    },
    "shiny-updates": {
        "name": "shiny updates",
        "list": [
            "wordpress-46-pepper-released-streamlines-plugin-and-theme",
            "wpweekly-episode-238-interview-with-adam-warner-sitelocks",
            "shiny-updates-project-officially-proposed-for-merge-into",
            "shiny-updates-version-2-adds-functionality-for-themes"
        ]
    },
    "wordpress-46": {
        "name": "WordPress 4.6",
        "list": [
            "wordpress-46-pepper-released-streamlines-plugin-and-theme",
            "wordpress-46-will-detect-broken-links-in-the",
            "wpweekly-episode-242-interview-with-eric-meyer",
            "wordpress-46-to-standardize-metadata-registration",
            "wordpress-46-beta-1-is-available-for-testing",
            "shiny-updates-approved-for-partial-merge-into-wordpress",
            "wordpress-46-development-kicks-off-this-week-dominik"
        ]
    },
    "web-accessibility": {
        "name": "web accessibility",
        "list": [
            "new-wa11y-plugin-scans-wordpress-sites-for-accessibility"
        ]
    },
    "software": {
        "name": "software",
        "list": [
            "in-case-you-missed-it-issue-14"
        ]
    },
    "testimonals": {
        "name": "testimonals",
        "list": [
            "in-case-you-missed-it-issue-14"
        ]
    },
    "wordcamp-sunshine-coast": {
        "name": "wordcamp sunshine coast",
        "list": [
            "in-case-you-missed-it-issue-14"
        ]
    },
    "journalism": {
        "name": "journalism",
        "list": [
            "wpweekly-episode-243-the-struggle-is-real"
        ]
    },
    "struggles": {
        "name": "struggles",
        "list": [
            "wpweekly-episode-243-the-struggle-is-real"
        ]
    },
    "layers": {
        "name": "layers",
        "list": [
            "layers-ends-exclusive-arrangement-with-envato-launches-new"
        ]
    },
    "wordcamp-bucharest": {
        "name": "wordcamp bucharest",
        "list": [
            "bucharest-romania-to-host-a-wordcamp-october-8"
        ]
    },
    "government": {
        "name": "government",
        "list": [
            "white-house-publishes-federal-source-code-policy-launches",
            "developers-urge-white-house-to-consider-open-by",
            "white-house-seeks-feedback-on-github-for-government"
        ]
    },
    "open-source-government-software": {
        "name": "open source government software",
        "list": [
            "white-house-publishes-federal-source-code-policy-launches",
            "bulgarian-government-now-requires-custom-software-to-be"
        ]
    },
    "ulysses": {
        "name": "ulysses",
        "list": [
            "ulysses-26-released-users-can-now-publish-posts"
        ]
    },
    "koding": {
        "name": "koding",
        "list": [
            "koding-open-sources-cloud-based-ide-partners-with"
        ]
    },
    "migrations": {
        "name": "migrations",
        "list": [
            "quickly-migrate-content-from-one-wordpress-site-to"
        ]
    },
    "excitement": {
        "name": "excitement",
        "list": [
            "the-wow-factor-in-major-wordpress-releases-is"
        ]
    },
    "wordpress-development": {
        "name": "wordpress development",
        "list": [
            "the-wow-factor-in-major-wordpress-releases-is"
        ]
    },
    "contact-form-7": {
        "name": "contact form 7",
        "list": [
            "contact-form-7-passes-40-million-downloads"
        ]
    },
    "posts-2-posts": {
        "name": "posts 2 posts",
        "list": [
            "users-of-the-posts-2-posts-plugin-left"
        ]
    },
    "relationships": {
        "name": "relationships",
        "list": [
            "users-of-the-posts-2-posts-plugin-left"
        ]
    },
    "scribu": {
        "name": "scribu",
        "list": [
            "users-of-the-posts-2-posts-plugin-left"
        ]
    },
    "wordcamp-okc": {
        "name": "wordcamp okc",
        "list": [
            "wordcamp-okc-unifies-oklahoma-wordpress-community-introduces-okie"
        ]
    },
    "avatar": {
        "name": "avatar",
        "list": [
            "managing-gravatars-in-wordpress-is-a-jarring-user"
        ]
    },
    "frameworks": {
        "name": "frameworks",
        "list": [
            "includewp-a-directory-that-caters-to-wordpress-frameworks"
        ]
    },
    "includewp": {
        "name": "includewp",
        "list": [
            "includewp-a-directory-that-caters-to-wordpress-frameworks"
        ]
    },
    "disable-blogging": {
        "name": "disable blogging",
        "list": [
            "easily-hide-wordpress-blogging-features-with-the-disable"
        ]
    },
    "patents": {
        "name": "patents",
        "list": [
            "automattic-will-continue-to-use-reactjs-in-calypso"
        ]
    },
    "wordpress-documentation": {
        "name": "wordpress documentation",
        "list": [
            "stack-overflow-documentation-is-now-in-beta"
        ]
    },
    "wpcampus-surveys": {
        "name": "wpcampus. surveys",
        "list": [
            "wpcampus-survey-results-indicate-misconceptions-of-wordpress-are"
        ]
    },
    "eric-meyer": {
        "name": "eric meyer",
        "list": [
            "wpweekly-episode-242-interview-with-eric-meyer"
        ]
    },
    "open-source-culture": {
        "name": "open source culture",
        "list": [
            "ford-foundation-publishes-non-technical-white-paper-on"
        ]
    },
    "linode": {
        "name": "linode",
        "list": [
            "downtime-expected-for-some-wp-engine-customers-as"
        ]
    },
    "wpengine": {
        "name": "wpengine",
        "list": [
            "downtime-expected-for-some-wp-engine-customers-as"
        ]
    },
    "a-week-of-rest": {
        "name": "a week of rest",
        "list": [
            "human-made-is-giving-away-two-full-scholarships"
        ]
    },
    "economics": {
        "name": "economics",
        "list": [
            "john-james-jacoby-publishes-35-part-tweetstorm-on"
        ]
    },
    "tweetstorm": {
        "name": "tweetstorm",
        "list": [
            "john-james-jacoby-publishes-35-part-tweetstorm-on"
        ]
    },
    "admin-columns": {
        "name": "admin columns",
        "list": [
            "easily-add-remove-and-rearrange-columns-with-the"
        ]
    },
    "caching": {
        "name": "caching",
        "list": [
            "wp-rocket-celebrates-3-years-in-business-passes",
            "simple-cache-a-new-one-click-install-caching"
        ]
    },
    "wp-rocket": {
        "name": "wp rocket",
        "list": [
            "wp-rocket-celebrates-3-years-in-business-passes"
        ]
    },
    "freedom-of-speech": {
        "name": "freedom of speech",
        "list": [
            "google-removes-dennis-coopers-14-year-old-blog"
        ]
    },
    "singapore": {
        "name": "singapore",
        "list": [
            "in-case-you-missed-it-issue-13"
        ]
    },
    "wordpress-audio": {
        "name": "wordpress audio",
        "list": [
            "new-plugin-adds-featured-audio-to-wordpress-posts"
        ]
    },
    "aesop-story-engine": {
        "name": "aesop story engine",
        "list": [
            "wpweekly-episode-241-wordcamp-warmup-jetpack-41-and",
            "aesop-story-engine-178-improves-video-and-chapter"
        ]
    },
    "all-in-one-seo": {
        "name": "all in one seo",
        "list": [
            "wpweekly-episode-241-wordcamp-warmup-jetpack-41-and",
            "all-in-one-seo-237-patches-persistent-xss"
        ]
    },
    "bp-rest-api": {
        "name": "BP REST API",
        "list": [
            "buddypress-27-development-kicks-off-project-shifts-focus"
        ]
    },
    "codeable": {
        "name": "codeable",
        "list": [
            "codeableio-buys-back-shares-from-early-investors-partners"
        ]
    },
    "new-york": {
        "name": "new york",
        "list": [
            "wordcamp-new-york-city-takes-part-in-united"
        ]
    },
    "united-nations": {
        "name": "united nations",
        "list": [
            "wordcamp-new-york-city-takes-part-in-united"
        ]
    },
    "attachments": {
        "name": "attachments",
        "list": [
            "new-plugin-adds-the-ability-to-categorize-and"
        ]
    },
    "media-library": {
        "name": "media library",
        "list": [
            "new-plugin-adds-the-ability-to-categorize-and"
        ]
    },
    "taxonomies": {
        "name": "taxonomies",
        "list": [
            "new-plugin-adds-the-ability-to-categorize-and"
        ]
    },
    "wordpress-meta": {
        "name": "wordpress meta",
        "list": [
            "wordpress-46-to-standardize-metadata-registration"
        ]
    },
    "wordpress-stats": {
        "name": "wordpress stats",
        "list": [
            "wordpress-stats-page-redesigned-adds-new-data-on"
        ]
    },
    "whatsapp": {
        "name": "whatsapp",
        "list": [
            "jetpack-41-adds-telegram-and-whatsapp-sharing-buttons",
            "wordpresscom-adds-sharing-buttons-for-whatsapp-telegram-and"
        ]
    },
    "mockups": {
        "name": "mockups",
        "list": [
            "community-created-mockups-suggest-improvements-to-the-wordpress"
        ]
    },
    "wireframes": {
        "name": "wireframes",
        "list": [
            "community-created-mockups-suggest-improvements-to-the-wordpress"
        ]
    },
    "responsive-design": {
        "name": "responsive design",
        "list": [
            "responsive-design-should-be-required-for-wordpressorg-themes"
        ]
    },
    "wordpress-themes-directory": {
        "name": "wordpress themes directory",
        "list": [
            "responsive-design-should-be-required-for-wordpressorg-themes"
        ]
    },
    "icymi": {
        "name": "icymi",
        "list": [
            "in-case-you-missed-it-issue-12",
            "in-case-you-missed-it-issue-3"
        ]
    },
    "internationalization": {
        "name": "internationalization",
        "list": [
            "in-case-you-missed-it-issue-12",
            "global-wordpress-translation-day-draws-448-participants-from"
        ]
    },
    "pluginscon": {
        "name": "pluginscon",
        "list": [
            "my-first-impression-of-pluginscon-a-conference-dedicated"
        ]
    },
    "wordpress-chrome-extensions": {
        "name": "wordpress chrome extensions",
        "list": [
            "wordpress-admin-switcher-a-new-google-chrome-extension"
        ]
    },
    "commercial": {
        "name": "commercial",
        "list": [
            "commercial-wordpress-product-descriptions-can-mislead-customers-into",
            "freemius-checkout-aims-to-take-the-hassle-out"
        ]
    },
    "redesign": {
        "name": "redesign",
        "list": [
            "new-wordpress-plugin-directory-now-in-open-beta"
        ]
    },
    "admin-bar": {
        "name": "admin bar",
        "list": [
            "in-case-you-missed-it-issue-11"
        ]
    },
    "italy-wapuu": {
        "name": "italy wapuu",
        "list": [
            "in-case-you-missed-it-issue-11"
        ]
    },
    "plugintut": {
        "name": "plugintut",
        "list": [
            "in-case-you-missed-it-issue-11"
        ]
    },
    "theme-reviewers": {
        "name": "theme reviewers",
        "list": [
            "in-case-you-missed-it-issue-11"
        ]
    },
    "database": {
        "name": "database",
        "list": [
            "why-some-wordpress-plugins-leave-orphaned-tables-in"
        ]
    },
    "giveaway": {
        "name": "giveaway",
        "list": [
            "advanced-wordpress-facebook-group-is-giving-40k-worth"
        ]
    },
    "buddypress-26": {
        "name": "buddypress 2.6",
        "list": [
            "buddypress-26-espejo-released-introduces-activity-embeds-and",
            "buddypress-26-to-introduce-new-api-for-navigation",
            "buddypress-26-development-kicks-off-david-cavins-to"
        ]
    },
    "french-wordpress-community": {
        "name": "french wordpress community",
        "list": [
            "thinkwp-releases-first-trailer-of-upcoming-50-minute"
        ]
    },
    "thinkwp": {
        "name": "thinkwp",
        "list": [
            "thinkwp-releases-first-trailer-of-upcoming-50-minute"
        ]
    },
    "eig": {
        "name": "eig",
        "list": [
            "how-hari-ravichandran-founded-endurance-international-group"
        ]
    },
    "webhosting": {
        "name": "webhosting",
        "list": [
            "how-hari-ravichandran-founded-endurance-international-group",
            "the-wordpressorg-recommended-hosting-page-is-revamped-features"
        ]
    },
    "happy-joe": {
        "name": "happy joe",
        "list": [
            "happy-joe-shifts-focus-to-medical-marijuana-education",
            "happy-joe-to-shut-down-non-profit-organization"
        ]
    },
    "tls": {
        "name": "TLS",
        "list": [
            "new-wordpress-plugin-tests-for-tls-12-compatibility"
        ]
    },
    "menus": {
        "name": "menus",
        "list": [
            "new-wordpress-feature-proposal-adds-content-authorship-to"
        ]
    },
    "phpworld": {
        "name": "php[world]",
        "list": [
            "phpworld-2016-call-for-speakers-now-open-wordpress"
        ]
    },
    "ideas": {
        "name": "ideas",
        "list": [
            "wordpress-feature-idea-add-oembed-support-to-comments"
        ]
    },
    "sublime": {
        "name": "sublime",
        "list": [
            "ahmad-awais-releases-wordpress-customizer-package-for-sublime"
        ]
    },
    "commercial-plugins": {
        "name": "commercial plugins",
        "list": [
            "brad-touesnard-on-why-clients-should-own-their"
        ]
    },
    "licenses": {
        "name": "licenses",
        "list": [
            "brad-touesnard-on-why-clients-should-own-their"
        ]
    },
    "google-fonts": {
        "name": "google fonts",
        "list": [
            "google-fonts-gets-a-redesign"
        ]
    },
    "forms": {
        "name": "forms",
        "list": [
            "gravityforms-20-released-featuring-recaptcha-20-security-hardening"
        ]
    },
    "gravityforms": {
        "name": "gravityforms",
        "list": [
            "gravityforms-20-released-featuring-recaptcha-20-security-hardening"
        ]
    },
    "kent": {
        "name": "kent",
        "list": [
            "wordcamp-northeast-ohio-a-smashing-success"
        ]
    },
    "ohio": {
        "name": "ohio",
        "list": [
            "wordcamp-northeast-ohio-a-smashing-success"
        ]
    },
    "afterparty": {
        "name": "afterparty",
        "list": [
            "wpweekly-episode-237-dont-take-my-booze-away",
            "how-wordcamp-londons-social-event-was-more-inclusive",
            "should-wordcamp-afterparties-be-alcohol-free"
        ]
    },
    "ukraine": {
        "name": "ukraine",
        "list": [
            "wpweekly-episode-237-dont-take-my-booze-away"
        ]
    },
    "checkout": {
        "name": "checkout",
        "list": [
            "freemius-checkout-aims-to-take-the-hassle-out"
        ]
    },
    "optinmonster": {
        "name": "optinmonster",
        "list": [
            "postmatic-2-features-email-digests-comment-intelligence-and"
        ]
    },
    "zapier": {
        "name": "zapier",
        "list": [
            "postmatic-2-features-email-digests-comment-intelligence-and"
        ]
    },
    "wordcamp-belfast": {
        "name": "wordcamp belfast",
        "list": [
            "wordcamp-belfast-set-for-october-2016-tickets-now",
            "wordpress-meetup-groups-in-belfast-and-dublin-are"
        ]
    },
    "alcohol": {
        "name": "alcohol",
        "list": [
            "how-wordcamp-londons-social-event-was-more-inclusive",
            "should-wordcamp-afterparties-be-alcohol-free"
        ]
    },
    "london": {
        "name": "london",
        "list": [
            "how-wordcamp-londons-social-event-was-more-inclusive"
        ]
    },
    "bp-reactions": {
        "name": "bp reactions",
        "list": [
            "new-plugin-adds-emoji-reactions-to-the-buddypress"
        ]
    },
    "wordcamp-kyiv": {
        "name": "wordcamp kyiv",
        "list": [
            "kyiv-ukraine-to-host-its-first-official-wordcamp"
        ]
    },
    "bobwp": {
        "name": "bobwp",
        "list": [
            "in-case-you-missed-it-issue-10"
        ]
    },
    "caldera": {
        "name": "caldera",
        "list": [
            "in-case-you-missed-it-issue-10"
        ]
    },
    "layerswp": {
        "name": "layerswp",
        "list": [
            "in-case-you-missed-it-issue-10"
        ]
    },
    "donation": {
        "name": "donation",
        "list": [
            "wpweekly-episode-236-wordpress-turns-13-years-old",
            "syed-balkhi-donates-wporg-to-the-wordpress-foundation"
        ]
    },
    "thematic": {
        "name": "thematic",
        "list": [
            "wpweekly-episode-236-wordpress-turns-13-years-old",
            "after-eight-years-thematic-themes-lead-developers-discontinue"
        ]
    },
    "upthemes": {
        "name": "upthemes",
        "list": [
            "themeforest-author-parallelus-acquires-upthemes"
        ]
    },
    "branding": {
        "name": "branding",
        "list": [
            "in-case-you-missed-it-issue-9"
        ]
    },
    "support-forums": {
        "name": "support forums",
        "list": [
            "in-case-you-missed-it-issue-9",
            "first-global-wordpress-contributor-drive-set-for-january"
        ]
    },
    "directory": {
        "name": "directory",
        "list": [
            "wordpress-meta-team-publishes-prototypes-of-the-plugin"
        ]
    },
    "ian-stewart": {
        "name": "ian stewart",
        "list": [
            "after-eight-years-thematic-themes-lead-developers-discontinue"
        ]
    },
    "easy-update-manager": {
        "name": "easy update manager",
        "list": [
            "take-granular-control-of-wordpress-update-system-with"
        ]
    },
    "categories": {
        "name": "categories",
        "list": [
            "wordpress-46-improves-the-accessibility-of-the-tag"
        ]
    },
    "recommended": {
        "name": "recommended",
        "list": [
            "the-wordpressorg-recommended-hosting-page-is-revamped-features"
        ]
    },
    "drupalcamps": {
        "name": "drupalcamps",
        "list": [
            "wpweekly-episode-234-all-things-wordcamp-with-andrea"
        ]
    },
    "drupalcon": {
        "name": "drupalcon",
        "list": [
            "wpweekly-episode-234-all-things-wordcamp-with-andrea"
        ]
    },
    "phpstorm": {
        "name": "phpstorm",
        "list": [
            "critical-vulnerabilities-found-in-phpstorm-immediate-update-advised"
        ]
    },
    "recommendations": {
        "name": "recommendations",
        "list": [
            "what-do-you-think-of-the-recommended-plugins"
        ]
    },
    "woo": {
        "name": "woo",
        "list": [
            "automattic-is-protecting-its-woo-woothemes-and-woocommerce"
        ]
    },
    "woothemes": {
        "name": "woothemes",
        "list": [
            "automattic-is-protecting-its-woo-woothemes-and-woocommerce"
        ]
    },
    "timber": {
        "name": "timber",
        "list": [
            "timber-10-is-now-available-on-wordpressorg"
        ]
    },
    "twig": {
        "name": "twig",
        "list": [
            "timber-10-is-now-available-on-wordpressorg"
        ]
    },
    "wordpress-452": {
        "name": "wordpress 4.5.2",
        "list": [
            "wordpress-452-patches-two-security-vulnerabilities"
        ]
    },
    "wcag": {
        "name": "wcag",
        "list": [
            "wordpressorg-support-forums-adds-accessibility-section"
        ]
    },
    "font-awesome": {
        "name": "font awesome",
        "list": [
            "font-awesome-cdn-now-in-beta-loads-icons",
            "font-awesome-460-adds-new-accessibility-icons-category"
        ]
    },
    "freemium": {
        "name": "freemium",
        "list": [
            "wpweekly-episode-233-recap-of-wordcamp-chicago-2016"
        ]
    },
    "woocomerce": {
        "name": "woocomerce",
        "list": [
            "wpweekly-episode-233-recap-of-wordcamp-chicago-2016"
        ]
    },
    "wordcamp-chicago": {
        "name": "wordcamp chicago",
        "list": [
            "wpweekly-episode-233-recap-of-wordcamp-chicago-2016"
        ]
    },
    "chicago": {
        "name": "chicago",
        "list": [
            "wordcamp-chicago-2016-was-a-deep-dish-of",
            "im-attending-wordcamp-chicago-2016-this-weekend"
        ]
    },
    "pizza": {
        "name": "pizza",
        "list": [
            "wordcamp-chicago-2016-was-a-deep-dish-of"
        ]
    },
    "patch": {
        "name": "patch",
        "list": [
            "bbpress-259-patches-cross-site-scripting-vulnerability"
        ]
    },
    "templatic": {
        "name": "templatic",
        "list": [
            "templatic-hacked-files-and-databases-compromised"
        ]
    },
    "beer": {
        "name": "beer",
        "list": [
            "create-beer-menus-with-the-easy-beer-lister"
        ]
    },
    "wordcamp-tokyo": {
        "name": "wordcamp tokyo",
        "list": [
            "wordcamp-tokyo-2016-calls-for-speakers-adds-new"
        ]
    },
    "wordpress-451": {
        "name": "wordpress 4.5.1",
        "list": [
            "wpweekly-episode-232-recap-of-wordcamp-san-diego",
            "wordpress-451-fixes-12-bugs"
        ]
    },
    "array": {
        "name": "array",
        "list": [
            "array-cuts-theme-club-pricing-releases-free-theme"
        ]
    },
    "geotag": {
        "name": "geotag",
        "list": [
            "wordpress-for-ios-adds-geotag-support-comment-moderation"
        ]
    },
    "gestures": {
        "name": "gestures",
        "list": [
            "wordpress-for-ios-adds-geotag-support-comment-moderation"
        ]
    },
    "wordpres-for-ios": {
        "name": "wordpres for ios",
        "list": [
            "wordpress-for-ios-adds-geotag-support-comment-moderation"
        ]
    },
    "edd": {
        "name": "edd",
        "list": [
            "in-case-you-missed-it-issue-8",
            "affiliatewp-passes-30k-in-monthly-revenue-after-2"
        ]
    },
    "mullenweg": {
        "name": "mullenweg",
        "list": [
            "in-case-you-missed-it-issue-8"
        ]
    },
    "translations-pressware": {
        "name": "translations. pressware",
        "list": [
            "in-case-you-missed-it-issue-8"
        ]
    },
    "451": {
        "name": "4.5.1",
        "list": [
            "wordpress-451-expected-early-next-week"
        ]
    },
    "beaver-builder": {
        "name": "beaver builder",
        "list": [
            "beaver-builder-passes-1-million-in-revenue-after"
        ]
    },
    "api": {
        "name": "api",
        "list": [
            "a-tip-for-convincing-customers-to-renew-license"
        ]
    },
    "license-keys": {
        "name": "license keys",
        "list": [
            "a-tip-for-convincing-customers-to-renew-license"
        ]
    },
    "wordpress-importer": {
        "name": "wordpress importer",
        "list": [
            "help-test-the-new-wordpress-importer-plugin-in",
            "in-case-you-missed-it-issue-7"
        ]
    },
    "monsterinsights": {
        "name": "monsterinsights",
        "list": [
            "monsterinsights-addresses-user-criticism-with-immediate-changes",
            "syed-balkhi-acquires-google-analytics-by-yoast-renames"
        ]
    },
    "admin-notice": {
        "name": "admin notice",
        "list": [
            "please-stop-abusing-wordpress-admin-notices"
        ]
    },
    "simple-cache": {
        "name": "simple cache",
        "list": [
            "simple-cache-a-new-one-click-install-caching"
        ]
    },
    "google-analytics": {
        "name": "google analytics",
        "list": [
            "syed-balkhi-acquires-google-analytics-by-yoast-renames"
        ]
    },
    "mike-schroder": {
        "name": "mike schroder",
        "list": [
            "wpweekly-episode-230-interview-with-mike-schroder-wordpress"
        ]
    },
    "wordpress-45": {
        "name": "wordpress 4.5",
        "list": [
            "wpweekly-episode-230-interview-with-mike-schroder-wordpress",
            "wordpress-45-coleman-released-introduces-custom-logos-responsive",
            "versions-of-wp-cli-prior-to-0230-are",
            "wordpress-45-improves-comment-moderation-screens",
            "jetpack-393-maintenance-release-adds-compatibility-for-wordpress",
            "wordpress-45-adds-inline-editing-to-the-links",
            "wpweekly-episode-224-preview-of-wordpress-45",
            "wordpress-45-to-introduce-native-support-for-a",
            "customizer-responsive-preview-and-selective-refresh-to-be"
        ]
    },
    "wordcamp-london": {
        "name": "wordcamp london",
        "list": [
            "mendel-kurland-interviews-konstantin-obenland-at-wordcamp-london",
            "giant-wapuu-among-the-attendees-at-wordcamp-london",
            "limited-edition-r2-wapuu-will-debut-at-wordcamp"
        ]
    },
    "a-day-of-rest": {
        "name": "A Day of REST",
        "list": [
            "a-day-of-rest-is-coming-to-boston"
        ]
    },
    "wapuu-api": {
        "name": "Wapuu API",
        "list": [
            "json-api-now-available-for-wordpress-wapuu-archive"
        ]
    },
    "video-games": {
        "name": "video games",
        "list": [
            "in-case-you-missed-it-issue-7"
        ]
    },
    "wplift": {
        "name": "wplift",
        "list": [
            "in-case-you-missed-it-issue-7"
        ]
    },
    "news-publisher": {
        "name": "news publisher",
        "list": [
            "my-apple-news-publisher-experience-three-weeks-later",
            "how-to-connect-your-wordpress-powered-site-to"
        ]
    },
    "affiliatewp": {
        "name": "affiliatewp",
        "list": [
            "affiliatewp-passes-30k-in-monthly-revenue-after-2"
        ]
    },
    "panama-papers": {
        "name": "panama papers",
        "list": [
            "outdated-and-vulnerable-wordpress-and-drupal-versions-may"
        ]
    },
    "post-status": {
        "name": "post status",
        "list": [
            "wordcamp-central-now-lets-you-track-an-events"
        ]
    },
    "user-role-editor": {
        "name": "user role editor",
        "list": [
            "user-role-editor-425-patches-critical-security-vulnerability"
        ]
    },
    "giannu-jumboji": {
        "name": "giannu. jumboji",
        "list": [
            "in-case-you-missed-it-issue-6"
        ]
    },
    "features-as-plugins": {
        "name": "features-as-plugins",
        "list": [
            "features-as-plugins-first-transitions-into-features-as"
        ]
    },
    "features-as-projects": {
        "name": "features-as-projects",
        "list": [
            "features-as-plugins-first-transitions-into-features-as"
        ]
    },
    "27": {
        "name": "2.7",
        "list": [
            "bbpress-26-expected-later-this-year-two-major"
        ]
    },
    "forum": {
        "name": "forum",
        "list": [
            "bbpress-26-expected-later-this-year-two-major"
        ]
    },
    "modern-tribe": {
        "name": "modern tribe",
        "list": [
            "wpweekly-episode-228-communication-is-key"
        ]
    },
    "advice": {
        "name": "advice",
        "list": [
            "a-little-communication-goes-a-long-way"
        ]
    },
    "gigpress": {
        "name": "gigpress",
        "list": [
            "modern-tribe-acquires-gigpress-exploring-saas-events-management"
        ]
    },
    "child-theme": {
        "name": "child theme",
        "list": [
            "add-child-theme-support-to-any-wordpress-theme"
        ]
    },
    "inspiration": {
        "name": "inspiration",
        "list": [
            "wpweekly-episode-227-the-heropress-story-with-topher"
        ]
    },
    "comedy": {
        "name": "comedy",
        "list": [
            "cast-of-silicon-valley-nails-the-meaning-of"
        ]
    },
    "silicon-valley": {
        "name": "silicon valley",
        "list": [
            "cast-of-silicon-valley-nails-the-meaning-of"
        ]
    },
    "w3-edge": {
        "name": "w3 edge",
        "list": [
            "frederick-townes-confirms-w3-total-cache-is-not"
        ]
    },
    "2fa": {
        "name": "2FA",
        "list": [
            "wp-engine-adds-2fa-to-user-portal-opt"
        ]
    },
    "pingbacks": {
        "name": "pingbacks",
        "list": [
            "is-w3c-replicating-the-wordpress-pingback-system"
        ]
    },
    "xml-rpc": {
        "name": "xml-rpc",
        "list": [
            "is-w3c-replicating-the-wordpress-pingback-system"
        ]
    },
    "wpforms-lite": {
        "name": "wpforms lite",
        "list": [
            "wpforms-aims-to-be-the-most-beginner-friendly"
        ]
    },
    "apple-news": {
        "name": "apple news",
        "list": [
            "wpweekly-episode-226-burnout"
        ]
    },
    "burnout": {
        "name": "burnout",
        "list": [
            "wpweekly-episode-226-burnout",
            "when-contributing-to-wordpress-full-time-leads-to"
        ]
    },
    "wordcamp-jacksonville": {
        "name": "wordcamp jacksonville",
        "list": [
            "tickets-for-wordcamp-jacksonville-2016-now-on-sale"
        ]
    },
    "contributing": {
        "name": "contributing",
        "list": [
            "when-contributing-to-wordpress-full-time-leads-to"
        ]
    },
    "drew-jaynes": {
        "name": "drew jaynes",
        "list": [
            "when-contributing-to-wordpress-full-time-leads-to"
        ]
    },
    "ireland": {
        "name": "ireland",
        "list": [
            "in-case-you-missed-it-issue-4"
        ]
    },
    "emoji-reactions": {
        "name": "emoji reactions",
        "list": [
            "github-now-supports-emoji-reactions-for-pull-requests"
        ]
    },
    "custom-content-type-manager": {
        "name": "custom content type manager",
        "list": [
            "custom-content-type-manager-plugin-update-creates-a"
        ]
    },
    "poetica": {
        "name": "poetica",
        "list": [
            "wpweekly-episode-224-preview-of-wordpress-45",
            "poetica-acquired-by-conde-nast-open-source-wordpress"
        ]
    },
    "alex-king": {
        "name": "alex king",
        "list": [
            "joshua-strebel-interviews-alex-king-10-days-before",
            "joshua-strebel-interviews-alex-king-10-days-before-0"
        ]
    },
    "bcrypt": {
        "name": "bcrypt",
        "list": [
            "roots-team-releases-wp-password-bcrypt-plugin-to"
        ]
    },
    "roots": {
        "name": "roots",
        "list": [
            "roots-team-releases-wp-password-bcrypt-plugin-to"
        ]
    },
    "buddypress-25": {
        "name": "buddypress 2.5",
        "list": [
            "buddypress-250-released-features-customizable-emails-and-support"
        ]
    },
    "tgm-plugin-activation": {
        "name": "TGM Plugin Activation",
        "list": [
            "tgm-plugin-activation-library-contributors-work-toward-feature",
            "tgm-plugin-activation-team-releases-custom-generator"
        ]
    },
    "collaboration": {
        "name": "collaboration",
        "list": [
            "poetica-acquired-by-conde-nast-open-source-wordpress"
        ]
    },
    "mailchimp": {
        "name": "mailchimp",
        "list": [
            "mandrill-to-discontinue-free-tier-for-transactional-emails"
        ]
    },
    "mandrill": {
        "name": "mandrill",
        "list": [
            "mandrill-to-discontinue-free-tier-for-transactional-emails"
        ]
    },
    "non-profit": {
        "name": "non-profit",
        "list": [
            "austin-wordpress-meetup-to-host-charity-hackathon-april"
        ]
    },
    "site-logo": {
        "name": "site logo",
        "list": [
            "wordpress-45-to-introduce-native-support-for-a"
        ]
    },
    "elegant-themes": {
        "name": "elegant themes",
        "list": [
            "critical-security-vulnerability-discovered-in-elegant-themes-products"
        ]
    },
    "wp-pusher": {
        "name": "wp pusher",
        "list": [
            "wp-pusher-210-offers-tighter-integration-with-github"
        ]
    },
    "rescue-themes": {
        "name": "rescue themes",
        "list": [
            "rescue-themes-is-for-sale"
        ]
    },
    "change-logs": {
        "name": "change logs",
        "list": [
            "wordpress-theme-review-team-recommends-authors-start-keeping"
        ]
    },
    "custom-contact-forms": {
        "name": "custom contact forms",
        "list": [
            "wordpressorg-has-fewer-than-20-plugins-using-the"
        ]
    },
    "scalability": {
        "name": "scalability",
        "list": [
            "pantheon-launches-community-resource-for-scaling-wordpress"
        ]
    },
    "day-of-rest": {
        "name": "Day of REST",
        "list": [
            "a-day-of-rest-conference-successful-81-would"
        ]
    },
    "mike-little": {
        "name": "mike little",
        "list": [
            "in-case-you-missed-it-issue-2"
        ]
    },
    "wpambassador": {
        "name": "wpambassador",
        "list": [
            "in-case-you-missed-it-issue-2"
        ]
    },
    "backup-buddy": {
        "name": "backup buddy",
        "list": [
            "wpweekly-episode-223-celebrating-8-years-of-ithemes"
        ]
    },
    "contributor": {
        "name": "contributor",
        "list": [
            "wpweekly-episode-223-celebrating-8-years-of-ithemes"
        ]
    },
    "giving-thanks": {
        "name": "giving thanks",
        "list": [
            "thank-a-wordpress-plugin-and-theme-author-day"
        ]
    },
    "holiday": {
        "name": "holiday",
        "list": [
            "thank-a-wordpress-plugin-and-theme-author-day"
        ]
    },
    "nonprofit": {
        "name": "nonprofit",
        "list": [
            "mark-root-wiley-publishes-free-guide-for-nonprofits"
        ]
    },
    "continuous-integration": {
        "name": "continuous integration",
        "list": [
            "kernl-to-offer-hosted-private-plugin-and-theme"
        ]
    },
    "kernl": {
        "name": "kernl",
        "list": [
            "kernl-to-offer-hosted-private-plugin-and-theme"
        ]
    },
    "challenge": {
        "name": "challenge",
        "list": [
            "first-global-wordpress-contributor-drive-set-for-january"
        ]
    },
    "deployer": {
        "name": "deployer",
        "list": [
            "deployer-app-pushes-plugins-from-github-to-wordpressorg"
        ]
    },
    "ilovewp": {
        "name": "#ilovewp",
        "list": [
            "wordpress-is-revamping-its-testimonials-page-with-ilovewp"
        ]
    },
    "glotpress": {
        "name": "glotpress",
        "list": [
            "wpweekly-episode-222-ithemes-enters-the-real-time"
        ]
    },
    "content": {
        "name": "content",
        "list": [
            "michael-arestad-sparks-renewed-effort-to-improve-the"
        ]
    },
    "visual-editor": {
        "name": "visual editor",
        "list": [
            "michael-arestad-sparks-renewed-effort-to-improve-the"
        ]
    },
    "justin-tadlock": {
        "name": "justin tadlock",
        "list": [
            "theme-hybrid-releases-its-first-commercial-plugin-theme"
        ]
    },
    "theme-hybrid": {
        "name": "theme hybrid",
        "list": [
            "theme-hybrid-releases-its-first-commercial-plugin-theme"
        ]
    },
    "valet": {
        "name": "valet",
        "list": [
            "wp-valet-rebrands-multimillion-dollar-wordpress-support-business"
        ]
    },
    "wp-valet": {
        "name": "wp valet",
        "list": [
            "wp-valet-rebrands-multimillion-dollar-wordpress-support-business"
        ]
    }
}