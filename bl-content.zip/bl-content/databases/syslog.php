<?php defined('BLUDIT') or die('Bludit CMS.'); ?>
[
    {
        "date": "2018-07-16 18:14:28",
        "dictionaryKey": "new-content-created",
        "notes": "WordCamp for iOS Renamed to WP Camps, More Events Added",
        "idExecution": "5b4cb65416154",
        "method": "POST",
        "username": "admin"
    },
    {
        "date": "2018-07-16 18:14:28",
        "dictionaryKey": "plugin-configured",
        "notes": "WordPress Visual Importer",
        "idExecution": "5b4cb65416154",
        "method": "POST",
        "username": "admin"
    },
    {
        "date": "2018-07-16 18:14:25",
        "dictionaryKey": "new-content-created",
        "notes": "WPWeekly Episode 319 – The Gutenberg Plugin Turns 30",
        "idExecution": "5b4cb65198238",
        "method": "POST",
        "username": "admin"
    },
    {
        "date": "2018-07-16 18:14:25",
        "dictionaryKey": "plugin-configured",
        "notes": "WordPress Visual Importer",
        "idExecution": "5b4cb65198238",
        "method": "POST",
        "username": "admin"
    },
    {
        "date": "2018-07-16 18:14:24",
        "dictionaryKey": "new-content-created",
        "notes": "WordCamp Europe Introduces Official Mobile App, New Tech for On-site Badge Printing",
        "idExecution": "5b4cb650b4be5",
        "method": "POST",
        "username": "admin"
    },
    {
        "date": "2018-07-16 18:14:24",
        "dictionaryKey": "plugin-configured",
        "notes": "WordPress Visual Importer",
        "idExecution": "5b4cb650b4be5",
        "method": "POST",
        "username": "admin"
    },
    {
        "date": "2018-07-16 18:14:23",
        "dictionaryKey": "new-content-created",
        "notes": "Watch WordCamp EU for Free via Livestream",
        "idExecution": "5b4cb64f3ecfb",
        "method": "POST",
        "username": "admin"
    },
    {
        "date": "2018-07-16 18:14:23",
        "dictionaryKey": "plugin-configured",
        "notes": "WordPress Visual Importer",
        "idExecution": "5b4cb64f3ecfb",
        "method": "POST",
        "username": "admin"
    },
    {
        "date": "2018-07-16 18:14:21",
        "dictionaryKey": "new-content-created",
        "notes": "Plugin Detective Wins WordCamp Orange County’s 2018 Plugin-a-Palooza",
        "idExecution": "5b4cb64da074f",
        "method": "POST",
        "username": "admin"
    },
    {
        "date": "2018-07-16 18:14:21",
        "dictionaryKey": "plugin-configured",
        "notes": "WordPress Visual Importer",
        "idExecution": "5b4cb64da074f",
        "method": "POST",
        "username": "admin"
    }
]